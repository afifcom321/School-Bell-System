# School Bell System

Sistem bel sekolah otomatis. Satu aplikasi desktop Windows menjalankan server lokal yang
menjadwalkan dan membunyikan bel secara otomatis — tepat waktu, tanpa perlu browser tetap
terbuka — sekaligus menyediakan dashboard web yang bisa diakses dari komputer atau HP lain
di jaringan sekolah yang sama untuk mengelola jadwal, sound, dan pengaturan.

```
Guru/Staf (HP, laptop)  ──Wi-Fi/LAN──▶  http://IP-KOMPUTER-SERVER:3000  ──▶  Dashboard Web
                                                    │
                                        Komputer Server (Windows)
                                        ┌─────────────────────────┐
                                        │  School Bell System.exe │
                                        │  - Scheduler (penjadwal)│──▶ 🔔 Speaker
                                        │  - Web server + API     │
                                        │  - Database (SQLite)    │
                                        └─────────────────────────┘
```

## Daftar Isi

- [Fitur Utama](#fitur-utama)
- [Struktur Folder](#struktur-folder)
- [Menjalankan dalam Mode Pengembangan](#menjalankan-dalam-mode-pengembangan)
- [Build Aplikasi Windows (.exe)](#build-aplikasi-windows-exe)
- [Login Pertama Kali](#login-pertama-kali)
- [Mengakses Dashboard dari Jaringan Sekolah](#mengakses-dashboard-dari-jaringan-sekolah)
- [Autostart saat Windows Menyala](#autostart-saat-windows-menyala)
- [Contoh Jadwal & Sound Bawaan](#contoh-jadwal--sound-bawaan)
- [Backup & Restore](#backup--restore)
- [Mode Ujian, Jeda, dan Hari Libur](#mode-ujian-jeda-dan-hari-libur)
- [Keamanan](#keamanan)
- [Menjalankan Tanpa Aplikasi Desktop (Headless)](#menjalankan-tanpa-aplikasi-desktop-headless)
- [Testing](#testing)
- [Troubleshooting](#troubleshooting)

## Fitur Utama

- **Penjadwalan akurat & tahan restart** — scheduler menghitung bel berikutnya dari jam
  sebenarnya (bukan timer `setTimeout` yang bisa meleset). Restart aplikasi tepat pukul
  07:29 tetap tahu bel berikutnya adalah 07:30, dan tidak akan berbunyi dua kali.
- **Berjalan di server, bukan di browser** — bel tetap berbunyi tepat waktu walau tidak ada
  dashboard yang sedang dibuka di komputer/HP mana pun.
- **Dashboard web real-time** — jam berjalan, hitung mundur ke bel berikutnya, dan status
  selalu sinkron di semua perangkat yang membuka dashboard secara bersamaan.
- **Manajemen jadwal fleksibel** — berulang per hari (mis. Senin–Jumat) atau tanggal
  tertentu, per-jadwal bisa memakai sound & volume berbeda, aktif/nonaktifkan tanpa
  menghapus, impor/ekspor jadwal sebagai berkas JSON.
- **Manajemen sound** — unggah MP3/WAV/OGG lewat drag-and-drop, preview langsung di
  browser, atur volume & batas durasi per sound.
- **Mode ujian & jeda sementara** — tahan bel otomatis untuk periode ujian atau kebutuhan
  mendadak, tanpa perlu mengubah/menghapus jadwal.
- **Hari libur** — rentang tanggal libur membuat bel otomatis tidak berbunyi pada hari itu.
- **Login & peran pengguna** — akun **Administrator** (kontrol penuh) dan **Viewer**
  (hanya melihat), cocok dibagikan ke guru piket tanpa risiko jadwal berubah.
- **Backup & restore database** — satu klik, plus backup otomatis harian.
- **Log lengkap** — setiap bel (berhasil/gagal/terlewat/dilewati karena libur-ujian-jeda)
  dan setiap perubahan pengaturan tercatat dengan waktu dan pelakunya.
- **Aplikasi desktop Windows** — ikon di system tray, panel kontrol ringkas, autostart
  saat Windows menyala, dan mencegah komputer sleep agar bel tidak terlewat.

## Struktur Folder

```
school-bell/
├── desktop/         Aplikasi Electron (proses utama, panel kontrol, pemutar audio)
├── server/          Server inti: API REST, scheduler, database, autentikasi
├── frontend/        Dashboard web (HTML/CSS/JS biasa, tanpa proses build)
├── default-sounds/  3 sound bawaan (disalin otomatis saat pertama kali dijalankan)
├── scripts/         Skrip bantu (mis. pembuat sound & ikon bawaan)
├── test/            Automated test (Node test runner)
└── build/           Aset untuk electron-builder (ikon .exe)
```

Saat aplikasi berjalan, data (database, sound yang diunggah, log, backup) disimpan **di
luar folder instalasi** supaya aman saat aplikasi di-update:

- Mode aplikasi desktop (packaged) → `%APPDATA%\School Bell System\`
- Mode pengembangan (`npm start` dari source) → folder `data/`, `sounds/`, `logs/` di
  dalam folder project

## Menjalankan dalam Mode Pengembangan

Kebutuhan: **Node.js 22.13 atau lebih baru** (memakai `node:sqlite` bawaan Node — tidak
perlu kompilasi native module apa pun, sehingga tidak perlu Visual Studio Build Tools).

```bash
npm install          # instal dependensi
npm start             # jalankan sebagai aplikasi desktop (Electron)
# atau
npm run dev            # sama seperti di atas, dengan DevTools terbuka
# atau
npm run server          # jalankan HANYA server (tanpa Electron) — cocok untuk mini-PC/NAS
```

Setelah berjalan, buka **http://localhost:3000** di browser. Login awal ada di bagian
[Login Pertama Kali](#login-pertama-kali).

`npm run server` berguna bila ingin menjalankan School Bell System di komputer tanpa
kepala (headless) seperti mini-PC atau server Linux — bel dan dashboard tetap berfungsi
penuh, hanya tanpa jendela panel kontrol/tray Windows.

## Build Aplikasi Windows (.exe)

Build **dilakukan di komputer mana pun** (Windows/Mac/Linux) — hasilnya berupa installer
Windows yang bisa dibagikan dan dipasang di komputer sekolah.

```bash
npm run build:win-installer   # installer .exe (disarankan) → dist/School Bell System Setup <versi>.exe
npm run build:win-portable    # versi portable, tanpa instalasi → dist/SchoolBellSystem-Portable-<versi>.exe
npm run build:win             # keduanya sekaligus
```

Hasil build ada di folder `dist/`. Installer memakai NSIS: pengguna bisa memilih folder
instalasi, dan shortcut otomatis dibuat di Desktop & Start Menu.

> **Catatan:** `node:sqlite` adalah modul bawaan Node.js (bukan native addon terpisah),
> jadi build ini **tidak memerlukan Python atau Visual Studio Build Tools** seperti
> kebanyakan aplikasi Electron+SQLite lainnya.

## Login Pertama Kali

```
Username : admin
Password : admin123
```

Saat login pertama, sistem **mewajibkan** Anda mengganti password sebelum bisa melakukan
apa pun — ini untuk mencegah aplikasi tertinggal dengan password bawaan yang diketahui
publik. Setelah itu, buat akun tambahan (Administrator/Viewer) di halaman **System**
sesuai kebutuhan — misalnya akun Viewer untuk guru piket yang hanya perlu melihat jadwal
hari itu tanpa bisa mengubahnya.

## Mengakses Dashboard dari Jaringan Sekolah

Web server mendengarkan di semua antarmuka jaringan (`0.0.0.0`), sehingga siapa pun yang
terhubung ke **Wi-Fi/LAN yang sama** dengan komputer server bisa membuka dashboard.

1. Di komputer server, buka aplikasi School Bell System → panel kontrol menampilkan
   daftar alamat (mis. `http://192.168.1.20:3000`), atau lihat di dashboard web pada
   menu **System → Alamat Dashboard**.
2. Di HP/laptop guru yang terhubung ke Wi-Fi sekolah yang sama, buka alamat tersebut di
   browser.
3. Login dengan akun yang sudah dibuat.

Bila alamat tidak bisa diakses dari perangkat lain, periksa Windows Firewall — izinkan
**Node.js**/**School Bell System** untuk jaringan privat (biasanya muncul dialog izin
otomatis saat pertama kali server dijalankan; pilih "Izinkan akses" untuk jaringan privat).

## Autostart saat Windows Menyala

Di panel kontrol aplikasi desktop, aktifkan **"Jalankan otomatis saat Windows menyala"**.
Aplikasi akan langsung berjalan (tersembunyi ke tray) setiap kali Windows dinyalakan,
tanpa perlu dibuka manual — cocok dipasang di komputer yang memang didedikasikan sebagai
"server bel" sekolah.

Pengaturan terkait lainnya (juga di panel kontrol / dashboard menu Pengaturan):

- **Nyalakan web server & jadwal otomatis saat aplikasi dibuka** — aktif secara default.
- **Cegah komputer sleep** — aktif secara default, supaya Windows tidak masuk mode tidur
  di tengah jam sekolah (yang akan membuat bel terlewat).
- **Tombol ✕ hanya menyembunyikan ke tray** — aktif secara default; bel tetap berjalan di
  latar belakang. Untuk benar-benar keluar, klik kanan ikon tray → **Keluar**, atau
  gunakan tombol **"Keluar dari Aplikasi"** di panel kontrol.

## Contoh Jadwal & Sound Bawaan

Saat pertama kali dijalankan, sistem otomatis menyiapkan 3 sound bawaan dan contoh
jadwal berikut (bisa diubah/dihapus bebas dari menu **Jadwal Bel**):

| Jam   | Nama Bel     | Hari         | Sound          |
|-------|--------------|--------------|----------------|
| 07:00 | Upacara      | Senin        | Bel Masuk      |
| 07:30 | Masuk Kelas  | Senin–Jumat  | Bel Masuk      |
| 09:00 | Istirahat    | Senin–Jumat  | Bel Istirahat  |
| 09:30 | Masuk Kelas  | Senin–Jumat  | Bel Masuk      |
| 12:00 | Istirahat    | Senin–Jumat  | Bel Istirahat  |
| 13:00 | Pulang       | Senin–Jumat  | Bel Pulang     |

Jadwal juga bisa diekspor sebagai berkas `.json` (menu **Jadwal Bel → Ekspor**) untuk
disalin ke instalasi School Bell System lain (mis. saat sekolah memasang di komputer
cadangan), lalu diimpor kembali lewat tombol **Impor**.

## Backup & Restore

Menu **System → Backup & Restore Database** mencakup jadwal, sound (metadata), pengaturan,
log, dan akun pengguna dalam satu berkas `.db`. Backup otomatis dibuat setiap hari
(7 backup otomatis terakhir disimpan; bisa dimatikan di Pengaturan).

> Berkas audio yang diunggah (folder `sounds/`) **tidak ikut** dalam backup database —
> cadangkan folder tersebut secara terpisah bila diperlukan (mis. salin ke flashdisk).

Saat restore, sistem otomatis membuat backup pengaman dari kondisi sebelum restore, jadi
proses ini bisa dibatalkan dengan me-restore ulang backup pengaman tersebut.

## Mode Ujian, Jeda, dan Hari Libur

Tiga cara menahan bel otomatis berbunyi tanpa menghapus/mengubah jadwal, dari dashboard
Dashboard atau panel kontrol:

- **Mode Ujian** — untuk periode ujian sekolah; bisa diatur sampai dimatikan manual,
  sampai beberapa jam ke depan, atau sampai tanggal tertentu.
- **Jeda Sementara** — untuk kebutuhan mendadak (15 menit, 30 menit, 1 jam, atau sampai
  besok pagi).
- **Hari Libur** (menu Pengaturan) — rentang tanggal yang berulang (mis. libur semester)
  bisa diatur jauh-jauh hari.

Bel **manual** dan **test sound** tetap bisa digunakan kapan pun walau salah satu mode di
atas sedang aktif.

## Keamanan

- Password disimpan dengan hash **scrypt** (bukan plaintext maupun hash lemah seperti MD5).
- Sesi login dengan cookie `HttpOnly` + `SameSite=Lax`, plus pemeriksaan `Origin` untuk
  mencegah serangan CSRF.
- Percobaan login gagal dibatasi (5 kali → terkunci 5 menit).
- Upload sound divalidasi ketat: ekstensi, tipe MIME, **dan** tanda tangan biner berkas
  (magic bytes) harus konsisten satu sama lain — bukan hanya nama berkas.
- Nama berkas di server selalu dibuat ulang secara acak & aman (tidak pernah memakai nama
  asli dari pengguna) untuk mencegah path traversal.
- Header keamanan standar (`Content-Security-Policy`, `X-Frame-Options`, dll.) aktif di
  seluruh dashboard.

## Menjalankan Tanpa Aplikasi Desktop (Headless)

```bash
npm run server
```

Berguna untuk server Linux/mini-PC yang tidak menjalankan Electron. Semua fitur (jadwal,
dashboard, API) tetap berfungsi penuh; hanya jendela panel kontrol & tray Windows yang
tidak tersedia. Hentikan dengan `Ctrl+C` (server berhenti dengan bersih, menyimpan semua
data sebelum keluar).

Environment variable yang didukung:

| Variabel      | Kegunaan                                                      |
|---------------|----------------------------------------------------------------|
| `PORT`        | Port web server (default: 3000, atau sesuai `data/config.json`) |
| `BELL_HOME`   | Folder data (default: folder project)                          |
| `BELL_AUDIO`  | Set `null` untuk mematikan suara sungguhan (mode testing)       |

## Testing

```bash
npm test
```

Menjalankan test otomatis (Node.js built-in test runner) yang mencakup: akurasi
scheduler (termasuk simulasi restart, keterlambatan, dan kegagalan database), serta
seluruh endpoint API (autentikasi, validasi input, upload sound, backup/restore, dsb).

## Troubleshooting

**Bel tidak berbunyi di jam yang seharusnya**
Periksa menu **Logs** — setiap bel yang gagal, terlewat, atau sengaja dilewati (libur/
ujian/jeda/jadwal nonaktif) selalu tercatat beserta alasannya.

**Dashboard tidak bisa diakses dari HP/laptop lain**
Pastikan kedua perangkat berada di jaringan Wi-Fi/LAN yang **sama**, dan periksa Windows
Firewall (lihat bagian [Mengakses Dashboard](#mengakses-dashboard-dari-jaringan-sekolah)).

**Jam bel meleset setelah komputer mati listrik/restart**
Scheduler menghitung ulang bel berikutnya dari jam sistem saat aplikasi menyala kembali —
tidak perlu diatur manual. Jika jam **sistem** Windows sendiri yang salah, gunakan tombol
**Sinkronkan Waktu Sistem** di menu System (Windows saja, memerlukan aplikasi dijalankan
sebagai Administrator dan layanan "Windows Time" aktif).

**Lupa password Administrator**
Hentikan aplikasi, hapus (atau pindahkan) berkas database di
`%APPDATA%\School Bell System\data\school-bell.db`, lalu jalankan ulang aplikasi — akun
admin bawaan (`admin`/`admin123`) akan dibuat ulang. **Catatan:** ini menghapus seluruh
jadwal dan pengaturan; sebaiknya restore dari backup terbaru setelahnya (menu System)
jika ada, alih-alih membiarkan database kosong.

---

Dibuat untuk membantu sekolah menjalankan bel otomatis yang bisa diandalkan — tanpa
tempelan jadwal kertas, tanpa harus ada orang yang menekan tombol setiap jam.
