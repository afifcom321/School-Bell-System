'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createBellApp } = require('../server');
const T = require('../server/scheduler/timeUtil');

// Senin, 21 September 2026 pukul HH:MM:SS WIB (UTC+7)
const wib = (hh, mm, ss = 0, date = '2026-09-21') => Date.parse(`${date}T${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}+07:00`);

function spyBackend() {
  const played = [];
  return {
    played,
    name: 'spy',
    play(job) {
      played.push(job);
      return Promise.resolve();
    },
    stop() {},
  };
}

async function makeApp() {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'bell-test-'));
  const backend = spyBackend();
  const app = await createBellApp({ home, audioBackend: backend });
  // mulai dari kondisi bersih: hapus contoh jadwal
  app.store.replaceSchedules([]);
  return { app, backend, home };
}

const sched = (over = {}) => ({
  name: 'Masuk Kelas',
  time: '07:30',
  mode: 'weekly',
  days: [1, 2, 3, 4, 5],
  date: null,
  soundId: null,
  volume: null,
  playSeconds: null,
  enabled: true,
  ...over,
});

const settle = () => new Promise((r) => setImmediate(r));

test('timeUtil: konversi timezone Asia/Jakarta', () => {
  const p = T.partsInTz(wib(7, 30, 15), 'Asia/Jakarta');
  assert.equal(p.date, '2026-09-21');
  assert.equal(p.hhmm, '07:30');
  assert.equal(p.second, 15);
  assert.equal(p.dow, 1); // Senin
  assert.equal(T.zonedToEpoch('2026-09-21', '07:30', 'Asia/Jakarta'), wib(7, 30));
  // Pergantian hari: 23:59 WIB masih tanggal yang sama, 00:00 sudah besok
  assert.equal(T.partsInTz(wib(23, 59, 59), 'Asia/Jakarta').date, '2026-09-21');
  assert.equal(T.partsInTz(wib(0, 0, 0, '2026-09-22'), 'Asia/Jakarta').date, '2026-09-22');
  assert.equal(T.addDays('2026-12-31', 1), '2027-01-01');
  assert.equal(T.dowOfDate('2026-09-27'), 0);
  assert.ok(T.isValidTimeZone('Asia/Makassar'));
  assert.ok(!T.isValidTimeZone('Bukan/Zona'));
});

test('timeUtil: DST (America/New_York) tetap benar', () => {
  // 2026-03-08 02:00 EST → 03:00 EDT
  const e = T.zonedToEpoch('2026-03-15', '07:30', 'America/New_York');
  const p = T.partsInTz(e, 'America/New_York');
  assert.equal(p.hhmm, '07:30');
  assert.equal(p.date, '2026-03-15');
});

test('scheduler: membunyikan tepat pada menitnya dan TIDAK berbunyi dua kali', async () => {
  const { app, backend } = await makeApp();
  const s = app.store.createSchedule(sched());
  const sch = app.scheduler;
  sch.reload();

  sch.now = () => wib(7, 29, 59);
  sch.tick();
  await settle();
  assert.equal(backend.played.length, 0, 'belum waktunya');

  sch.now = () => wib(7, 30, 0);
  sch.tick();
  await settle();
  assert.equal(backend.played.length, 1, 'harus berbunyi pukul 07:30:00');

  // tick berulang di menit yang sama
  for (const sec of [1, 2, 30, 59]) {
    sch.now = () => wib(7, 30, sec);
    sch.tick();
  }
  await settle();
  assert.equal(backend.played.length, 1, 'tidak boleh berbunyi ulang di menit yang sama');

  // penanda tersimpan di database → aman terhadap restart
  assert.equal(app.store.getSchedule(s.id).lastFired, '2026-09-21 07:30');
  await app.shutdown();
});

test('scheduler: restart di menit yang sama tidak membunyikan dobel; restart 07:29 tetap tahu bel berikutnya', async () => {
  const { app, backend, home } = await makeApp();
  app.store.createSchedule(sched());
  app.scheduler.reload();

  // "restart" pukul 07:29 → bel berikutnya harus 07:30 (dihitung dari timestamp)
  const next = app.scheduler.computeNext(wib(7, 29, 5));
  assert.equal(next.time, '07:30');
  assert.equal(next.at, wib(7, 30));

  app.scheduler.now = () => wib(7, 30, 1);
  app.scheduler.tick();
  await settle();
  assert.equal(backend.played.length, 1);
  await app.shutdown();

  // Proses baru (simulasi restart pukul 07:30:20) memakai database yang sama
  const backend2 = spyBackend();
  const app2 = await createBellApp({ home, audioBackend: backend2 });
  app2.scheduler.now = () => wib(7, 30, 20);
  app2.scheduler.tick();
  await settle();
  assert.equal(backend2.played.length, 0, 'sudah berbunyi sebelum restart — tidak boleh dobel');
  await app2.shutdown();
});

test('scheduler: catch-up — aplikasi baru hidup 20 detik setelah jadwal tetap membunyikan bel', async () => {
  const { app, backend } = await makeApp();
  app.store.createSchedule(sched());
  app.scheduler.reload();
  app.scheduler.now = () => wib(7, 30, 20);
  app.scheduler.tick();
  await settle();
  assert.equal(backend.played.length, 1);
  await app.shutdown();
});

test('scheduler: bel yang terlambat melebihi toleransi dicatat "terlewat", tidak dibunyikan', async () => {
  const { app, backend } = await makeApp();
  app.store.createSchedule(sched());
  app.store.setSettings({ catchup_seconds: '30' });
  app.scheduler.reload();
  app.scheduler.lastMin = Math.floor(wib(7, 29, 0) / 60000);
  app.scheduler.now = () => wib(7, 30, 50); // terlambat 50 detik > 30
  app.scheduler.tick();
  await settle();
  assert.equal(backend.played.length, 0);
  const logs = app.store.listLogs({ status: 'missed' });
  assert.equal(logs.total, 1);
  await app.shutdown();
});

test('scheduler: hari, jadwal nonaktif, dan mode tanggal tertentu', async () => {
  const { app, backend } = await makeApp();
  app.store.createSchedule(sched({ name: 'Upacara', time: '07:00', days: [1] })); // hanya Senin
  app.store.createSchedule(sched({ name: 'Nonaktif', time: '07:10', enabled: false }));
  app.store.createSchedule(sched({ name: 'Khusus', time: '07:20', mode: 'date', days: [], date: '2026-09-22' }));
  const sch = app.scheduler;
  sch.reload();

  // Senin 07:00 → berbunyi
  sch.now = () => wib(7, 0, 0);
  sch.tick();
  // Senin 07:10 → nonaktif, tidak berbunyi
  sch.now = () => wib(7, 10, 0);
  sch.tick();
  // Senin 07:20 → jadwal tanggal 22, tidak berbunyi hari ini
  sch.now = () => wib(7, 20, 0);
  sch.tick();
  await settle();
  assert.equal(backend.played.length, 1);
  assert.equal(backend.played[0].filepath.endsWith('.wav'), true);

  // Selasa 22 → jadwal khusus berbunyi, Upacara (hanya Senin) tidak
  sch.now = () => wib(7, 0, 0, '2026-09-22');
  sch.tick();
  sch.now = () => wib(7, 20, 0, '2026-09-22');
  sch.tick();
  await settle();
  assert.equal(backend.played.length, 2);
  await app.shutdown();
});

test('scheduler: mode ujian, jeda, libur, dan saklar nonaktif menahan bel + dicatat', async () => {
  const { app, backend } = await makeApp();
  app.store.createSchedule(sched({ time: '07:30' }));
  app.store.createSchedule(sched({ name: 'B', time: '08:00' }));
  app.store.createSchedule(sched({ name: 'C', time: '08:30' }));
  app.store.createSchedule(sched({ name: 'D', time: '09:00' }));
  const sch = app.scheduler;

  app.store.setSettings({ exam_mode: '1', exam_until: '' });
  sch.reload();
  sch.now = () => wib(7, 30, 0);
  sch.tick();
  assert.equal(sch.computeNext(wib(7, 0, 0)), null, 'mode ujian tanpa batas → tidak ada bel berikutnya');

  app.store.setSettings({ exam_mode: '0', pause_until: String(wib(8, 15)) });
  sch.reload();
  sch.now = () => wib(8, 0, 0);
  sch.tick();
  assert.equal(sch.computeNext(wib(7, 59)).time, '08:30', 'jeda sampai 08:15 → berikutnya 08:30');

  app.store.setSettings({ pause_until: '', holidays: JSON.stringify([{ start: '2026-09-21', end: '2026-09-21', name: 'Libur Uji' }]) });
  sch.reload();
  sch.now = () => wib(8, 30, 0);
  sch.tick();
  assert.equal(sch.computeNext(wib(8, 0)).date, '2026-09-22', 'hari libur dilewati');

  app.store.setSettings({ holidays: '[]', scheduler_enabled: '0' });
  sch.reload();
  sch.now = () => wib(9, 0, 0);
  sch.tick();

  await settle();
  assert.equal(backend.played.length, 0, 'tidak ada bel yang boleh berbunyi');
  assert.equal(app.store.listLogs({ status: 'skipped' }).total, 4, 'keempatnya dicatat sebagai dilewati');
  await app.shutdown();
});

test('scheduler: kegagalan memutar suara dicatat dan jadwal berikutnya tetap jalan', async () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'bell-test-'));
  let calls = 0;
  const flaky = {
    name: 'flaky',
    play() {
      calls++;
      return calls === 1 ? Promise.reject(new Error('speaker rusak')) : Promise.resolve();
    },
    stop() {},
  };
  const app = await createBellApp({ home, audioBackend: flaky });
  app.store.replaceSchedules([]);
  app.store.createSchedule(sched({ time: '07:30' }));
  app.store.createSchedule(sched({ name: 'Kedua', time: '07:31' }));
  const problems = [];
  app.on('problem', (p) => problems.push(p));
  const sch = app.scheduler;
  sch.reload();

  sch.now = () => wib(7, 30, 0);
  sch.tick();
  await new Promise((r) => setTimeout(r, 30));
  assert.ok(app.store.listLogs({ status: 'error' }).total >= 1, 'error tercatat di log');
  assert.ok(problems.length >= 1, 'event problem dipancarkan (notifikasi)');
  assert.equal(app.buildStatus().bell.lastError.message, 'speaker rusak', 'status menampilkan error terakhir');

  sch.now = () => wib(7, 31, 0);
  sch.tick();
  await new Promise((r) => setTimeout(r, 30));
  assert.equal(calls, 2, 'jadwal kedua tetap dijalankan setelah kegagalan');
  assert.equal(app.buildStatus().bell.lastError, null, 'error hilang setelah pemutaran berikutnya berhasil');
  await app.shutdown();
});

test('scheduler: tetap berjalan dengan data cache saat database bermasalah', async () => {
  const { app, backend } = await makeApp();
  app.store.createSchedule(sched());
  const sch = app.scheduler;
  sch.reload();
  app.store.db.close(); // simulasi database rusak/terkunci

  sch.now = () => wib(7, 30, 0);
  sch.loadedAt = 0; // paksa scheduler mencoba memuat ulang (di produksi terjadi tiap 30 detik)
  assert.doesNotThrow(() => sch.tick());
  await settle();
  assert.equal(backend.played.length, 1, 'bel tetap berbunyi memakai cache');
  assert.ok(sch.cacheError, 'error database tercatat');
  assert.equal(app.buildStatus().db.ok, false);
  await app.shutdown();
});

test('scheduler: preview tanggal & simulasi test', async () => {
  const { app } = await makeApp();
  app.store.createSchedule(sched({ time: '07:30' }));
  app.store.setSettings({ holidays: JSON.stringify([{ start: '2026-09-23', end: '2026-09-23', name: 'Libur' }]) });
  app.scheduler.reload();
  const p = app.scheduler.preview('2026-09-23');
  assert.equal(p.holiday, 'Libur');
  assert.equal(p.items[0].willRing, false);
  const t = app.scheduler.testAt('2026-09-24', '07:30');
  assert.equal(t.matches.length, 1);
  assert.equal(t.suppressed, null);
  const sun = app.scheduler.testAt('2026-09-27', '07:30');
  assert.equal(sun.matches.length, 0, 'Minggu tidak ada bel');
  await app.shutdown();
});
