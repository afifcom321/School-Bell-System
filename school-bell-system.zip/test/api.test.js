'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createBellApp } = require('../server');
const { createNullBackend } = require('../server/audio/audioManager');

const PORT = 3400 + Math.floor(Math.random() * 400);
const BASE = `http://127.0.0.1:${PORT}`;
const WAV = fs.readFileSync(path.join(__dirname, '..', 'default-sounds', 'bell.wav'));

/** Klien HTTP kecil dengan cookie jar */
function client() {
  let cookie = '';
  const call = async (method, url, body, headers = {}) => {
    const init = { method, headers: { ...headers } };
    if (cookie) init.headers.Cookie = cookie;
    if (body instanceof FormData) init.body = body;
    else if (body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(body);
    }
    const res = await fetch(BASE + url, init);
    const set = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    if (set.length) cookie = set[0].split(';')[0].endsWith('=') ? '' : set[0].split(';')[0];
    let json = null;
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('application/json')) json = await res.json();
    return { status: res.status, json, res };
  };
  return {
    get: (u, h) => call('GET', u, undefined, h),
    post: (u, b, h) => call('POST', u, b === undefined ? {} : b, h),
    put: (u, b) => call('PUT', u, b),
    patch: (u, b) => call('PATCH', u, b),
    del: (u) => call('DELETE', u),
    upload: (u, buf, name, type) => {
      const fd = new FormData();
      fd.append('file', new Blob([buf], { type }), name);
      return call('POST', u, fd);
    },
  };
}

let app;
let home;
const admin = client();
const viewer = client();

test.before(async () => {
  home = fs.mkdtempSync(path.join(os.tmpdir(), 'bell-api-'));
  app = await createBellApp({ home, audioBackend: createNullBackend(), config: { port: PORT, host: '127.0.0.1' } });
  const info = await app.startServer();
  assert.ok(info.running, `server harus berjalan: ${info.error}`);
  app.startScheduler();
});
test.after(async () => {
  await app.shutdown();
});

test('publik: /api/health terbuka, endpoint lain wajib login', async () => {
  const c = client();
  assert.equal((await c.get('/api/health')).status, 200);
  for (const url of ['/api/status', '/api/schedules', '/api/sounds', '/api/logs', '/api/settings', '/api/system']) {
    assert.equal((await c.get(url)).status, 401, `${url} harus 401 tanpa login`);
  }
  for (const [m, url] of [['post', '/api/bell/trigger'], ['post', '/api/schedules'], ['post', '/api/sounds/upload'], ['put', '/api/settings'], ['post', '/api/scheduler/toggle']]) {
    assert.equal((await c[m](url, {})).status, 401, `${url} harus 401`);
  }
});

test('login: password salah ditolak; login awal memaksa ganti password', async () => {
  assert.equal((await client().post('/api/auth/login', { username: 'admin', password: 'salah' })).status, 401);

  const r = await admin.post('/api/auth/login', { username: 'admin', password: 'admin123' });
  assert.equal(r.status, 200);
  assert.equal(r.json.user.role, 'admin');
  assert.equal(r.json.user.mustChangePassword, true);
  assert.match(r.res.headers.get('set-cookie'), /HttpOnly/);

  const blocked = await admin.get('/api/status');
  assert.equal(blocked.status, 403);
  assert.equal(blocked.json.code, 'PASSWORD_CHANGE_REQUIRED');

  assert.equal((await admin.post('/api/auth/change-password', { currentPassword: 'admin123', newPassword: 'admin123' })).status, 400);
  assert.equal((await admin.post('/api/auth/change-password', { currentPassword: 'admin123', newPassword: '123' })).status, 400);
  assert.equal((await admin.post('/api/auth/change-password', { currentPassword: 'salah', newPassword: 'sekolah2026' })).status, 400);
  assert.equal((await admin.post('/api/auth/change-password', { currentPassword: 'admin123', newPassword: 'sekolah2026' })).status, 200);
  assert.equal((await admin.get('/api/status')).status, 200);
});

test('password disimpan sebagai hash scrypt (bukan plaintext)', () => {
  const u = app.store.getUserByUsername('admin');
  assert.match(u.passwordHash, /^scrypt\$/);
  assert.ok(!u.passwordHash.includes('sekolah2026'));
});

test('role: Viewer hanya boleh melihat', async () => {
  const cr = await admin.post('/api/auth/users', { username: 'guru1', password: 'guru12345', role: 'viewer' });
  assert.equal(cr.status, 201);
  assert.equal((await viewer.post('/api/auth/login', { username: 'guru1', password: 'guru12345' })).status, 200);

  assert.equal((await viewer.get('/api/status')).status, 200);
  assert.equal((await viewer.get('/api/schedules')).status, 200);
  assert.equal((await viewer.get('/api/logs')).status, 200);
  assert.equal((await viewer.get('/api/system')).json.paths, null, 'viewer tidak melihat path server');

  assert.equal((await viewer.post('/api/bell/trigger', {})).status, 403);
  assert.equal((await viewer.post('/api/bell/stop', {})).status, 403);
  assert.equal((await viewer.post('/api/schedules', { name: 'x', time: '07:00', days: [1] })).status, 403);
  assert.equal((await viewer.put('/api/settings', { masterVolume: 10 })).status, 403);
  assert.equal((await viewer.post('/api/scheduler/toggle', { enabled: false })).status, 403);
  assert.equal((await viewer.get('/api/auth/users')).status, 403);
  assert.equal((await viewer.get('/api/system/backups/download')).status, 403);
  // simulasi (dry-run) boleh untuk viewer
  assert.equal((await viewer.post('/api/scheduler/test', { date: '2026-09-21', time: '07:30' })).status, 200);
});

test('user: tidak bisa menghapus diri sendiri / admin terakhir', async () => {
  const me = (await admin.get('/api/auth/me')).json.user;
  assert.equal((await admin.del(`/api/auth/users/${me.id}`)).status, 400);
  assert.equal((await admin.put(`/api/auth/users/${me.id}`, { role: 'viewer' })).status, 400);
});

test('jadwal: CRUD, validasi, toggle, export/import', async () => {
  const list = (await admin.get('/api/schedules')).json.schedules;
  assert.ok(list.length >= 6, 'contoh jadwal awal ada');

  assert.equal((await admin.post('/api/schedules', { name: '', time: '07:00', days: [1] })).status, 400);
  assert.equal((await admin.post('/api/schedules', { name: 'X', time: '25:00', days: [1] })).status, 400);
  assert.equal((await admin.post('/api/schedules', { name: 'X', time: '07:00', days: [] })).status, 400);
  assert.equal((await admin.post('/api/schedules', { name: 'X', time: '07:00', mode: 'date', date: '2026-13-40' })).status, 400);
  assert.equal((await admin.post('/api/schedules', { name: 'X', time: '07:00', days: [1], soundId: 9999 })).status, 400);
  assert.equal((await admin.post('/api/schedules', { name: 'X', time: '07:00', days: [1], volume: 500 })).status, 400);

  const cr = await admin.post('/api/schedules', { name: 'Bel Uji', time: '10:15', days: [6, 0] });
  assert.equal(cr.status, 201);
  const id = cr.json.schedule.id;
  assert.deepEqual(cr.json.schedule.days, [0, 6]);

  const up = await admin.put(`/api/schedules/${id}`, { name: 'Bel Uji 2', time: '10:20', mode: 'date', date: '2026-10-01', enabled: true });
  assert.equal(up.json.schedule.mode, 'date');
  assert.equal(up.json.schedule.date, '2026-10-01');

  assert.equal((await admin.patch(`/api/schedules/${id}/enabled`, { enabled: false })).json.schedule.enabled, false);
  assert.equal((await admin.get('/api/schedules/preview?date=2026-10-01')).json.items.some((i) => i.id === id), true);
  assert.equal((await admin.get('/api/schedules/preview?date=bukan')).status, 400);

  const exp = await admin.get('/api/schedules/export');
  assert.equal(exp.json.format, 'school-bell-schedules');
  const before = (await admin.get('/api/schedules')).json.schedules.length;
  assert.equal((await admin.post('/api/schedules/import', { mode: 'append', schedules: exp.json.schedules })).status, 200);
  assert.equal((await admin.get('/api/schedules')).json.schedules.length, before * 2);
  assert.equal((await admin.post('/api/schedules/import', { mode: 'replace', schedules: exp.json.schedules })).status, 200);
  assert.equal((await admin.get('/api/schedules')).json.schedules.length, before);
  assert.equal((await admin.post('/api/schedules/import', { schedules: [{ name: 'Rusak', time: '99:99', days: [1] }] })).status, 400);

  assert.equal((await admin.del(`/api/schedules/${id}`)).status, 404, 'id lama sudah hilang setelah impor replace');
});

test('sound: upload valid, validasi ketat, anti path traversal', async () => {
  // valid
  const ok = await admin.upload('/api/sounds/upload', WAV, 'Bel Baru.wav', 'audio/wav');
  assert.equal(ok.status, 201, JSON.stringify(ok.json));
  assert.ok(ok.json.sound.duration > 3, 'durasi terbaca');
  const soundId = ok.json.sound.id;

  // ekstensi terlarang
  assert.equal((await admin.upload('/api/sounds/upload', WAV, 'virus.exe', 'audio/wav')).status, 400);
  assert.equal((await admin.upload('/api/sounds/upload', Buffer.from('<script>alert(1)</script>'), 'x.html', 'text/html')).status, 400);
  // ekstensi .mp3 tetapi isi WAV → ditolak (signature)
  assert.equal((await admin.upload('/api/sounds/upload', WAV, 'palsu.mp3', 'audio/mpeg')).status, 400);
  // isi bukan audio walau ekstensi & MIME benar
  assert.equal((await admin.upload('/api/sounds/upload', Buffer.from('MZ\x90\x00 ini bukan audio sama sekali!!'), 'x.wav', 'audio/wav')).status, 400);
  // MIME tidak cocok dengan ekstensi
  assert.equal((await admin.upload('/api/sounds/upload', WAV, 'x.wav', 'text/plain')).status, 400);
  // melebihi batas ukuran
  const big = Buffer.concat([WAV.subarray(0, 44), Buffer.alloc(21 * 1024 * 1024)]);
  assert.equal((await admin.upload('/api/sounds/upload', big, 'besar.wav', 'audio/wav')).status, 413);

  // path traversal pada nama berkas: nama akhir selalu aman dan berada di folder sounds
  const trav = await admin.upload('/api/sounds/upload', WAV, '../../../../etc/evil.wav', 'audio/wav');
  assert.equal(trav.status, 201);
  const row = app.store.getSound(trav.json.sound.id);
  assert.match(row.filename, /^[a-z0-9_-]+-[0-9a-f]{6}\.wav$/);
  assert.ok(fs.existsSync(path.join(home, 'sounds', row.filename)));
  assert.ok(!fs.existsSync(path.join(home, '..', 'evil.wav')));
  assert.ok(!fs.existsSync('/etc/evil.wav'));

  // stream file untuk preview
  const file = await admin.get(`/api/sounds/${soundId}/file`);
  assert.equal(file.status, 200);
  assert.equal(file.res.headers.get('content-type'), 'audio/wav');
  assert.equal((await client().get(`/api/sounds/${soundId}/file`)).status, 401);

  // ubah pengaturan sound
  const up = await admin.put(`/api/sounds/${soundId}`, { name: 'Bel Baru', volume: 70, maxPlaySeconds: 3 });
  assert.equal(up.json.sound.volume, 70);
  assert.equal(up.json.sound.maxPlaySeconds, 3);
  assert.equal((await admin.put(`/api/sounds/${soundId}`, { volume: 150 })).status, 400);

  // pakai di jadwal lalu hapus sound → jadwal tetap ada (memakai default)
  const sc = await admin.post('/api/schedules', { name: 'Pakai Sound', time: '11:11', days: [1], soundId });
  assert.equal(sc.json.schedule.soundId, soundId);
  const del = await admin.del(`/api/sounds/${soundId}`);
  assert.equal(del.json.affectedSchedules, 1);
  assert.equal((await admin.get('/api/schedules')).json.schedules.find((s) => s.id === sc.json.schedule.id).soundId, null);
  assert.ok(!fs.existsSync(path.join(home, 'sounds', ok.json.sound.filename)), 'file ikut terhapus dari disk');
});

test('bel manual: trigger, status "berbunyi", stop, dan tercatat di log', async () => {
  const r = await admin.post('/api/bell/trigger', {});
  assert.equal(r.status, 200);
  const st = (await admin.get('/api/status')).json;
  assert.equal(st.bell.ringing, true, 'UI harus melihat status "Bel sedang berbunyi"');
  assert.match(st.bell.current.name, /Bel manual/);
  await admin.post('/api/bell/stop', {});
  await new Promise((r2) => setTimeout(r2, 100));
  assert.equal((await admin.get('/api/status')).json.bell.ringing, false, 'kembali normal');

  assert.equal((await admin.post('/api/bell/trigger', { soundId: 99999 })).status, 500, 'sound tidak ada → error jelas');
  assert.equal((await admin.post('/api/bell/trigger', { volume: 500 })).status, 400);

  const logs = (await admin.get('/api/logs?limit=50')).json.rows.map((l) => l.event).join('\n');
  assert.match(logs, /Bel manual dibunyikan oleh admin/);
});

test('kontrol scheduler: toggle, jeda, mode ujian tercermin di status', async () => {
  await admin.post('/api/scheduler/toggle', { enabled: false });
  let st = (await admin.get('/api/status')).json;
  assert.equal(st.autoBell.active, false);
  assert.equal(st.autoBell.reason, 'disabled');
  assert.equal(st.next, null);
  await admin.post('/api/scheduler/toggle', { enabled: true });

  await admin.post('/api/scheduler/pause', { minutes: 30 });
  st = (await admin.get('/api/status')).json;
  assert.equal(st.autoBell.reason, 'paused');
  assert.ok(st.pause.until > Date.now());
  await admin.post('/api/scheduler/pause', { clear: true });

  await admin.post('/api/scheduler/exam', { enabled: true });
  assert.equal((await admin.get('/api/status')).json.autoBell.reason, 'exam');
  await admin.post('/api/scheduler/exam', { enabled: false });
  st = (await admin.get('/api/status')).json;
  assert.equal(st.autoBell.active, true);
  assert.ok(st.next, 'ada bel berikutnya');
  assert.equal((await admin.post('/api/scheduler/pause', { minutes: -5 })).status, 400);
});

test('pengaturan: validasi timezone, format jam, volume master, libur', async () => {
  assert.equal((await admin.put('/api/settings', { timezone: 'Mars/Olympus' })).status, 400);
  assert.equal((await admin.put('/api/settings', { timeFormat: '13' })).status, 400);
  assert.equal((await admin.put('/api/settings', { masterVolume: 101 })).status, 400);
  assert.equal((await admin.put('/api/settings', { holidays: [{ start: '2026-12-31', end: '2026-12-01', name: 'x' }] })).status, 400);
  assert.equal((await admin.put('/api/settings', { timezone: 'Asia/Makassar', timeFormat: '12', masterVolume: 60, holidays: [{ start: '2026-12-24', end: '2026-12-31', name: 'Libur Semester' }] })).status, 200);
  const s = (await admin.get('/api/settings')).json.settings;
  assert.equal(s.timezone, 'Asia/Makassar');
  assert.equal(s.timeFormat, '12');
  assert.equal(s.masterVolume, 60);
  assert.equal(s.holidays[0].name, 'Libur Semester');
  const st = (await admin.get('/api/status')).json;
  assert.equal(st.server.timezone, 'Asia/Makassar');
  await admin.put('/api/settings', { timezone: 'Asia/Jakarta', timeFormat: '24', masterVolume: 80, holidays: [] });
});

test('backup & restore database', async () => {
  const c = await admin.post('/api/system/backups', {});
  assert.equal(c.status, 201);
  const dl = await admin.get('/api/system/backups/download');
  assert.equal(dl.status, 200);
  const buf = Buffer.from(await dl.res.arrayBuffer());
  assert.equal(buf.toString('latin1', 0, 15), 'SQLite format 3');

  // ubah data, lalu restore backup → data kembali
  const before = (await admin.get('/api/schedules')).json.schedules.length;
  await admin.post('/api/schedules', { name: 'Sementara', time: '05:05', days: [1] });
  assert.equal((await admin.get('/api/schedules')).json.schedules.length, before + 1);

  assert.equal((await admin.upload('/api/system/restore', Buffer.from('bukan database'), 'x.db', 'application/octet-stream')).status, 400);
  const rs = await admin.upload('/api/system/restore', buf, 'backup.db', 'application/octet-stream');
  assert.equal(rs.status, 200, JSON.stringify(rs.json));

  // sesi ikut ter-restore dari backup → login ulang
  await admin.post('/api/auth/login', { username: 'admin', password: 'sekolah2026' });
  assert.equal((await admin.get('/api/schedules')).json.schedules.length, before);
  assert.ok(app.store.listBackups().some((b) => b.name.includes('pre-restore')), 'database lama diamankan sebelum restore');
});

test('keamanan: Origin asing ditolak (CSRF), nama backup tak valid ditolak, header keamanan ada', async () => {
  const r = await admin.post('/api/bell/trigger', {}, { Origin: 'http://evil.example.com' });
  assert.equal(r.status, 403);
  assert.equal((await admin.get('/api/system/backups/file/..%2F..%2Fetc%2Fpasswd')).status, 400);
  const page = await fetch(BASE + '/');
  assert.equal(page.headers.get('x-content-type-options'), 'nosniff');
  assert.match(page.headers.get('content-security-policy'), /default-src 'self'/);
});

test('SSE: dashboard menerima status realtime', async () => {
  const ac = new AbortController();
  const res = await fetch(BASE + '/api/events', { headers: { Cookie: await cookieOf(admin) }, signal: ac.signal });
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type'), /text\/event-stream/);
  const reader = res.body.getReader();
  const { value } = await reader.read();
  ac.abort();
  assert.match(Buffer.from(value).toString(), /retry:/);
});

async function cookieOf(cl) {
  // ambil cookie dengan login ulang pada klien terpisah (jar internal tidak diekspos)
  const c = client();
  const r = await c.post('/api/auth/login', { username: 'admin', password: 'sekolah2026' });
  return r.res.headers.get('set-cookie').split(';')[0];
}

test('login: dikunci sementara setelah 5 kali gagal', async () => {
  const c = client();
  let last;
  for (let i = 0; i < 6; i++) last = await c.post('/api/auth/login', { username: 'admin', password: 'ngawur' + i });
  assert.equal(last.status, 429);
  assert.ok(last.res.headers.get('retry-after'));
  // bahkan password benar ditolak selama terkunci
  assert.equal((await c.post('/api/auth/login', { username: 'admin', password: 'sekolah2026' })).status, 429);
});
