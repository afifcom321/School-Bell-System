'use strict';
/**
 * Skema database. Setiap elemen MIGRATIONS dijalankan sekali (dilacak lewat PRAGMA user_version).
 * Untuk perubahan skema di masa depan, TAMBAHKAN fungsi baru di akhir array — jangan ubah yang lama.
 *
 * Catatan desain:
 *  - File audio TIDAK disimpan di database. Tabel `sounds` hanya menyimpan metadata + path relatif
 *    (mis. "sounds/bell.wav") terhadap folder kerja aplikasi.
 *  - Hari: 0 = Minggu, 1 = Senin, … 6 = Sabtu. Kolom `days` berisi CSV, mis. "1,2,3,4,5".
 */
const MIGRATIONS = [
  // ---------------------------------------------------------------- v1
  (db) => {
    db.exec(`
      CREATE TABLE sounds (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        name             TEXT    NOT NULL,
        filename         TEXT    NOT NULL UNIQUE,
        filepath         TEXT    NOT NULL,             -- relatif terhadap folder kerja, mis. sounds/bell.wav
        mime             TEXT,
        size             INTEGER,
        volume           INTEGER NOT NULL DEFAULT 100, -- 0..100 (volume dasar sound ini)
        duration         REAL,                         -- detik (durasi asli file)
        max_play_seconds INTEGER,                      -- batas durasi putar (NULL = putar sampai selesai)
        is_builtin       INTEGER NOT NULL DEFAULT 0,
        created_at       TEXT    NOT NULL
      );

      CREATE TABLE schedules (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT    NOT NULL,
        time        TEXT    NOT NULL,                  -- 'HH:MM' (24 jam)
        mode        TEXT    NOT NULL DEFAULT 'weekly', -- 'weekly' = berulang tiap minggu, 'date' = tanggal tertentu
        days        TEXT    NOT NULL DEFAULT '1,2,3,4,5',
        date        TEXT,                              -- 'YYYY-MM-DD' (hanya untuk mode 'date')
        sound_id    INTEGER REFERENCES sounds(id) ON DELETE SET NULL,
        volume      INTEGER,                           -- override volume (NULL = pakai volume sound)
        play_seconds INTEGER,                          -- override durasi maksimum (NULL = pakai pengaturan sound)
        enabled     INTEGER NOT NULL DEFAULT 1,
        last_fired  TEXT,                              -- 'YYYY-MM-DD HH:MM' terakhir kali diproses (anti dobel bunyi)
        created_at  TEXT    NOT NULL,
        updated_at  TEXT    NOT NULL
      );
      CREATE INDEX idx_schedules_time ON schedules(time);

      CREATE TABLE settings (
        id    INTEGER PRIMARY KEY AUTOINCREMENT,
        key   TEXT NOT NULL UNIQUE,
        value TEXT
      );

      CREATE TABLE logs (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        event       TEXT    NOT NULL,
        schedule_id INTEGER,
        timestamp   INTEGER NOT NULL,                  -- epoch milidetik
        status      TEXT    NOT NULL DEFAULT 'ok',     -- ok | info | warning | error | skipped | missed
        source      TEXT,                              -- scheduler | manual | system | auth | admin
        detail      TEXT
      );
      CREATE INDEX idx_logs_timestamp ON logs(timestamp DESC);

      CREATE TABLE users (
        id                   INTEGER PRIMARY KEY AUTOINCREMENT,
        username             TEXT    NOT NULL UNIQUE COLLATE NOCASE,
        password_hash        TEXT    NOT NULL,         -- scrypt (bukan plaintext)
        role                 TEXT    NOT NULL DEFAULT 'viewer', -- admin | viewer
        must_change_password INTEGER NOT NULL DEFAULT 0,
        created_at           TEXT    NOT NULL
      );

      CREATE TABLE sessions (
        token_hash TEXT PRIMARY KEY,                   -- SHA-256 dari token cookie
        user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        ip         TEXT
      );
      CREATE INDEX idx_sessions_expires ON sessions(expires_at);
    `);
  },
];

/** Nilai awal pengaturan (hanya dimasukkan jika key belum ada) */
const DEFAULT_SETTINGS = {
  school_name: 'Sekolah Kita',
  timezone: 'Asia/Jakarta',
  time_format: '24', // '24' | '12'
  master_volume: '80', // 0..100
  scheduler_enabled: '1', // saklar jadwal otomatis
  default_sound_id: '',
  exam_mode: '0',
  exam_until: '', // epoch ms; kosong = sampai dimatikan manual
  pause_until: '', // epoch ms; jeda sementara
  holidays: '[]', // JSON: [{ start:'YYYY-MM-DD', end:'YYYY-MM-DD', name:'…' }]
  catchup_seconds: '120', // toleransi keterlambatan bel (mis. setelah komputer "hang")
  test_sound_seconds: '4', // durasi "Test Sound"
  log_retention_days: '90',
  auto_backup: '1', // backup otomatis harian
};

module.exports = { MIGRATIONS, DEFAULT_SETTINGS };
