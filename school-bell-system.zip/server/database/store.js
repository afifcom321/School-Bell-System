'use strict';
const fs = require('fs');
const path = require('path');
const { openDatabase, openAndMigrate, verifyBackupFile, removeSidecars } = require('./connection');
const { DEFAULT_SETTINGS } = require('./schema');

const nowIso = () => new Date().toISOString();
/** node:sqlite tidak menerima undefined/boolean → normalisasi */
const v = (x) => (x === undefined ? null : typeof x === 'boolean' ? (x ? 1 : 0) : x);

class Store {
  constructor(paths, logger) {
    this.paths = paths;
    this.logger = logger;
    this.db = null;
    this.recovered = null;
  }

  open() {
    const { db, recovered } = openDatabase(this.paths, this.logger);
    this.db = db;
    this.recovered = recovered;
    this.seedSettings();
    return this;
  }

  close() {
    try {
      this.db && this.db.close();
    } catch {
      /* abaikan */
    }
    this.db = null;
  }

  tx(fn) {
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const out = fn();
      this.db.exec('COMMIT');
      return out;
    } catch (err) {
      try {
        this.db.exec('ROLLBACK');
      } catch {
        /* abaikan */
      }
      throw err;
    }
  }

  // ------------------------------------------------------------- settings
  seedSettings() {
    const stmt = this.db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
    for (const [k, val] of Object.entries(DEFAULT_SETTINGS)) stmt.run(k, val);
  }

  getSettings() {
    const out = {};
    for (const row of this.db.prepare('SELECT key, value FROM settings').all()) out[row.key] = row.value;
    return out;
  }

  setSettings(obj) {
    const stmt = this.db.prepare(
      'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
    );
    this.tx(() => {
      for (const [k, val] of Object.entries(obj)) stmt.run(k, String(val ?? ''));
    });
  }

  // ------------------------------------------------------------ schedules
  static mapSchedule(r) {
    if (!r) return null;
    return {
      id: r.id,
      name: r.name,
      time: r.time,
      mode: r.mode,
      days: r.days ? r.days.split(',').filter((x) => x !== '').map(Number) : [],
      date: r.date || null,
      soundId: r.sound_id ?? null,
      volume: r.volume ?? null,
      playSeconds: r.play_seconds ?? null,
      enabled: !!r.enabled,
      lastFired: r.last_fired || null,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    };
  }

  listSchedules() {
    return this.db
      .prepare('SELECT * FROM schedules ORDER BY time ASC, id ASC')
      .all()
      .map(Store.mapSchedule);
  }

  getSchedule(id) {
    return Store.mapSchedule(this.db.prepare('SELECT * FROM schedules WHERE id = ?').get(id));
  }

  createSchedule(d) {
    const ts = nowIso();
    const info = this.db
      .prepare(
        `INSERT INTO schedules (name, time, mode, days, date, sound_id, volume, play_seconds, enabled, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(d.name, d.time, d.mode, d.days.join(','), v(d.date), v(d.soundId), v(d.volume), v(d.playSeconds), v(d.enabled), ts, ts);
    return this.getSchedule(Number(info.lastInsertRowid));
  }

  updateSchedule(id, d) {
    const info = this.db
      .prepare(
        `UPDATE schedules SET name = ?, time = ?, mode = ?, days = ?, date = ?, sound_id = ?, volume = ?,
           play_seconds = ?, enabled = ?, last_fired = NULL, updated_at = ? WHERE id = ?`
      )
      .run(d.name, d.time, d.mode, d.days.join(','), v(d.date), v(d.soundId), v(d.volume), v(d.playSeconds), v(d.enabled), nowIso(), id);
    return info.changes ? this.getSchedule(id) : null;
  }

  setScheduleEnabled(id, enabled) {
    const info = this.db
      .prepare('UPDATE schedules SET enabled = ?, updated_at = ? WHERE id = ?')
      .run(enabled ? 1 : 0, nowIso(), id);
    return info.changes ? this.getSchedule(id) : null;
  }

  deleteSchedule(id) {
    return this.db.prepare('DELETE FROM schedules WHERE id = ?').run(id).changes > 0;
  }

  markFired(id, key) {
    this.db.prepare('UPDATE schedules SET last_fired = ? WHERE id = ?').run(key, id);
  }

  replaceSchedules(list) {
    return this.tx(() => {
      this.db.exec('DELETE FROM schedules');
      return list.map((d) => this.createSchedule(d));
    });
  }

  // --------------------------------------------------------------- sounds
  static mapSound(r) {
    if (!r) return null;
    return {
      id: r.id,
      name: r.name,
      filename: r.filename,
      filepath: r.filepath,
      mime: r.mime,
      size: r.size,
      volume: r.volume,
      duration: r.duration,
      maxPlaySeconds: r.max_play_seconds ?? null,
      isBuiltin: !!r.is_builtin,
      createdAt: r.created_at,
    };
  }

  listSounds() {
    return this.db.prepare('SELECT * FROM sounds ORDER BY name COLLATE NOCASE ASC').all().map(Store.mapSound);
  }

  getSound(id) {
    return Store.mapSound(this.db.prepare('SELECT * FROM sounds WHERE id = ?').get(id));
  }

  getSoundByFilename(filename) {
    return Store.mapSound(this.db.prepare('SELECT * FROM sounds WHERE filename = ?').get(filename));
  }

  createSound(d) {
    const info = this.db
      .prepare(
        `INSERT INTO sounds (name, filename, filepath, mime, size, volume, duration, max_play_seconds, is_builtin, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(d.name, d.filename, d.filepath, v(d.mime), v(d.size), v(d.volume ?? 100), v(d.duration), v(d.maxPlaySeconds), v(d.isBuiltin), nowIso());
    return this.getSound(Number(info.lastInsertRowid));
  }

  updateSound(id, d) {
    const info = this.db
      .prepare('UPDATE sounds SET name = ?, volume = ?, max_play_seconds = ? WHERE id = ?')
      .run(d.name, d.volume, v(d.maxPlaySeconds), id);
    return info.changes ? this.getSound(id) : null;
  }

  updateSoundDuration(id, duration) {
    this.db.prepare('UPDATE sounds SET duration = ? WHERE id = ?').run(duration, id);
  }

  deleteSound(id) {
    return this.db.prepare('DELETE FROM sounds WHERE id = ?').run(id).changes > 0;
  }

  countSchedulesUsingSound(id) {
    return this.db.prepare('SELECT COUNT(*) AS c FROM schedules WHERE sound_id = ?').get(id).c;
  }

  // ----------------------------------------------------------------- logs
  addLog(e) {
    const info = this.db
      .prepare('INSERT INTO logs (event, schedule_id, timestamp, status, source, detail) VALUES (?, ?, ?, ?, ?, ?)')
      .run(e.event, v(e.scheduleId), e.timestamp, e.status, v(e.source), v(e.detail));
    return Number(info.lastInsertRowid);
  }

  listLogs({ limit = 100, offset = 0, status } = {}) {
    limit = Math.min(Math.max(Number(limit) || 100, 1), 500);
    offset = Math.max(Number(offset) || 0, 0);
    const where = status ? 'WHERE status = ?' : '';
    const args = status ? [status] : [];
    const rows = this.db
      .prepare(`SELECT * FROM logs ${where} ORDER BY timestamp DESC, id DESC LIMIT ? OFFSET ?`)
      .all(...args, limit, offset)
      .map((r) => ({
        id: r.id,
        event: r.event,
        scheduleId: r.schedule_id,
        timestamp: r.timestamp,
        status: r.status,
        source: r.source,
        detail: r.detail,
      }));
    const total = this.db.prepare(`SELECT COUNT(*) AS c FROM logs ${where}`).get(...args).c;
    return { rows, total };
  }

  pruneLogs(days) {
    const cutoff = Date.now() - days * 86400000;
    return this.db.prepare('DELETE FROM logs WHERE timestamp < ?').run(cutoff).changes;
  }

  clearLogs() {
    return this.db.prepare('DELETE FROM logs').run().changes;
  }

  // ---------------------------------------------------------------- users
  static mapUser(r) {
    if (!r) return null;
    return {
      id: r.id,
      username: r.username,
      role: r.role,
      mustChangePassword: !!r.must_change_password,
      createdAt: r.created_at,
      passwordHash: r.password_hash,
    };
  }

  countUsers() {
    return this.db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  }

  countAdmins() {
    return this.db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'admin'").get().c;
  }

  listUsers() {
    return this.db
      .prepare('SELECT * FROM users ORDER BY username COLLATE NOCASE')
      .all()
      .map(Store.mapUser)
      .map(({ passwordHash, ...rest }) => rest);
  }

  getUser(id) {
    return Store.mapUser(this.db.prepare('SELECT * FROM users WHERE id = ?').get(id));
  }

  getUserByUsername(username) {
    return Store.mapUser(this.db.prepare('SELECT * FROM users WHERE username = ?').get(username));
  }

  createUser({ username, passwordHash, role, mustChangePassword }) {
    const info = this.db
      .prepare('INSERT INTO users (username, password_hash, role, must_change_password, created_at) VALUES (?, ?, ?, ?, ?)')
      .run(username, passwordHash, role, mustChangePassword ? 1 : 0, nowIso());
    return this.getUser(Number(info.lastInsertRowid));
  }

  updateUser(id, { role, passwordHash, mustChangePassword }) {
    const u = this.getUser(id);
    if (!u) return null;
    this.db
      .prepare('UPDATE users SET role = ?, password_hash = ?, must_change_password = ? WHERE id = ?')
      .run(role ?? u.role, passwordHash ?? u.passwordHash, mustChangePassword === undefined ? (u.mustChangePassword ? 1 : 0) : mustChangePassword ? 1 : 0, id);
    return this.getUser(id);
  }

  deleteUser(id) {
    return this.db.prepare('DELETE FROM users WHERE id = ?').run(id).changes > 0;
  }

  // ------------------------------------------------------------- sessions
  createSession(tokenHash, userId, expiresAt, ip) {
    this.db
      .prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at, ip) VALUES (?, ?, ?, ?, ?)')
      .run(tokenHash, userId, Date.now(), expiresAt, v(ip));
  }

  getSession(tokenHash) {
    return this.db.prepare('SELECT * FROM sessions WHERE token_hash = ?').get(tokenHash);
  }

  extendSession(tokenHash, expiresAt) {
    this.db.prepare('UPDATE sessions SET expires_at = ? WHERE token_hash = ?').run(expiresAt, tokenHash);
  }

  deleteSession(tokenHash) {
    this.db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
  }

  deleteUserSessions(userId, exceptHash) {
    this.db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').run(userId, exceptHash || '');
  }

  pruneSessions() {
    this.db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
  }

  // -------------------------------------------------------------- backups
  /** Buat salinan konsisten database (VACUUM INTO) — aman walau server sedang berjalan */
  backupTo(file) {
    if (fs.existsSync(file)) fs.unlinkSync(file);
    this.db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
    return file;
  }

  createBackup(label = 'manual') {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    const stamp = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
    const file = path.join(this.paths.backupsDir, `school-bell-${label}-${stamp}.db`);
    this.backupTo(file);
    return file;
  }

  listBackups() {
    try {
      return fs
        .readdirSync(this.paths.backupsDir)
        .filter((f) => /^school-bell-.*\.db$/.test(f))
        .map((f) => {
          const st = fs.statSync(path.join(this.paths.backupsDir, f));
          return { name: f, size: st.size, modifiedAt: st.mtimeMs };
        })
        .sort((a, b) => b.modifiedAt - a.modifiedAt);
    } catch {
      return [];
    }
  }

  /** Simpan maksimal N backup otomatis terbaru */
  pruneAutoBackups(keep = 7) {
    const autos = this.listBackups().filter((b) => b.name.includes('-auto-'));
    for (const b of autos.slice(keep)) {
      try {
        fs.unlinkSync(path.join(this.paths.backupsDir, b.name));
      } catch {
        /* abaikan */
      }
    }
  }

  /**
   * Ganti database aktif dengan berkas backup.
   * Database lama diamankan dulu sebagai backup "sebelum-restore".
   */
  restoreFrom(file) {
    const check = verifyBackupFile(file);
    if (!check.ok) throw new Error(check.error);
    const safety = this.createBackup('pre-restore');
    this.close();
    try {
      removeSidecars(this.paths.dbFile);
      fs.copyFileSync(file, this.paths.dbFile);
      this.db = openAndMigrate(this.paths.dbFile);
      this.seedSettings();
    } catch (err) {
      // kembalikan database lama
      removeSidecars(this.paths.dbFile);
      fs.copyFileSync(safety, this.paths.dbFile);
      this.db = openAndMigrate(this.paths.dbFile);
      throw new Error(`Restore gagal, database lama dikembalikan: ${err.message}`);
    }
    return safety;
  }
}

module.exports = { Store };
