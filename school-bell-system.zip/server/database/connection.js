'use strict';
/**
 * Koneksi SQLite memakai modul bawaan Node: node:sqlite
 * (tidak perlu compile native module → aman untuk build Windows).
 * Butuh Node >= 22.13 (Electron 35+ sudah menyertakannya).
 */
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { MIGRATIONS } = require('./schema');

function isCorruption(err) {
  return /malformed|not a database|corrupt|encrypted|disk image/i.test(String(err && err.message));
}

/** Buka database, aktifkan pragma, jalankan migrasi, lalu cek integritas */
function openAndMigrate(file) {
  const db = new DatabaseSync(file);
  try {
    db.exec('PRAGMA busy_timeout = 5000');
    db.exec('PRAGMA journal_mode = WAL');
    db.exec('PRAGMA synchronous = NORMAL');
    db.exec('PRAGMA foreign_keys = ON');
    const check = db.prepare('PRAGMA quick_check').get();
    if (check && Object.values(check)[0] !== 'ok') throw new Error('database disk image is malformed');
    migrate(db);
    return db;
  } catch (err) {
    try {
      db.close();
    } catch {
      /* abaikan */
    }
    throw err;
  }
}

function migrate(db) {
  let version = db.prepare('PRAGMA user_version').get().user_version;
  for (let i = version; i < MIGRATIONS.length; i++) {
    db.exec('BEGIN');
    try {
      MIGRATIONS[i](db);
      db.exec(`PRAGMA user_version = ${i + 1}`);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw new Error(`Migrasi database v${i + 1} gagal: ${err.message}`);
    }
  }
}

function removeSidecars(file) {
  for (const ext of ['-wal', '-shm']) {
    try {
      fs.unlinkSync(file + ext);
    } catch {
      /* tidak ada */
    }
  }
}

/** Verifikasi bahwa sebuah berkas adalah database School Bell yang valid (dipakai saat restore) */
function verifyBackupFile(file) {
  let db;
  try {
    db = new DatabaseSync(file, { readOnly: true });
    const tables = db
      .prepare("SELECT name FROM sqlite_master WHERE type='table'")
      .all()
      .map((r) => r.name);
    for (const t of ['schedules', 'sounds', 'settings', 'logs']) {
      if (!tables.includes(t)) return { ok: false, error: `Tabel "${t}" tidak ditemukan — ini bukan backup School Bell.` };
    }
    const check = db.prepare('PRAGMA quick_check').get();
    if (check && Object.values(check)[0] !== 'ok') return { ok: false, error: 'Berkas backup rusak (integrity check gagal).' };
    return { ok: true };
  } catch (err) {
    return { ok: false, error: `Bukan berkas database yang valid: ${err.message}` };
  } finally {
    try {
      db && db.close();
    } catch {
      /* abaikan */
    }
  }
}

function latestBackup(backupsDir) {
  try {
    return fs
      .readdirSync(backupsDir)
      .filter((f) => /^school-bell-.*\.db$/.test(f))
      .map((f) => ({ f, t: fs.statSync(path.join(backupsDir, f)).mtimeMs }))
      .sort((a, b) => b.t - a.t)
      .map((x) => path.join(backupsDir, x.f))[0];
  } catch {
    return undefined;
  }
}

/**
 * Buka database utama. Bila korup: pindahkan berkas rusak (tidak dihapus),
 * lalu coba pulihkan dari backup otomatis terbaru; bila tidak ada, buat database baru.
 * Mengembalikan { db, recovered: string|null }.
 */
function openDatabase(paths, logger) {
  try {
    return { db: openAndMigrate(paths.dbFile), recovered: null };
  } catch (err) {
    if (!isCorruption(err) || !fs.existsSync(paths.dbFile)) throw err;
    logger.system('error', `Database korup: ${err.message}. Mencoba memulihkan…`);
    const aside = `${paths.dbFile}.corrupt-${Date.now()}`;
    fs.renameSync(paths.dbFile, aside);
    removeSidecars(paths.dbFile);
    const backup = latestBackup(paths.backupsDir);
    if (backup && verifyBackupFile(backup).ok) {
      fs.copyFileSync(backup, paths.dbFile);
      logger.system('warn', `Database dipulihkan dari backup: ${path.basename(backup)}`);
      return { db: openAndMigrate(paths.dbFile), recovered: `Dipulihkan dari backup ${path.basename(backup)}` };
    }
    logger.system('warn', 'Tidak ada backup valid — membuat database baru.');
    return { db: openAndMigrate(paths.dbFile), recovered: 'Database lama korup dan dibuat ulang (berkas lama disimpan dengan akhiran .corrupt)' };
  }
}

module.exports = { openDatabase, openAndMigrate, verifyBackupFile, removeSidecars, latestBackup, isCorruption };
