'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const { execFile } = require('child_process');

const { getPaths, resolveSoundPath } = require('./paths');
const { loadConfig, saveConfig } = require('./config');
const { Logger } = require('./logger');
const { Store } = require('./database/store');
const { AudioManager, createNullBackend } = require('./audio/audioManager');
const { createSystemBackend } = require('./audio/systemPlayer');
const { Scheduler } = require('./scheduler/scheduler');
const { AuthService } = require('./auth/authService');
const { partsInTz } = require('./scheduler/timeUtil');
const { createHttpServer } = require('./http');
const pkg = require('../package.json');

const BUILTIN_SOUNDS = [
  { file: 'bell.wav', name: 'Bel Masuk' },
  { file: 'istirahat.wav', name: 'Bel Istirahat' },
  { file: 'pulang.wav', name: 'Bel Pulang' },
];

// Contoh jadwal awal (sesuai contoh pada spesifikasi). Hanya dibuat SEKALI saat pertama kali dijalankan.
const EXAMPLE_SCHEDULES = [
  { name: 'Upacara', time: '07:00', days: [1], sound: 'bell.wav' },
  { name: 'Masuk Kelas', time: '07:30', days: [1, 2, 3, 4, 5], sound: 'bell.wav' },
  { name: 'Istirahat', time: '09:00', days: [1, 2, 3, 4, 5], sound: 'istirahat.wav' },
  { name: 'Masuk Kelas', time: '09:30', days: [1, 2, 3, 4, 5], sound: 'bell.wav' },
  { name: 'Istirahat', time: '12:00', days: [1, 2, 3, 4, 5], sound: 'istirahat.wav' },
  { name: 'Pulang', time: '13:00', days: [1, 2, 3, 4, 5], sound: 'pulang.wav' },
];

/**
 * BellApp — komposisi utama. Dipakai oleh aplikasi desktop (Electron) maupun mode headless (npm run server).
 *
 *  - Core  : database, scheduler, audio → hidup selama aplikasi berjalan
 *  - Web   : HTTP server (dashboard + REST API) → dapat di-start/stop/restart terpisah dari scheduler
 *
 * Events: 'change' (status berubah), 'problem' ({message}), 'log' (entry)
 */
class BellApp extends EventEmitter {
  constructor(options = {}) {
    super();
    this.options = options;
    this.version = pkg.version;
    this.startedAt = Date.now();
    this.paths = null;
    this.config = null;
    this.logger = null;
    this.store = null;
    this.audio = null;
    this.scheduler = null;
    this.auth = null;
    this.http = null;
    this.serverState = { running: false, port: null, error: null };
    this.dbError = null;
    this.recoveredNote = null;
    this.timers = [];
    this._changeTimer = null;
  }

  // ------------------------------------------------------------------ init
  async init() {
    this.paths = getPaths(this.options.home);
    this.config = loadConfig(this.paths);
    if (this.options.config) this.config = { ...this.config, ...this.options.config };
    this.logger = new Logger(this.paths);
    this.store = new Store(this.paths, this.logger);
    this.audio = new AudioManager({ paths: this.paths, logger: this.logger });
    this.scheduler = new Scheduler({ store: this.store, audio: this.audio, logger: this.logger });
    this.auth = new AuthService({ store: this.store, logger: this.logger });

    this.audio.setBackend(this.options.audioBackend || (process.env.BELL_AUDIO === 'null' ? createNullBackend() : createSystemBackend()));

    this.logger.on('entry', (e) => {
      this.emit('log', e);
      this.notifyChange();
    });
    this.audio.on('start', () => this.notifyChange());
    this.audio.on('finish', () => this.notifyChange());
    this.audio.on('queued', () => this.notifyChange());
    this.audio.on('error', (e) => this.emit('problem', { message: `Gagal memutar sound "${e.sound}": ${e.message}` }));
    this.scheduler.on('problem', (e) => this.emit('problem', e));
    this.scheduler.on('state', () => this.notifyChange());

    await this.openDatabase();
    // Watchdog scheduler + pemeliharaan berkala
    this.timers.push(setInterval(() => this.scheduler.ensureAlive(), 5000));
    this.timers.push(setInterval(() => this.maintenance(), 10 * 60 * 1000));
    for (const t of this.timers) t.unref && t.unref();
    return this;
  }

  /** Buka database; bila gagal, server tetap hidup dalam mode "degraded" dan mencoba lagi berkala */
  async openDatabase() {
    try {
      this.store.open();
      this.logger.attachStore(this.store);
      this.dbError = null;
      this.recoveredNote = this.store.recovered;
      if (this.recoveredNote) this.logger.record({ event: 'Database dipulihkan', status: 'warning', source: 'system', detail: this.recoveredNote });
      await this.auth.ensureDefaultAdmin();
      this.seedInitialData();
      this.scheduler.reload();
      this.maintenance();
      return true;
    } catch (err) {
      this.dbError = err.message;
      this.logger.system('error', `Database tidak dapat dibuka: ${err.message}`);
      this.emit('problem', { message: `Database bermasalah: ${err.message}` });
      if (!this._dbRetry) {
        this._dbRetry = setInterval(async () => {
          if (await this.openDatabase()) {
            clearInterval(this._dbRetry);
            this._dbRetry = null;
            this.notifyChange();
          }
        }, 30000);
        this._dbRetry.unref && this._dbRetry.unref();
      }
      return false;
    }
  }

  /** Salin sound bawaan + contoh jadwal pada peluncuran pertama */
  seedInitialData() {
    const settings = this.store.getSettings();
    if (settings.initial_seed_done === '1') return;
    const ids = {};
    for (const b of BUILTIN_SOUNDS) {
      const src = path.join(this.paths.defaultSoundsDir, b.file);
      const dest = path.join(this.paths.soundsDir, b.file);
      try {
        if (!fs.existsSync(src)) continue;
        if (!fs.existsSync(dest)) fs.copyFileSync(src, dest);
        const st = fs.statSync(dest);
        const existing = this.store.getSoundByFilename(b.file);
        const sound =
          existing ||
          this.store.createSound({
            name: b.name,
            filename: b.file,
            filepath: `sounds/${b.file}`,
            mime: 'audio/wav',
            size: st.size,
            volume: 100,
            duration: Math.round(((st.size - 44) / (44100 * 2)) * 100) / 100,
            maxPlaySeconds: null,
            isBuiltin: true,
          });
        ids[b.file] = sound.id;
      } catch (err) {
        this.logger.system('warn', `Gagal menyiapkan sound bawaan ${b.file}: ${err.message}`);
      }
    }
    if (this.store.listSchedules().length === 0) {
      for (const ex of EXAMPLE_SCHEDULES) {
        this.store.createSchedule({
          name: ex.name,
          time: ex.time,
          mode: 'weekly',
          days: ex.days,
          date: null,
          soundId: ids[ex.sound] || null,
          volume: null,
          playSeconds: null,
          enabled: true,
        });
      }
    }
    const patch = { initial_seed_done: '1' };
    if (ids['bell.wav']) patch.default_sound_id = String(ids['bell.wav']);
    this.store.setSettings(patch);
    this.logger.record({ event: 'Data awal (sound bawaan & contoh jadwal) dibuat', status: 'info', source: 'system' });
  }

  /** Pembersihan berkala: sesi kedaluwarsa, log lama, backup otomatis harian */
  maintenance() {
    if (!this.store || !this.store.db) return;
    try {
      this.store.pruneSessions();
      const cfg = this.scheduler.cfg;
      const today = partsInTz(Date.now(), cfg.timezone).date.replace(/-/g, '');
      if (this._lastMaintenanceDay !== today) {
        this._lastMaintenanceDay = today;
        const removed = this.store.pruneLogs(cfg.logRetentionDays);
        if (removed > 0) this.logger.system('info', `${removed} log lama dihapus (retensi ${cfg.logRetentionDays} hari)`);
        if (cfg.autoBackup) {
          const has = this.store.listBackups().some((b) => b.name.includes(`-auto-${today}`));
          if (!has) {
            this.store.createBackup('auto');
            this.store.pruneAutoBackups(7);
            this.logger.record({ event: 'Backup otomatis dibuat', status: 'info', source: 'system' });
          }
        }
      }
    } catch (err) {
      this.logger.system('error', `Pemeliharaan gagal: ${err.message}`);
    }
  }

  // ------------------------------------------------------------ web server
  async startServer() {
    if (this.http) return this.getInfo();
    const { port, host } = this.config;
    try {
      const http = createHttpServer(this);
      await http.listen(port, host);
      this.http = http;
      this.serverState = { running: true, port, error: null };
      this.logger.record({ event: `Web server dimulai di port ${port}`, status: 'info', source: 'system' });
    } catch (err) {
      const msg =
        err.code === 'EADDRINUSE'
          ? `Port ${port} sudah dipakai aplikasi lain. Ganti port atau tutup aplikasi tersebut.`
          : err.code === 'EACCES'
            ? `Tidak punya izin memakai port ${port}. Gunakan port di atas 1024.`
            : err.message;
      this.serverState = { running: false, port, error: msg };
      this.logger.system('error', `Web server gagal dimulai: ${msg}`);
      this.emit('problem', { message: `Web server gagal dimulai: ${msg}` });
    }
    this.notifyChange();
    return this.getInfo();
  }

  async stopServer() {
    if (this.http) {
      await this.http.close();
      this.http = null;
      this.logger.record({ event: 'Web server dihentikan', status: 'info', source: 'system' });
    }
    this.serverState = { running: false, port: this.config.port, error: null };
    this.notifyChange();
    return this.getInfo();
  }

  async restartServer() {
    await this.stopServer();
    return this.startServer();
  }

  startScheduler() {
    this.scheduler.start();
    this.notifyChange();
  }

  stopScheduler() {
    this.scheduler.stop();
    this.notifyChange();
  }

  async shutdown() {
    for (const t of this.timers) clearInterval(t);
    if (this._dbRetry) clearInterval(this._dbRetry);
    try {
      this.audio && this.audio.stop();
    } catch {
      /* abaikan */
    }
    this.scheduler && this.scheduler.stop();
    await this.stopServer();
    this.store && this.store.close();
  }

  /** Simpan perubahan konfigurasi level aplikasi (port, dsb.) */
  updateConfig(patch) {
    this.config = saveConfig(this.paths, { ...this.config, ...patch });
    return this.config;
  }

  // ------------------------------------------------------------------ info
  getAddresses() {
    const out = [];
    const nets = os.networkInterfaces();
    for (const [name, list] of Object.entries(nets)) {
      for (const n of list || []) {
        if (n.family === 'IPv4' && !n.internal) out.push({ interface: name, address: n.address });
      }
    }
    return out;
  }

  getInfo() {
    const port = this.serverState.port || this.config.port;
    return {
      running: this.serverState.running,
      port,
      host: this.config.host,
      error: this.serverState.error,
      localUrl: `http://localhost:${port}`,
      urls: this.getAddresses().map((a) => ({ ...a, url: `http://${a.address}:${port}` })),
    };
  }

  notifyChange() {
    if (this._changeTimer) return;
    this._changeTimer = setTimeout(() => {
      this._changeTimer = null;
      this.emit('change');
    }, 40);
  }

  // ---------------------------------------------------------------- status
  buildStatus() {
    const now = Date.now();
    const sch = this.scheduler;
    const cfg = sch.cfg;
    const snap = sch.snapshot(now);
    const dbOk = !this.dbError && !snap.cacheError && !!(this.store && this.store.db);
    const today = partsInTz(now, cfg.timezone);
    const holiday = sch.holidayOn(today.date);
    return {
      app: { name: 'School Bell System', version: this.version, schoolName: cfg.schoolName },
      server: {
        status: 'running',
        now,
        uptimeSec: Math.round(process.uptime()),
        timezone: cfg.timezone,
        timeFormat: cfg.timeFormat,
        webPort: this.serverState.port,
      },
      db: { ok: dbOk, error: this.dbError || (snap.cacheError && snap.cacheError.message) || null, recovered: this.recoveredNote },
      scheduler: {
        running: snap.running,
        enabled: cfg.enabled,
        lastTickAt: snap.lastTickAt,
        scheduleCount: snap.scheduleCount,
        activeScheduleCount: snap.activeScheduleCount,
      },
      autoBell: {
        active: snap.running && !snap.suppression,
        reason: !snap.running ? 'stopped' : snap.suppression ? snap.suppression.reason : null,
        label: !snap.running ? 'Scheduler tidak berjalan' : snap.suppression ? snap.suppression.label : null,
        until: snap.suppression && snap.suppression.until ? snap.suppression.until : null,
      },
      exam: { active: cfg.examMode, until: cfg.examUntil },
      pause: { until: cfg.pauseUntil && cfg.pauseUntil > now ? cfg.pauseUntil : null },
      holidayToday: holiday ? holiday.name : null,
      bell: this.audio.state(),
      next: sch.computeNext(now),
      today: sch.todayList(now),
      masterVolume: cfg.masterVolume,
      defaultSoundId: cfg.defaultSoundId,
    };
  }

  // ------------------------------------------------------------ manual bell
  /** Cek awal sebelum bel manual dimulai, agar error dapat langsung dikembalikan ke UI */
  preflight(sound) {
    if (!sound) return 'Tidak ada sound yang dipilih atau tersedia. Upload sound terlebih dahulu.';
    const abs = resolveSoundPath(this.paths, sound.filepath);
    if (!abs) return 'Path file sound tidak valid';
    if (!fs.existsSync(abs)) return `File sound "${sound.name}" tidak ditemukan di folder sounds`;
    if (!this.audio.backend) return 'Pemutar audio belum siap';
    return null;
  }

  /**
   * Bunyikan bel manual / test sound. Mengembalikan segera setelah bel MULAI;
   * hasil akhir dilaporkan lewat log & event.
   */
  triggerManual({ soundId, volume, seconds, actor = 'admin', test = false }) {
    const sch = this.scheduler;
    sch.reload();
    let sound = null;
    if (soundId) sound = sch.soundMap.get(Number(soundId)) || null;
    else sound = sch.resolveSound({ soundId: null });
    const problem = this.preflight(sound);
    if (problem) return { ok: false, error: problem };

    const vol = sch.effectiveVolume(sound, volume === undefined || volume === null ? undefined : Number(volume));
    const secs = test ? sch.cfg.testSoundSeconds : seconds || sound.maxPlaySeconds || null;
    const label = test ? `Test: ${sound.name}` : `Bel manual: ${sound.name}`;
    this.logger.record({
      event: test ? `Test sound "${sound.name}" oleh ${actor}` : `Bel manual dibunyikan oleh ${actor}`,
      status: 'ok',
      source: 'manual',
      detail: `Sound: ${sound.name}, volume ${vol}%${secs ? `, maks ${secs} detik` : ''}`,
    });
    this.audio
      .play({ label, filepath: sound.filepath, volume: vol, seconds: secs, duration: sound.duration, source: test ? 'test' : 'manual', interrupt: true })
      .then((res) => {
        if (res.ok && !res.stopped) this.logger.record({ event: `Bel selesai: ${label}`, status: 'info', source: 'manual' });
        else if (res.ok) this.logger.record({ event: `Bel dihentikan: ${label}`, status: 'info', source: 'manual' });
        else this.logger.record({ event: `Bel gagal diputar: ${label}`, status: 'error', source: 'manual', detail: res.error });
      });
    return { ok: true, sound: { id: sound.id, name: sound.name }, volume: vol };
  }

  // ------------------------------------------------------------- time sync
  /** Sinkronisasi jam sistem. Windows: w32tm /resync (butuh layanan Windows Time & hak admin). */
  syncSystemTime() {
    return new Promise((resolve) => {
      if (process.platform !== 'win32') {
        return resolve({
          ok: false,
          error: 'Sinkronisasi otomatis hanya tersedia di Windows. Di sistem lain, gunakan pengaturan waktu bawaan (NTP) sistem operasi.',
        });
      }
      execFile('w32tm', ['/resync'], { windowsHide: true, timeout: 20000 }, (err, stdout, stderr) => {
        const output = `${stdout || ''}${stderr || ''}`.trim();
        if (err) {
          return resolve({
            ok: false,
            error: 'Sinkronisasi gagal. Pastikan layanan "Windows Time" berjalan dan aplikasi dijalankan sebagai Administrator.',
            output,
          });
        }
        this.logger.record({ event: 'Sinkronisasi waktu sistem dijalankan', status: 'info', source: 'system', detail: output.slice(0, 200) });
        this.scheduler.reload();
        this.notifyChange();
        resolve({ ok: true, output });
      });
    });
  }
}

module.exports = { BellApp };
