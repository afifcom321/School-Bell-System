'use strict';
/**
 * Utilitas waktu berbasis timezone IANA (mis. Asia/Jakarta) memakai Intl bawaan Node.
 * Semua perhitungan berbasis epoch (timestamp) sehingga tidak terpengaruh drift setTimeout.
 */

const dtfCache = new Map();
const WEEKDAYS = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

function getFormatter(tz) {
  let f = dtfCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: tz,
      hourCycle: 'h23',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      weekday: 'short',
    });
    dtfCache.set(tz, f);
  }
  return f;
}

function isValidTimeZone(tz) {
  if (typeof tz !== 'string' || !tz) return false;
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

const pad2 = (n) => String(n).padStart(2, '0');

/** Pecah epoch menjadi komponen waktu lokal di timezone tertentu */
function partsInTz(epochMs, tz) {
  const map = {};
  for (const p of getFormatter(tz).formatToParts(new Date(epochMs))) map[p.type] = p.value;
  const year = Number(map.year);
  const month = Number(map.month);
  const day = Number(map.day);
  const hour = Number(map.hour) % 24;
  const minute = Number(map.minute);
  const second = Number(map.second);
  return {
    year,
    month,
    day,
    hour,
    minute,
    second,
    dow: WEEKDAYS[map.weekday], // 0 = Minggu … 6 = Sabtu
    date: `${year}-${pad2(month)}-${pad2(day)}`,
    hhmm: `${pad2(hour)}:${pad2(minute)}`,
  };
}

/** Selisih (ms) antara waktu lokal timezone dan UTC pada epoch tertentu */
function tzOffsetMs(epochMs, tz) {
  const p = partsInTz(epochMs, tz);
  const asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return asUtc - Math.floor(epochMs / 1000) * 1000;
}

/** Ubah tanggal 'YYYY-MM-DD' + 'HH:MM' di timezone tertentu menjadi epoch ms */
function zonedToEpoch(dateStr, hhmm, tz) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const [hh, mm] = hhmm.split(':').map(Number);
  const guess = Date.UTC(y, m - 1, d, hh, mm, 0);
  let epoch = guess - tzOffsetMs(guess, tz);
  // koreksi kedua untuk kasus DST
  epoch = guess - tzOffsetMs(epoch, tz);
  return epoch;
}

/** Tambah n hari pada string tanggal 'YYYY-MM-DD' */
function addDays(dateStr, n) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + n));
  return `${dt.getUTCFullYear()}-${pad2(dt.getUTCMonth() + 1)}-${pad2(dt.getUTCDate())}`;
}

/** Hari dalam seminggu (0 = Minggu) untuk string tanggal */
function dowOfDate(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

function isValidDate(str) {
  if (typeof str !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
  const [y, m, d] = str.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function isValidHHMM(str) {
  return typeof str === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(str);
}

module.exports = {
  isValidTimeZone,
  partsInTz,
  tzOffsetMs,
  zonedToEpoch,
  addDays,
  dowOfDate,
  isValidDate,
  isValidHHMM,
  pad2,
};
