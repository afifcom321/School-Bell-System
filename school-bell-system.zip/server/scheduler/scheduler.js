'use strict';
const { EventEmitter } = require('events');
const { parseSettings } = require('../settings');
const { partsInTz, zonedToEpoch, addDays, dowOfDate } = require('./timeUtil');

const RELOAD_EVERY_MS = 30000;
const LOOKAHEAD_DAYS = 14;

/**
 * Scheduler bel — berjalan sepenuhnya di sisi server (tidak bergantung pada browser).
 *
 * Cara kerja (anti-drift):
 *  1. Loop ringan berdetak tiap ±1 detik (di-align ke pergantian detik). Ketepatan TIDAK bergantung pada
 *     interval karena setiap detak membandingkan JAM AKTUAL (Date.now) dengan jadwal.
 *  2. Setiap detak memproses semua menit sejak detak sebelumnya (`lastMin`) → tidak ada menit yang terlewat
 *     walau event loop sempat tertunda. Bel terlambat ≤ `catchup_seconds` tetap dibunyikan, selebihnya
 *     dicatat sebagai "terlewat".
 *  3. Anti-dobel: setiap jadwal dicatat `last_fired` = 'YYYY-MM-DD HH:MM' (di memori dan database), sehingga
 *     tidak berbunyi dua kali dalam menit yang sama, termasuk saat aplikasi restart.
 *  4. Bel berikutnya dihitung dari timestamp + jadwal, bukan timer → restart pukul 07:29 tetap tahu 07:30.
 *  5. Data (jadwal, sound, pengaturan) di-cache di memori. Jika database bermasalah, scheduler tetap berjalan
 *     memakai cache terakhir yang valid.
 */
class Scheduler extends EventEmitter {
  constructor({ store, audio, logger, now = () => Date.now() }) {
    super();
    this.store = store;
    this.audio = audio;
    this.logger = logger;
    this.now = now;

    this.running = false;
    this.timer = null;
    this.lastTickAt = 0;
    this.lastMin = null;
    this.startedAt = null;
    this.firedKeys = new Set();

    this.raw = {};
    this.cfg = parseSettings({});
    this.schedules = [];
    this.sounds = [];
    this.soundMap = new Map();
    this.loadedAt = 0;
    this.cacheError = null;
  }

  // ------------------------------------------------------------ lifecycle
  start() {
    if (this.running) return;
    this.reload();
    this.running = true;
    this.startedAt = this.now();
    this.lastMin = Math.floor(this.now() / 60000) - 1; // ikut periksa menit sebelumnya (catch-up saat start)
    this.logger.record({ event: 'Scheduler dimulai', status: 'info', source: 'system' });
    this._arm();
    this.tick();
    this.emit('state');
  }

  stop() {
    if (!this.running) return;
    this.running = false;
    clearTimeout(this.timer);
    this.timer = null;
    this.logger.record({ event: 'Scheduler dihentikan', status: 'info', source: 'system' });
    this.emit('state');
  }

  /** Dipanggil watchdog: hidupkan ulang loop bila macet */
  ensureAlive() {
    if (this.running && this.now() - this.lastTickAt > 5000) {
      this.logger.record({ event: 'Scheduler macet — dihidupkan ulang oleh watchdog', status: 'warning', source: 'system' });
      clearTimeout(this.timer);
      this._arm();
      this.tick();
    }
  }

  _arm() {
    clearTimeout(this.timer);
    if (!this.running) return;
    const delay = 1000 - (Date.now() % 1000) + 15; // sejajarkan dengan pergantian detik
    this.timer = setTimeout(() => {
      this.tick();
      this._arm();
    }, delay);
  }

  // ---------------------------------------------------------------- cache
  /** Muat ulang jadwal/sound/pengaturan dari database ke cache. Aman terhadap error DB. */
  reload() {
    try {
      const schedules = this.store.listSchedules();
      const sounds = this.store.listSounds();
      const raw = this.store.getSettings();
      this.schedules = schedules;
      this.sounds = sounds;
      this.soundMap = new Map(sounds.map((s) => [s.id, s]));
      this.raw = raw;
      this.cfg = parseSettings(raw);
      this.loadedAt = this.now();
      if (this.cacheError) {
        this.logger.record({ event: 'Database kembali normal', status: 'info', source: 'system' });
        this.cacheError = null;
      }
      return true;
    } catch (err) {
      this.loadedAt = this.now(); // jangan coba tiap detik
      if (!this.cacheError) {
        this.cacheError = { message: err.message, at: this.now() };
        this.logger.record({
          event: 'Database bermasalah — scheduler memakai data cache terakhir',
          status: 'error',
          source: 'system',
          detail: err.message,
        });
        this.emit('problem', { message: `Database bermasalah: ${err.message}` });
      }
      return false;
    }
  }

  // ----------------------------------------------------------------- tick
  tick() {
    try {
      const now = this.now();
      if (this.lastTickAt && now - this.lastTickAt > 5000 && this.lastMin !== null) {
        this.logger.record({
          event: `Scheduler tertunda ${Math.round((now - this.lastTickAt) / 1000)} detik`,
          status: 'warning',
          source: 'system',
          detail: 'Komputer mungkin sempat sleep/hang. Bel yang terlewat dicatat pada log.',
        });
      }
      this.lastTickAt = now;
      if (now - this.loadedAt > RELOAD_EVERY_MS) this.reload();
      this.housekeeping(now);

      const curMin = Math.floor(now / 60000);
      if (this.lastMin === null) this.lastMin = curMin - 1;
      let missedLogged = 0;
      for (let m = this.lastMin + 1; m <= curMin; m++) {
        missedLogged += this.processMinute(m * 60000, now, missedLogged);
      }
      this.lastMin = curMin;
      if (this.firedKeys.size > 500) this.firedKeys.clear();
    } catch (err) {
      // Apa pun yang terjadi, loop tidak boleh mati
      this.logger.system('error', `Scheduler tick error: ${err.stack || err.message}`);
    }
  }

  /** Proses seluruh jadwal yang jatuh tepat pada menit `minuteStart`. Mengembalikan jumlah log "terlewat". */
  processMinute(minuteStart, now, alreadyMissed = 0) {
    const cfg = this.cfg;
    const p = partsInTz(minuteStart, cfg.timezone);
    const due = this.schedules.filter((s) => s.enabled && s.time === p.hhmm && this.appliesOn(s, p.date, p.dow));
    let missed = 0;
    for (const s of due) {
      const key = `${p.date} ${p.hhmm}`;
      const memKey = `${s.id}|${key}`;
      if (s.lastFired === key || this.firedKeys.has(memKey)) continue;
      this.firedKeys.add(memKey); // tandai DULU agar tidak mungkin berbunyi dua kali
      s.lastFired = key;

      const late = now - minuteStart;
      const sup = this.suppressionAt(minuteStart, p.date);
      if (sup) {
        this.logger.record({
          event: `Bel dilewati: ${s.name}`,
          scheduleId: s.id,
          status: 'skipped',
          source: 'scheduler',
          detail: `${s.time} — ${sup.label}`,
        });
      } else if (late > Math.max(cfg.catchupSeconds * 1000, 2000)) {
        if (alreadyMissed + missed < 20) {
          this.logger.record({
            event: `Bel terlewat: ${s.name}`,
            scheduleId: s.id,
            status: 'missed',
            source: 'scheduler',
            detail: `${s.time} — terlambat ${Math.round(late / 1000)} detik (melebihi toleransi ${cfg.catchupSeconds} detik)`,
          });
          missed++;
        }
      } else {
        this.fire(s, late);
      }
      try {
        this.store.markFired(s.id, key);
      } catch {
        /* database bermasalah: penanda di memori sudah cukup untuk mencegah dobel */
      }
    }
    return missed;
  }

  // ----------------------------------------------------------------- fire
  resolveSound(s) {
    if (s.soundId && this.soundMap.has(s.soundId)) return this.soundMap.get(s.soundId);
    if (this.cfg.defaultSoundId && this.soundMap.has(this.cfg.defaultSoundId)) return this.soundMap.get(this.cfg.defaultSoundId);
    return this.sounds[0] || null;
  }

  effectiveVolume(sound, override) {
    const base = override ?? sound.volume ?? 100;
    return Math.round((base * this.cfg.masterVolume) / 100);
  }

  fire(s, lateMs = 0) {
    const sound = this.resolveSound(s);
    if (!sound) {
      this.logger.record({
        event: `Bel gagal: ${s.name}`,
        scheduleId: s.id,
        status: 'error',
        source: 'scheduler',
        detail: 'Tidak ada sound yang dapat digunakan. Upload sound terlebih dahulu.',
      });
      this.emit('problem', { message: `Bel "${s.name}" gagal: tidak ada sound tersedia` });
      return Promise.resolve({ ok: false });
    }
    const lateNote = lateMs > 3000 ? ` (terlambat ${Math.round(lateMs / 1000)} dtk)` : '';
    this.logger.record({
      event: `Bel terjadwal berbunyi: ${s.name}`,
      scheduleId: s.id,
      source: 'scheduler',
      detail: `${s.time} — sound: ${sound.name}${lateNote}`,
    });
    this.emit('fired', { schedule: s, sound });
    return this.audio
      .play({
        label: s.name,
        filepath: sound.filepath,
        volume: this.effectiveVolume(sound, s.volume),
        seconds: s.playSeconds ?? sound.maxPlaySeconds ?? null,
        duration: sound.duration,
        source: 'scheduler',
        scheduleId: s.id,
        interrupt: false,
      })
      .then((res) => {
        if (res.ok && !res.stopped) {
          this.logger.record({ event: `Bel selesai: ${s.name}`, scheduleId: s.id, status: 'info', source: 'scheduler' });
        } else if (res.ok && res.stopped) {
          this.logger.record({ event: `Bel dihentikan: ${s.name}`, scheduleId: s.id, status: 'info', source: 'scheduler' });
        } else {
          this.logger.record({
            event: `Bel gagal diputar: ${s.name}`,
            scheduleId: s.id,
            status: 'error',
            source: 'scheduler',
            detail: res.error,
          });
          this.emit('problem', { message: `Bel "${s.name}" gagal diputar: ${res.error}` });
        }
        return res;
      });
  }

  // ------------------------------------------------------------ housekeeping
  /** Matikan otomatis mode ujian / jeda sementara yang sudah berakhir */
  housekeeping(now) {
    const c = this.cfg;
    try {
      if (c.examMode && c.examUntil && now >= c.examUntil) {
        this.store.setSettings({ exam_mode: '0', exam_until: '' });
        this.logger.record({ event: 'Mode ujian berakhir — bel otomatis aktif kembali', status: 'info', source: 'scheduler' });
        this.reload();
        this.emit('state');
      }
      if (c.pauseUntil && now >= c.pauseUntil) {
        this.store.setSettings({ pause_until: '' });
        this.logger.record({ event: 'Jeda bel berakhir — bel otomatis aktif kembali', status: 'info', source: 'scheduler' });
        this.reload();
        this.emit('state');
      }
    } catch {
      /* dicoba lagi pada detak berikutnya */
    }
  }

  // ----------------------------------------------------------- rule helpers
  appliesOn(s, dateStr, dow) {
    if (s.mode === 'date') return s.date === dateStr;
    return s.days.includes(dow);
  }

  holidayOn(dateStr) {
    return this.cfg.holidays.find((h) => dateStr >= h.start && dateStr <= h.end) || null;
  }

  /**
   * Apakah bel otomatis DITAHAN pada waktu tertentu? (mode libur/ujian/jeda/nonaktif)
   * @returns {null | {reason:'disabled'|'exam'|'paused'|'holiday', label:string, until?:number}}
   */
  suppressionAt(epoch, dateStr) {
    const c = this.cfg;
    if (!c.enabled) return { reason: 'disabled', label: 'Jadwal otomatis dinonaktifkan' };
    if (c.examMode && (!c.examUntil || epoch < c.examUntil)) {
      return { reason: 'exam', label: 'Mode ujian aktif', until: c.examUntil || undefined };
    }
    if (c.pauseUntil && epoch < c.pauseUntil) return { reason: 'paused', label: 'Bel dijeda sementara', until: c.pauseUntil };
    const h = this.holidayOn(dateStr);
    if (h) return { reason: 'holiday', label: `Libur: ${h.name}` };
    return null;
  }

  bellsOnDate(dateStr, enabledOnly = true) {
    const dow = dowOfDate(dateStr);
    return this.schedules
      .filter((s) => (!enabledOnly || s.enabled) && this.appliesOn(s, dateStr, dow))
      .sort((a, b) => a.time.localeCompare(b.time) || a.id - b.id);
  }

  // -------------------------------------------------------------- queries
  /** Bel otomatis berikutnya (memperhitungkan libur/ujian/jeda). Dihitung dari timestamp, bukan timer. */
  computeNext(now = this.now()) {
    const tz = this.cfg.timezone;
    if (!this.cfg.enabled) return null;
    let date = partsInTz(now, tz).date;
    for (let i = 0; i <= LOOKAHEAD_DAYS; i++, date = addDays(date, 1)) {
      for (const s of this.bellsOnDate(date, true)) {
        const at = zonedToEpoch(date, s.time, tz);
        if (at <= now) continue;
        if (this.suppressionAt(at, date)) continue;
        const sound = this.resolveSound(s);
        return { at, date, time: s.time, name: s.name, scheduleId: s.id, soundName: sound ? sound.name : null };
      }
    }
    return null;
  }

  /** Daftar bel hari ini beserta statusnya */
  todayList(now = this.now()) {
    const tz = this.cfg.timezone;
    const date = partsInTz(now, tz).date;
    let nextMarked = false;
    return this.bellsOnDate(date, true).map((s) => {
      const at = zonedToEpoch(date, s.time, tz);
      const sound = this.resolveSound(s);
      let state = 'done';
      if (at > now) {
        state = nextMarked ? 'upcoming' : 'next';
        nextMarked = true;
      }
      return { id: s.id, time: s.time, name: s.name, at, soundName: sound ? sound.name : null, state };
    });
  }

  /** Pratinjau jadwal untuk tanggal tertentu */
  preview(dateStr) {
    const holiday = this.holidayOn(dateStr);
    const items = this.bellsOnDate(dateStr, false).map((s) => {
      const sound = this.resolveSound(s);
      return {
        id: s.id,
        time: s.time,
        name: s.name,
        enabled: s.enabled,
        soundName: sound ? sound.name : null,
        willRing: s.enabled && !holiday,
      };
    });
    return { date: dateStr, dow: dowOfDate(dateStr), holiday: holiday ? holiday.name : null, items };
  }

  /** Simulasi (dry-run): jadwal apa yang akan berbunyi pada tanggal + jam tertentu? Tidak membunyikan apa pun. */
  testAt(dateStr, hhmm) {
    const tz = this.cfg.timezone;
    const epoch = zonedToEpoch(dateStr, hhmm, tz);
    const dow = dowOfDate(dateStr);
    const matches = this.schedules
      .filter((s) => s.enabled && s.time === hhmm && this.appliesOn(s, dateStr, dow))
      .map((s) => ({ id: s.id, name: s.name, soundName: (this.resolveSound(s) || {}).name || null }));
    const sup = this.suppressionAt(epoch, dateStr);
    return { date: dateStr, time: hhmm, epoch, matches, suppressed: sup };
  }

  snapshot(now = this.now()) {
    const sup = this.suppressionAt(now, partsInTz(now, this.cfg.timezone).date);
    return {
      running: this.running,
      enabled: this.cfg.enabled,
      suppression: sup,
      lastTickAt: this.lastTickAt,
      startedAt: this.startedAt,
      scheduleCount: this.schedules.length,
      activeScheduleCount: this.schedules.filter((s) => s.enabled).length,
      cacheError: this.cacheError,
    };
  }
}

module.exports = { Scheduler };
