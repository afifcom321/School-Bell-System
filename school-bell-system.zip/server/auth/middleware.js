'use strict';

const COOKIE_NAME = 'sbs_session';

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    if (k) out[k] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function setSessionCookie(res, token, maxAgeMs) {
  res.setHeader(
    'Set-Cookie',
    `${COOKIE_NAME}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${Math.floor(maxAgeMs / 1000)}`
  );
}

function clearSessionCookie(res) {
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);
}

/** Baca cookie sesi → req.user (bila valid). Tidak menolak request. */
function attachUser(auth) {
  return (req, res, next) => {
    const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
    req.sessionToken = token || null;
    try {
      req.user = auth.authenticate(token) || null;
    } catch {
      req.user = null; // database bermasalah → anggap belum login; endpoint akan menampilkan error jelas
    }
    next();
  };
}

/** Wajib login. User dengan password bawaan hanya boleh mengganti password. */
function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Silakan login terlebih dahulu', code: 'UNAUTHENTICATED' });
  if (req.user.mustChangePassword) {
    return res.status(403).json({ error: 'Anda harus mengganti password bawaan terlebih dahulu', code: 'PASSWORD_CHANGE_REQUIRED' });
  }
  next();
}

/** Wajib admin (Viewer hanya boleh melihat) */
function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Hanya administrator yang dapat melakukan tindakan ini', code: 'FORBIDDEN' });
    }
    next();
  });
}

/**
 * Perlindungan CSRF tambahan: untuk request yang mengubah data, jika browser mengirim header Origin
 * maka host-nya harus sama dengan host server. (Cookie juga sudah SameSite=Lax.)
 */
function sameOriginOnly(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.headers.origin;
  if (origin) {
    try {
      if (new URL(origin).host !== req.headers.host) {
        return res.status(403).json({ error: 'Origin tidak diizinkan', code: 'BAD_ORIGIN' });
      }
    } catch {
      return res.status(403).json({ error: 'Origin tidak valid', code: 'BAD_ORIGIN' });
    }
  }
  next();
}

module.exports = { attachUser, requireAuth, requireAdmin, sameOriginOnly, setSessionCookie, clearSessionCookie, parseCookies, COOKIE_NAME };
