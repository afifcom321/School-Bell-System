'use strict';
const crypto = require('crypto');
const { hashPassword, verifyPassword } = require('./password');

const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 jam, diperpanjang otomatis saat dipakai
const MAX_FAILS = 5;
const LOCK_MS = 5 * 60 * 1000;

const DEFAULT_ADMIN = { username: 'admin', password: 'admin123' };

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

class AuthService {
  constructor({ store, logger }) {
    this.store = store;
    this.logger = logger;
    this.fails = new Map(); // ip -> { count, lockedUntil }
  }

  /** Buat akun admin awal (wajib ganti password saat login pertama) bila belum ada user */
  async ensureDefaultAdmin() {
    if (this.store.countUsers() > 0) return false;
    this.store.createUser({
      username: DEFAULT_ADMIN.username,
      passwordHash: await hashPassword(DEFAULT_ADMIN.password),
      role: 'admin',
      mustChangePassword: true,
    });
    this.logger.record({
      event: 'Akun admin awal dibuat',
      status: 'info',
      source: 'auth',
      detail: `Username "${DEFAULT_ADMIN.username}" — password wajib diganti saat login pertama`,
    });
    return true;
  }

  isLocked(ip) {
    const f = this.fails.get(ip);
    if (!f || !f.lockedUntil) return 0;
    if (Date.now() >= f.lockedUntil) {
      this.fails.delete(ip);
      return 0;
    }
    return Math.ceil((f.lockedUntil - Date.now()) / 1000);
  }

  registerFail(ip) {
    const f = this.fails.get(ip) || { count: 0, lockedUntil: 0 };
    f.count += 1;
    if (f.count >= MAX_FAILS) f.lockedUntil = Date.now() + LOCK_MS;
    this.fails.set(ip, f);
  }

  /** @returns {{ok:true,user,token,maxAgeMs}|{ok:false,error,status,retryAfter?}} */
  async login(username, password, ip) {
    const wait = this.isLocked(ip);
    if (wait) {
      return { ok: false, status: 429, error: `Terlalu banyak percobaan gagal. Coba lagi dalam ${Math.ceil(wait / 60)} menit.`, retryAfter: wait };
    }
    const user = typeof username === 'string' ? this.store.getUserByUsername(username.trim()) : null;
    // verifikasi tetap dijalankan walau user tidak ada (menyamakan waktu respons)
    const ok = await verifyPassword(String(password || ''), user ? user.passwordHash : 'scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=');
    if (!user || !ok) {
      this.registerFail(ip);
      this.logger.record({ event: 'Login gagal', status: 'warning', source: 'auth', detail: `User "${String(username).slice(0, 40)}" dari ${ip}` });
      return { ok: false, status: 401, error: 'Username atau password salah' };
    }
    this.fails.delete(ip);
    const token = crypto.randomBytes(32).toString('hex');
    this.store.createSession(sha256(token), user.id, Date.now() + SESSION_TTL_MS, ip);
    this.logger.record({ event: `Login: ${user.username}`, status: 'info', source: 'auth', detail: `dari ${ip}` });
    return { ok: true, user: publicUser(user), token, maxAgeMs: SESSION_TTL_MS };
  }

  logout(token) {
    if (token) this.store.deleteSession(sha256(token));
  }

  /** Validasi token cookie → user (atau null). Memperpanjang sesi bila sudah lewat setengah masa berlaku. */
  authenticate(token) {
    if (!token || typeof token !== 'string' || token.length !== 64) return null;
    const hash = sha256(token);
    const s = this.store.getSession(hash);
    if (!s) return null;
    if (s.expires_at < Date.now()) {
      this.store.deleteSession(hash);
      return null;
    }
    const user = this.store.getUser(s.user_id);
    if (!user) return null;
    if (s.expires_at - Date.now() < SESSION_TTL_MS / 2) this.store.extendSession(hash, Date.now() + SESSION_TTL_MS);
    return { ...publicUser(user), tokenHash: hash };
  }

  async changePassword(userId, currentPassword, newPassword, keepTokenHash) {
    const user = this.store.getUser(userId);
    if (!user) return { ok: false, status: 404, error: 'User tidak ditemukan' };
    if (!(await verifyPassword(String(currentPassword || ''), user.passwordHash))) {
      return { ok: false, status: 400, error: 'Password saat ini salah' };
    }
    const problem = passwordProblem(newPassword);
    if (problem) return { ok: false, status: 400, error: problem };
    this.store.updateUser(userId, { passwordHash: await hashPassword(newPassword), mustChangePassword: false });
    this.store.deleteUserSessions(userId, keepTokenHash); // sesi lain dikeluarkan
    this.logger.record({ event: `Password diganti: ${user.username}`, status: 'info', source: 'auth' });
    return { ok: true };
  }
}

function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 6) return 'Password baru minimal 6 karakter';
  if (pw.length > 128) return 'Password terlalu panjang';
  if (pw === DEFAULT_ADMIN.password) return 'Gunakan password yang berbeda dari password bawaan';
  return null;
}

function publicUser(u) {
  return { id: u.id, username: u.username, role: u.role, mustChangePassword: !!u.mustChangePassword };
}

module.exports = { AuthService, passwordProblem, DEFAULT_ADMIN, publicUser, hashPassword };
