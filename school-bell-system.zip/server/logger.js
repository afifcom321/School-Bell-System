'use strict';
const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');

/**
 * Logger aktivitas.
 * - Aktivitas penting ditulis ke tabel `logs` (untuk ditampilkan di web) DAN ke file logs/app-YYYY-MM-DD.log
 * - Jika database bermasalah, log tetap tertulis ke file dan server TIDAK crash.
 * Event 'entry' dipancarkan setiap ada log baru (dipakai untuk realtime di web & notifikasi desktop).
 */
class Logger extends EventEmitter {
  constructor(paths) {
    super();
    this.paths = paths;
    this.store = null;
    this.dbFailureReported = false;
    this.pruneFiles();
  }

  attachStore(store) {
    this.store = store;
  }

  /** Catat aktivitas. status: ok | info | warning | error | skipped | missed */
  record({ event, scheduleId = null, status = 'ok', source = 'system', detail = null }) {
    const entry = { event, scheduleId, status, source, detail, timestamp: Date.now() };
    if (this.store) {
      try {
        entry.id = this.store.addLog(entry);
        this.dbFailureReported = false;
      } catch (err) {
        if (!this.dbFailureReported) {
          this.dbFailureReported = true;
          this.writeFile('ERROR', 'system', `Gagal menulis log ke database: ${err.message}`);
        }
      }
    }
    this.writeFile(status.toUpperCase(), source, detail ? `${event} — ${detail}` : event);
    try {
      this.emit('entry', entry);
    } catch {
      /* listener tidak boleh mematikan logger */
    }
    return entry;
  }

  /** Log teknis (hanya console + file, tidak masuk tabel logs) */
  system(level, message) {
    this.writeFile(level.toUpperCase(), 'system', message);
    if (level === 'error') console.error(`[bell] ${message}`);
  }

  writeFile(level, source, message) {
    try {
      const d = new Date();
      const pad = (n) => String(n).padStart(2, '0');
      const day = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
      const time = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
      fs.appendFileSync(
        path.join(this.paths.logsDir, `app-${day}.log`),
        `[${day} ${time}] [${level}] [${source}] ${message}\n`
      );
    } catch {
      /* disk penuh / read-only: abaikan agar tidak crash */
    }
  }

  /** Hapus file log teks yang lebih tua dari 30 hari */
  pruneFiles(days = 30) {
    try {
      const limit = Date.now() - days * 86400000;
      for (const f of fs.readdirSync(this.paths.logsDir)) {
        if (!/^app-\d{4}-\d{2}-\d{2}\.log$/.test(f)) continue;
        const full = path.join(this.paths.logsDir, f);
        if (fs.statSync(full).mtimeMs < limit) fs.unlinkSync(full);
      }
    } catch {
      /* abaikan */
    }
  }
}

module.exports = { Logger };
