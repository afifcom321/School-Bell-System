'use strict';
const { isValidTimeZone, isValidDate } = require('./scheduler/timeUtil');

const int = (v, fallback = null) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : fallback;
};
const clamp = (n, lo, hi) => Math.min(Math.max(n, lo), hi);

/** Ubah pasangan key/value mentah dari DB menjadi objek bertipe */
function parseSettings(raw = {}) {
  let holidays = [];
  try {
    const parsed = JSON.parse(raw.holidays || '[]');
    if (Array.isArray(parsed)) {
      holidays = parsed
        .filter((h) => h && isValidDate(h.start) && isValidDate(h.end || h.start))
        .map((h) => ({ start: h.start, end: h.end || h.start, name: String(h.name || 'Libur').slice(0, 80) }));
    }
  } catch {
    /* abaikan */
  }
  const examUntil = int(raw.exam_until);
  const pauseUntil = int(raw.pause_until);
  return {
    schoolName: raw.school_name || 'Sekolah Kita',
    timezone: isValidTimeZone(raw.timezone) ? raw.timezone : 'Asia/Jakarta',
    timeFormat: raw.time_format === '12' ? '12' : '24',
    masterVolume: clamp(int(raw.master_volume, 80), 0, 100),
    enabled: raw.scheduler_enabled !== '0',
    defaultSoundId: int(raw.default_sound_id),
    examMode: raw.exam_mode === '1',
    examUntil: examUntil && examUntil > 0 ? examUntil : null,
    pauseUntil: pauseUntil && pauseUntil > 0 ? pauseUntil : null,
    holidays,
    catchupSeconds: clamp(int(raw.catchup_seconds, 120), 0, 3600),
    testSoundSeconds: clamp(int(raw.test_sound_seconds, 4), 1, 30),
    logRetentionDays: clamp(int(raw.log_retention_days, 90), 1, 3650),
    autoBackup: raw.auto_backup !== '0',
  };
}

/**
 * Validasi permintaan perubahan pengaturan dari API (camelCase) → pasangan key/value DB.
 * Mengembalikan { values } atau { error }.
 */
function buildSettingsPatch(body) {
  const values = {};
  const b = body || {};
  if ('schoolName' in b) {
    const s = String(b.schoolName).trim();
    if (!s || s.length > 80) return { error: 'Nama sekolah wajib diisi (maks. 80 karakter)' };
    values.school_name = s;
  }
  if ('timezone' in b) {
    if (!isValidTimeZone(b.timezone)) return { error: 'Timezone tidak valid' };
    values.timezone = b.timezone;
  }
  if ('timeFormat' in b) {
    if (!['12', '24'].includes(String(b.timeFormat))) return { error: 'Format jam harus 12 atau 24' };
    values.time_format = String(b.timeFormat);
  }
  if ('masterVolume' in b) {
    const n = int(b.masterVolume);
    if (n === null || n < 0 || n > 100) return { error: 'Volume master harus 0–100' };
    values.master_volume = String(n);
  }
  if ('defaultSoundId' in b) {
    values.default_sound_id = b.defaultSoundId === null || b.defaultSoundId === '' ? '' : String(int(b.defaultSoundId, ''));
  }
  if ('holidays' in b) {
    if (!Array.isArray(b.holidays) || b.holidays.length > 200) return { error: 'Daftar libur tidak valid' };
    const list = [];
    for (const h of b.holidays) {
      if (!h || !isValidDate(h.start) || !isValidDate(h.end || h.start)) return { error: 'Tanggal libur tidak valid' };
      if ((h.end || h.start) < h.start) return { error: 'Tanggal akhir libur tidak boleh sebelum tanggal mulai' };
      list.push({ start: h.start, end: h.end || h.start, name: String(h.name || 'Libur').trim().slice(0, 80) || 'Libur' });
    }
    list.sort((a, b2) => a.start.localeCompare(b2.start));
    values.holidays = JSON.stringify(list);
  }
  if ('testSoundSeconds' in b) {
    const n = int(b.testSoundSeconds);
    if (n === null || n < 1 || n > 30) return { error: 'Durasi test sound harus 1–30 detik' };
    values.test_sound_seconds = String(n);
  }
  if ('catchupSeconds' in b) {
    const n = int(b.catchupSeconds);
    if (n === null || n < 0 || n > 3600) return { error: 'Toleransi keterlambatan harus 0–3600 detik' };
    values.catchup_seconds = String(n);
  }
  if ('logRetentionDays' in b) {
    const n = int(b.logRetentionDays);
    if (n === null || n < 1 || n > 3650) return { error: 'Retensi log harus 1–3650 hari' };
    values.log_retention_days = String(n);
  }
  if ('autoBackup' in b) values.auto_backup = b.autoBackup ? '1' : '0';
  return { values };
}

module.exports = { parseSettings, buildSettingsPatch };
