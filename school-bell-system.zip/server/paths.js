'use strict';
/**
 * Menentukan lokasi folder kerja aplikasi.
 *
 * - Development / headless : folder project (school-bell/)
 * - Aplikasi Windows (build): %APPDATA%/School Bell System  (diset oleh desktop/main.js lewat BELL_HOME)
 * - Bisa dioverride dengan environment variable BELL_HOME
 */
const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = path.resolve(__dirname, '..');

function getPaths(homeOverride) {
  const home = path.resolve(homeOverride || process.env.BELL_HOME || PROJECT_ROOT);
  const paths = {
    home,
    dataDir: path.join(home, 'data'),
    soundsDir: path.join(home, 'sounds'),
    logsDir: path.join(home, 'logs'),
    backupsDir: path.join(home, 'data', 'backups'),
    dbFile: path.join(home, 'data', 'school-bell.db'),
    configFile: path.join(home, 'data', 'config.json'),
    // Berkas bawaan aplikasi (read-only, ikut ter-package)
    frontendDir: path.join(PROJECT_ROOT, 'frontend'),
    defaultSoundsDir: path.join(PROJECT_ROOT, 'default-sounds'),
  };
  for (const dir of [paths.dataDir, paths.soundsDir, paths.logsDir, paths.backupsDir]) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return paths;
}

/**
 * Mengubah path relatif (disimpan di database) menjadi path absolut,
 * dan MEMASTIKAN hasilnya berada di dalam folder sounds (anti path traversal).
 * Mengembalikan null jika path tidak aman.
 */
function resolveSoundPath(paths, relativePath) {
  if (typeof relativePath !== 'string' || !relativePath || relativePath.includes('\0')) return null;
  const abs = path.resolve(paths.home, relativePath);
  const rel = path.relative(paths.soundsDir, abs);
  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) return null;
  return abs;
}

module.exports = { getPaths, resolveSoundPath, PROJECT_ROOT };
