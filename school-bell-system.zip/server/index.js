'use strict';
/** Titik masuk modul server — dipakai oleh aplikasi desktop (desktop/main.js) */
const { BellApp } = require('./app');

async function createBellApp(options = {}) {
  return new BellApp(options).init();
}

module.exports = { createBellApp, BellApp };
