'use strict';
const express = require('express');

/** Bungkus handler async agar error masuk ke error middleware (server tidak crash) */
const ah = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/** Nama pelaku untuk log: "admin (192.168.1.21)" */
const actorOf = (req) => (req.user ? req.user.username : 'sistem');

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function createApiRouter(bell, hub) {
  const router = express.Router();

  // Publik: hanya untuk mengecek apakah server hidup (tidak memuat data sensitif)
  router.get('/health', (req, res) =>
    res.json({ ok: true, app: 'School Bell System', version: bell.version, database: !bell.dbError && !!bell.store.db })
  );

  // Jika database tidak bisa dibuka, semua endpoint lain memberi pesan jelas (bukan crash)
  router.use((req, res, next) => {
    if (bell.store && bell.store.db) return next();
    res.status(503).json({
      error: `Database tidak tersedia: ${bell.dbError || 'belum siap'}. Bel otomatis memakai data terakhir yang tersimpan. Periksa folder data/ lalu restart aplikasi.`,
      code: 'DB_UNAVAILABLE',
    });
  });

  const ctx = { bell, hub, ah, HttpError, actorOf };
  router.use('/auth', require('./auth')(ctx));
  router.use(require('./status')(ctx));
  router.use('/schedules', require('./schedules')(ctx));
  router.use('/sounds', require('./sounds')(ctx));
  router.use('/bell', require('./bell')(ctx));
  router.use('/scheduler', require('./schedulerControl')(ctx));
  router.use('/logs', require('./logs')(ctx));
  router.use('/settings', require('./settingsRoutes')(ctx));
  router.use('/system', require('./system')(ctx));
  return router;
}

module.exports = { createApiRouter, ah, HttpError, actorOf };
