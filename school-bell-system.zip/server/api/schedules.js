'use strict';
const express = require('express');
const { requireAuth, requireAdmin } = require('../auth/middleware');
const { isValidDate, isValidHHMM } = require('../scheduler/timeUtil');

const DAY_NAMES = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

/** Validasi & normalisasi payload jadwal. Mengembalikan { value } atau { error }. */
function validateSchedule(body, store) {
  const b = body || {};
  const name = typeof b.name === 'string' ? b.name.trim() : '';
  if (!name || name.length > 60) return { error: 'Nama bel wajib diisi (maks. 60 karakter)' };
  if (!isValidHHMM(b.time)) return { error: 'Jam tidak valid (format HH:MM, 24 jam)' };
  const mode = b.mode === 'date' ? 'date' : 'weekly';

  let days = [];
  let date = null;
  if (mode === 'weekly') {
    if (!Array.isArray(b.days)) return { error: 'Pilih minimal satu hari' };
    days = [...new Set(b.days.map(Number))].filter((d) => Number.isInteger(d) && d >= 0 && d <= 6).sort();
    if (!days.length) return { error: 'Pilih minimal satu hari' };
  } else {
    if (!isValidDate(b.date)) return { error: 'Tanggal tidak valid (format YYYY-MM-DD)' };
    date = b.date;
  }

  let soundId = null;
  if (b.soundId !== undefined && b.soundId !== null && b.soundId !== '') {
    soundId = Number(b.soundId);
    if (!Number.isInteger(soundId) || !store.getSound(soundId)) return { error: 'Sound yang dipilih tidak ditemukan' };
  }
  let volume = null;
  if (b.volume !== undefined && b.volume !== null && b.volume !== '') {
    volume = Number(b.volume);
    if (!Number.isInteger(volume) || volume < 0 || volume > 100) return { error: 'Volume harus 0–100' };
  }
  let playSeconds = null;
  if (b.playSeconds !== undefined && b.playSeconds !== null && b.playSeconds !== '') {
    playSeconds = Number(b.playSeconds);
    if (!Number.isInteger(playSeconds) || playSeconds < 1 || playSeconds > 600) return { error: 'Durasi maksimum harus 1–600 detik' };
  }
  return {
    value: { name, time: b.time, mode, days: mode === 'weekly' ? days : [], date, soundId, volume, playSeconds, enabled: b.enabled !== false },
  };
}

module.exports = function scheduleRoutes({ bell, ah, HttpError, actorOf }) {
  const r = express.Router();
  const { store, scheduler, logger } = bell;

  const changed = () => {
    scheduler.reload();
    bell.notifyChange();
  };
  const describe = (s) => `${s.time} ${s.name}`;

  r.get('/', requireAuth, (req, res) => res.json({ schedules: store.listSchedules() }));

  // Pratinjau jadwal pada tanggal tertentu (mis. untuk melihat efek hari libur)
  r.get('/preview', requireAuth, (req, res) => {
    const date = String(req.query.date || '');
    if (!isValidDate(date)) throw new HttpError(400, 'Parameter date harus berformat YYYY-MM-DD');
    scheduler.reload();
    res.json(scheduler.preview(date));
  });

  r.get('/export', requireAdmin, (req, res) => {
    const sounds = new Map(store.listSounds().map((s) => [s.id, s.filename]));
    const data = {
      format: 'school-bell-schedules',
      version: 1,
      exportedAt: new Date().toISOString(),
      schedules: store.listSchedules().map((s) => ({
        name: s.name,
        time: s.time,
        mode: s.mode,
        days: s.days,
        date: s.date,
        sound: s.soundId ? sounds.get(s.soundId) || null : null,
        volume: s.volume,
        playSeconds: s.playSeconds,
        enabled: s.enabled,
      })),
    };
    res.setHeader('Content-Disposition', 'attachment; filename="jadwal-bel.json"');
    res.json(data);
  });

  r.post(
    '/import',
    requireAdmin,
    ah(async (req, res) => {
      const { schedules, mode } = req.body || {};
      if (!Array.isArray(schedules) || schedules.length === 0) throw new HttpError(400, 'Berkas tidak berisi jadwal');
      if (schedules.length > 500) throw new HttpError(400, 'Maksimal 500 jadwal per impor');
      const byFilename = new Map(store.listSounds().map((s) => [s.filename, s.id]));
      const items = [];
      for (let i = 0; i < schedules.length; i++) {
        const raw = { ...schedules[i] };
        raw.soundId = raw.sound ? byFilename.get(String(raw.sound)) ?? null : null;
        const v = validateSchedule(raw, store);
        if (v.error) throw new HttpError(400, `Jadwal #${i + 1}: ${v.error}`);
        items.push(v.value);
      }
      if (mode === 'replace') store.replaceSchedules(items);
      else store.tx(() => items.forEach((d) => store.createSchedule(d)));
      logger.record({
        event: `Jadwal diimpor: ${items.length} item (${mode === 'replace' ? 'menggantikan semua' : 'ditambahkan'})`,
        status: 'ok',
        source: 'admin',
        detail: `oleh ${actorOf(req)}`,
      });
      changed();
      res.json({ ok: true, imported: items.length });
    })
  );

  r.post('/', requireAdmin, (req, res) => {
    const v = validateSchedule(req.body, store);
    if (v.error) throw new HttpError(400, v.error);
    const s = store.createSchedule(v.value);
    logger.record({ event: `Jadwal ditambahkan: ${describe(s)}`, scheduleId: s.id, status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
    changed();
    res.status(201).json({ schedule: s });
  });

  r.put('/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    if (!store.getSchedule(id)) throw new HttpError(404, 'Jadwal tidak ditemukan');
    const v = validateSchedule(req.body, store);
    if (v.error) throw new HttpError(400, v.error);
    const s = store.updateSchedule(id, v.value);
    logger.record({ event: `Jadwal diperbarui: ${describe(s)}`, scheduleId: id, status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
    changed();
    res.json({ schedule: s });
  });

  r.patch('/:id/enabled', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const enabled = !!(req.body && req.body.enabled);
    const s = store.setScheduleEnabled(id, enabled);
    if (!s) throw new HttpError(404, 'Jadwal tidak ditemukan');
    logger.record({
      event: `Jadwal ${enabled ? 'diaktifkan' : 'dinonaktifkan'}: ${describe(s)}`,
      scheduleId: id,
      status: 'ok',
      source: 'admin',
      detail: `oleh ${actorOf(req)}`,
    });
    changed();
    res.json({ schedule: s });
  });

  r.delete('/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const s = store.getSchedule(id);
    if (!s) throw new HttpError(404, 'Jadwal tidak ditemukan');
    store.deleteSchedule(id);
    logger.record({ event: `Jadwal dihapus: ${describe(s)}`, scheduleId: id, status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
    changed();
    res.json({ ok: true });
  });

  return r;
};

module.exports.validateSchedule = validateSchedule;
module.exports.DAY_NAMES = DAY_NAMES;
