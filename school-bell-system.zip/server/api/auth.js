'use strict';
const express = require('express');
const { requireAdmin, setSessionCookie, clearSessionCookie } = require('../auth/middleware');
const { hashPassword, passwordProblem } = require('../auth/authService');

const clientIp = (req) => (req.socket && req.socket.remoteAddress ? req.socket.remoteAddress.replace('::ffff:', '') : 'unknown');

module.exports = function authRoutes({ bell, ah, HttpError, actorOf }) {
  const r = express.Router();
  const { auth, store, logger } = bell;

  r.post(
    '/login',
    ah(async (req, res) => {
      const { username, password } = req.body || {};
      const result = await auth.login(username, password, clientIp(req));
      if (!result.ok) {
        if (result.retryAfter) res.setHeader('Retry-After', String(result.retryAfter));
        return res.status(result.status).json({ error: result.error });
      }
      setSessionCookie(res, result.token, result.maxAgeMs);
      res.json({ user: result.user });
    })
  );

  r.post('/logout', (req, res) => {
    auth.logout(req.sessionToken);
    clearSessionCookie(res);
    res.json({ ok: true });
  });

  r.get('/me', (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'Belum login', code: 'UNAUTHENTICATED' });
    const { tokenHash, ...user } = req.user;
    res.json({ user });
  });

  r.post(
    '/change-password',
    ah(async (req, res) => {
      if (!req.user) throw new HttpError(401, 'Silakan login terlebih dahulu');
      const { currentPassword, newPassword } = req.body || {};
      const result = await auth.changePassword(req.user.id, currentPassword, newPassword, req.user.tokenHash);
      if (!result.ok) throw new HttpError(result.status, result.error);
      res.json({ ok: true });
    })
  );

  // ---------------------------------------------------------- manajemen user (admin)
  r.get('/users', requireAdmin, (req, res) => res.json({ users: store.listUsers() }));

  r.post(
    '/users',
    requireAdmin,
    ah(async (req, res) => {
      const { username, password, role } = req.body || {};
      if (typeof username !== 'string' || !/^[a-zA-Z0-9._-]{3,32}$/.test(username.trim())) {
        throw new HttpError(400, 'Username 3–32 karakter: huruf, angka, titik, garis bawah, atau strip');
      }
      if (!['admin', 'viewer'].includes(role)) throw new HttpError(400, 'Role harus admin atau viewer');
      const problem = passwordProblem(password);
      if (problem) throw new HttpError(400, problem);
      if (store.getUserByUsername(username.trim())) throw new HttpError(409, 'Username sudah dipakai');
      const user = store.createUser({
        username: username.trim(),
        passwordHash: await hashPassword(password),
        role,
        mustChangePassword: false,
      });
      logger.record({ event: `User dibuat: ${user.username} (${role})`, status: 'info', source: 'admin', detail: `oleh ${actorOf(req)}` });
      const { passwordHash, ...safe } = user;
      res.status(201).json({ user: safe });
    })
  );

  r.put(
    '/users/:id',
    requireAdmin,
    ah(async (req, res) => {
      const id = Number(req.params.id);
      const target = store.getUser(id);
      if (!target) throw new HttpError(404, 'User tidak ditemukan');
      const { role, password } = req.body || {};
      const patch = {};
      if (role !== undefined) {
        if (!['admin', 'viewer'].includes(role)) throw new HttpError(400, 'Role harus admin atau viewer');
        if (target.role === 'admin' && role !== 'admin' && store.countAdmins() <= 1) {
          throw new HttpError(400, 'Tidak dapat menurunkan satu-satunya administrator');
        }
        patch.role = role;
      }
      if (password !== undefined && password !== '') {
        const problem = passwordProblem(password);
        if (problem) throw new HttpError(400, problem);
        patch.passwordHash = await hashPassword(password);
        patch.mustChangePassword = false;
      }
      const user = store.updateUser(id, patch);
      if (patch.passwordHash) store.deleteUserSessions(id);
      logger.record({ event: `User diperbarui: ${user.username}`, status: 'info', source: 'admin', detail: `oleh ${actorOf(req)}` });
      const { passwordHash, ...safe } = user;
      res.json({ user: safe });
    })
  );

  r.delete('/users/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const target = store.getUser(id);
    if (!target) throw new HttpError(404, 'User tidak ditemukan');
    if (target.id === req.user.id) throw new HttpError(400, 'Anda tidak dapat menghapus akun Anda sendiri');
    if (target.role === 'admin' && store.countAdmins() <= 1) throw new HttpError(400, 'Tidak dapat menghapus satu-satunya administrator');
    store.deleteUser(id);
    logger.record({ event: `User dihapus: ${target.username}`, status: 'info', source: 'admin', detail: `oleh ${actorOf(req)}` });
    res.json({ ok: true });
  });

  return r;
};
