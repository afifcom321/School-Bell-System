'use strict';
const express = require('express');
const { requireAuth, requireAdmin } = require('../auth/middleware');
const { buildSettingsPatch } = require('../settings');

module.exports = function settingsRoutes({ bell, HttpError, actorOf }) {
  const r = express.Router();
  const { store, scheduler, logger } = bell;

  r.get('/', requireAuth, (req, res) => {
    scheduler.reload();
    const c = scheduler.cfg;
    res.json({
      settings: {
        schoolName: c.schoolName,
        timezone: c.timezone,
        timeFormat: c.timeFormat,
        masterVolume: c.masterVolume,
        defaultSoundId: c.defaultSoundId,
        holidays: c.holidays,
        testSoundSeconds: c.testSoundSeconds,
        catchupSeconds: c.catchupSeconds,
        logRetentionDays: c.logRetentionDays,
        autoBackup: c.autoBackup,
      },
    });
  });

  r.put('/', requireAdmin, (req, res) => {
    const { values, error } = buildSettingsPatch(req.body);
    if (error) throw new HttpError(400, error);
    if (!Object.keys(values).length) throw new HttpError(400, 'Tidak ada perubahan pengaturan');
    if ('default_sound_id' in values && values.default_sound_id !== '' && !store.getSound(Number(values.default_sound_id))) {
      throw new HttpError(400, 'Sound default tidak ditemukan');
    }
    store.setSettings(values);
    logger.record({ event: 'Pengaturan diperbarui', status: 'ok', source: 'admin', detail: `${Object.keys(req.body || {}).join(', ')} — oleh ${actorOf(req)}` });
    scheduler.reload();
    bell.notifyChange();
    res.json({ ok: true });
  });

  return r;
};
