'use strict';
const os = require('os');
const express = require('express');
const { requireAuth } = require('../auth/middleware');

module.exports = function statusRoutes({ bell, hub }) {
  const r = express.Router();

  r.get('/status', requireAuth, (req, res) => res.json(bell.buildStatus()));

  // Server-Sent Events: dashboard menerima perubahan status secara realtime
  r.get('/events', requireAuth, (req, res) => hub.add(req, res));

  r.get('/system', requireAuth, (req, res) => {
    const status = bell.buildStatus();
    const isAdmin = req.user.role === 'admin';
    res.json({
      app: { name: 'School Bell System', version: bell.version },
      runtime: {
        node: process.versions.node,
        electron: process.versions.electron || null,
        platform: `${os.platform()} ${os.release()}`,
        hostname: os.hostname(),
        osTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        uptimeSec: Math.round(process.uptime()),
        memoryMb: Math.round(process.memoryUsage().rss / 1048576),
      },
      server: bell.getInfo(),
      audioBackend: bell.audio.backendName,
      db: status.db,
      scheduler: status.scheduler,
      paths: isAdmin
        ? { home: bell.paths.home, sounds: bell.paths.soundsDir, database: bell.paths.dbFile, logs: bell.paths.logsDir, backups: bell.paths.backupsDir }
        : null,
    });
  });

  return r;
};
