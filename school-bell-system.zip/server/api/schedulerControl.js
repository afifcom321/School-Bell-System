'use strict';
const express = require('express');
const { requireAuth, requireAdmin } = require('../auth/middleware');
const { partsInTz, zonedToEpoch, addDays, isValidDate, isValidHHMM } = require('../scheduler/timeUtil');

module.exports = function schedulerControlRoutes({ bell, HttpError, actorOf }) {
  const r = express.Router();
  const { store, scheduler, logger } = bell;

  const apply = () => {
    scheduler.reload();
    bell.notifyChange();
  };
  const fmt = (epoch) => new Intl.DateTimeFormat('id-ID', { timeZone: scheduler.cfg.timezone, dateStyle: 'medium', timeStyle: 'short', hourCycle: 'h23' }).format(new Date(epoch));

  // Saklar jadwal otomatis
  r.post('/toggle', requireAdmin, (req, res) => {
    const enabled = !!(req.body && req.body.enabled);
    store.setSettings({ scheduler_enabled: enabled ? '1' : '0' });
    logger.record({ event: `Jadwal otomatis ${enabled ? 'diaktifkan' : 'dinonaktifkan'}`, status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
    apply();
    res.json({ ok: true, enabled });
  });

  // Jeda sementara: { minutes } | { untilTomorrow: true } | { clear: true }
  r.post('/pause', requireAdmin, (req, res) => {
    const b = req.body || {};
    if (b.clear) {
      store.setSettings({ pause_until: '' });
      logger.record({ event: 'Jeda bel dibatalkan', status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
      apply();
      return res.json({ ok: true, until: null });
    }
    let until;
    if (b.untilTomorrow) {
      const today = partsInTz(Date.now(), scheduler.cfg.timezone).date;
      until = zonedToEpoch(addDays(today, 1), '00:00', scheduler.cfg.timezone);
    } else {
      const minutes = Number(b.minutes);
      if (!Number.isFinite(minutes) || minutes < 1 || minutes > 7 * 24 * 60) throw new HttpError(400, 'Durasi jeda harus 1 menit – 7 hari');
      until = Date.now() + Math.round(minutes) * 60000;
    }
    store.setSettings({ pause_until: String(until) });
    logger.record({ event: 'Bel otomatis dijeda sementara', status: 'ok', source: 'admin', detail: `sampai ${fmt(until)}, oleh ${actorOf(req)}` });
    apply();
    res.json({ ok: true, until });
  });

  // Mode ujian: { enabled, untilMinutes? , untilDate? }
  r.post('/exam', requireAdmin, (req, res) => {
    const b = req.body || {};
    if (!b.enabled) {
      store.setSettings({ exam_mode: '0', exam_until: '' });
      logger.record({ event: 'Mode ujian dimatikan', status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
      apply();
      return res.json({ ok: true, enabled: false });
    }
    let until = '';
    if (b.untilDate) {
      if (!isValidDate(b.untilDate)) throw new HttpError(400, 'Tanggal tidak valid');
      until = zonedToEpoch(addDays(b.untilDate, 1), '00:00', scheduler.cfg.timezone); // berlaku sampai akhir tanggal tsb
    } else if (b.untilMinutes) {
      const m = Number(b.untilMinutes);
      if (!Number.isFinite(m) || m < 1 || m > 30 * 24 * 60) throw new HttpError(400, 'Durasi mode ujian tidak valid');
      until = Date.now() + Math.round(m) * 60000;
    }
    store.setSettings({ exam_mode: '1', exam_until: String(until) });
    logger.record({
      event: 'Mode ujian diaktifkan — bel otomatis ditahan',
      status: 'ok',
      source: 'admin',
      detail: `${until ? `sampai ${fmt(until)}` : 'sampai dimatikan manual'}, oleh ${actorOf(req)}`,
    });
    apply();
    res.json({ ok: true, enabled: true, until: until || null });
  });

  // Simulasi (dry-run): tidak membunyikan apa pun
  r.post('/test', requireAuth, (req, res) => {
    const { date, time } = req.body || {};
    if (!isValidDate(date)) throw new HttpError(400, 'Tanggal tidak valid');
    if (!isValidHHMM(time)) throw new HttpError(400, 'Jam tidak valid (HH:MM)');
    scheduler.reload();
    res.json(scheduler.testAt(date, time));
  });

  return r;
};
