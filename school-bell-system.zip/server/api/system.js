'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const { requireAdmin } = require('../auth/middleware');

const SQLITE_MAGIC = 'SQLite format 3\u0000';

module.exports = function systemRoutes({ bell, ah, HttpError, actorOf }) {
  const r = express.Router();
  const { store, logger, paths, scheduler } = bell;
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 100 * 1024 * 1024, files: 1, fields: 2 } });

  r.get('/backups', requireAdmin, (req, res) => res.json({ backups: store.listBackups(), folder: paths.backupsDir }));

  // Buat backup di folder data/backups (di komputer server)
  r.post('/backups', requireAdmin, (req, res) => {
    const file = store.createBackup('manual');
    logger.record({ event: 'Backup database dibuat', status: 'ok', source: 'admin', detail: `${path.basename(file)} — oleh ${actorOf(req)}` });
    res.status(201).json({ name: path.basename(file), backups: store.listBackups() });
  });

  // Unduh backup terbaru (dibuat saat itu juga) ke perangkat yang sedang dipakai
  r.get('/backups/download', requireAdmin, (req, res, next) => {
    // Catatan: jangan berawalan titik — res.download menolak dotfile
    const tmp = path.join(paths.backupsDir, `tmp-download-${crypto.randomBytes(4).toString('hex')}.db`);
    try {
      store.backupTo(tmp);
    } catch (err) {
      return next(err);
    }
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    const name = `school-bell-backup-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.db`;
    logger.record({ event: 'Backup database diunduh', status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
    res.download(tmp, name, (err) => {
      fs.unlink(tmp, () => {});
      if (err && !res.headersSent) next(err);
    });
  });

  r.get('/backups/file/:name', requireAdmin, (req, res) => {
    const name = String(req.params.name);
    if (!/^school-bell-[A-Za-z0-9-]+\.db$/.test(name)) throw new HttpError(400, 'Nama backup tidak valid');
    const abs = path.join(paths.backupsDir, name);
    if (path.dirname(abs) !== paths.backupsDir || !fs.existsSync(abs)) throw new HttpError(404, 'Backup tidak ditemukan');
    res.download(abs, name, (err) => {
      if (err && !res.headersSent) res.status(500).json({ error: 'Gagal mengunduh backup' });
    });
  });

  // Restore dari berkas .db yang diunggah
  r.post(
    '/restore',
    requireAdmin,
    upload.single('file'),
    ah(async (req, res) => {
      if (!req.file) throw new HttpError(400, 'Pilih berkas backup (.db)');
      if (req.file.buffer.toString('latin1', 0, 16) !== SQLITE_MAGIC) throw new HttpError(400, 'Berkas bukan database SQLite');
      const tmp = path.join(paths.backupsDir, `tmp-restore-${crypto.randomBytes(4).toString('hex')}.db`);
      fs.writeFileSync(tmp, req.file.buffer, { mode: 0o600 });
      let safety;
      try {
        safety = store.restoreFrom(tmp);
      } catch (err) {
        throw new HttpError(400, err.message);
      } finally {
        fs.unlink(tmp, () => {});
      }
      scheduler.reload();
      logger.record({
        event: 'Database dipulihkan dari backup',
        status: 'warning',
        source: 'admin',
        detail: `Data sebelumnya diamankan di ${path.basename(safety)} — oleh ${actorOf(req)}`,
      });
      bell.notifyChange();
      res.json({ ok: true, safetyBackup: path.basename(safety), note: 'Silakan login kembali. Berkas audio (folder sounds) tidak ikut backup database.' });
    })
  );

  r.post(
    '/time-sync',
    requireAdmin,
    ah(async (req, res) => {
      const result = await bell.syncSystemTime();
      res.status(result.ok ? 200 : 500).json(result);
    })
  );

  return r;
};
