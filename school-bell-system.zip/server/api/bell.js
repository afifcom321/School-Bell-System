'use strict';
const express = require('express');
const { requireAdmin } = require('../auth/middleware');

module.exports = function bellRoutes({ bell, HttpError, actorOf }) {
  const r = express.Router();

  // Bunyikan bel sekarang (opsional: pilih sound, volume, durasi)
  r.post('/trigger', requireAdmin, (req, res) => {
    const b = req.body || {};
    if (b.soundId !== undefined && b.soundId !== null && !Number.isInteger(Number(b.soundId))) throw new HttpError(400, 'soundId tidak valid');
    if (b.volume !== undefined && b.volume !== null && !(Number(b.volume) >= 0 && Number(b.volume) <= 100)) throw new HttpError(400, 'Volume harus 0–100');
    if (b.seconds !== undefined && b.seconds !== null && !(Number(b.seconds) >= 1 && Number(b.seconds) <= 600)) throw new HttpError(400, 'Durasi harus 1–600 detik');
    const result = bell.triggerManual({
      soundId: b.soundId ? Number(b.soundId) : null,
      volume: b.volume,
      seconds: b.seconds ? Number(b.seconds) : null,
      actor: actorOf(req),
    });
    if (!result.ok) throw new HttpError(500, result.error);
    res.json(result);
  });

  r.post('/stop', requireAdmin, (req, res) => {
    const was = bell.audio.state();
    bell.audio.stop();
    if (was.ringing) bell.logger.record({ event: `Bel dihentikan manual oleh ${actorOf(req)}`, status: 'info', source: 'manual' });
    res.json({ ok: true });
  });

  return r;
};
