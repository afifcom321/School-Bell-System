'use strict';
const fs = require('fs');
const path = require('path');
const express = require('express');
const multer = require('multer');
const { requireAuth, requireAdmin } = require('../auth/middleware');
const { resolveSoundPath } = require('../paths');
const { validateAudioUpload, displayNameFrom, safeStoredFilename, readDuration, MAX_UPLOAD_BYTES } = require('../audio/validate');

module.exports = function soundRoutes({ bell, ah, HttpError, actorOf }) {
  const r = express.Router();
  const { store, scheduler, logger, paths } = bell;

  // File ditahan di memori (maks. 20 MB), divalidasi dulu, baru ditulis ke disk oleh server
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_UPLOAD_BYTES, files: 1, fields: 5, fieldSize: 1024 },
  });

  const changed = () => {
    scheduler.reload();
    bell.notifyChange();
  };

  const view = (s) => {
    const abs = resolveSoundPath(paths, s.filepath);
    return {
      id: s.id,
      name: s.name,
      filename: s.filename,
      mime: s.mime,
      size: s.size,
      volume: s.volume,
      duration: s.duration,
      maxPlaySeconds: s.maxPlaySeconds,
      isBuiltin: s.isBuiltin,
      isDefault: scheduler.cfg.defaultSoundId === s.id,
      usedBy: store.countSchedulesUsingSound(s.id),
      fileMissing: !abs || !fs.existsSync(abs),
    };
  };

  r.get('/', requireAuth, (req, res) => {
    scheduler.reload();
    res.json({
      sounds: store.listSounds().map(view),
      folder: req.user.role === 'admin' ? paths.soundsDir : null,
      maxUploadMb: Math.round(MAX_UPLOAD_BYTES / 1048576),
    });
  });

  // Stream file audio (untuk preview di browser) — hanya untuk user yang login, path selalu dari database
  r.get('/:id/file', requireAuth, (req, res) => {
    const s = store.getSound(Number(req.params.id));
    if (!s) throw new HttpError(404, 'Sound tidak ditemukan');
    const abs = resolveSoundPath(paths, s.filepath);
    if (!abs || !fs.existsSync(abs)) throw new HttpError(404, 'File sound tidak ditemukan di disk');
    res.sendFile(abs, {
      headers: { 'Content-Type': s.mime || 'audio/mpeg', 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': 'inline' },
      dotfiles: 'deny',
    });
  });

  r.post(
    '/upload',
    requireAdmin,
    upload.single('file'),
    ah(async (req, res) => {
      const check = validateAudioUpload(req.file);
      if (!check.ok) throw new HttpError(400, check.error);

      const storedName = safeStoredFilename(req.file.originalname, check.ext);
      const dest = path.join(paths.soundsDir, storedName);
      // Pastikan hasil akhir benar-benar di dalam folder sounds
      if (path.dirname(dest) !== paths.soundsDir) throw new HttpError(400, 'Nama berkas tidak valid');

      const duration = await readDuration(req.file.buffer, check.mime);
      const wanted = typeof req.body.name === 'string' ? req.body.name.trim().slice(0, 60) : '';
      fs.writeFileSync(dest, req.file.buffer, { flag: 'wx', mode: 0o644 }); // 'wx': tidak menimpa berkas lain
      let sound;
      try {
        sound = store.createSound({
          name: wanted || displayNameFrom(req.file.originalname),
          filename: storedName,
          filepath: `sounds/${storedName}`,
          mime: check.mime,
          size: req.file.size,
          volume: 100,
          duration,
          maxPlaySeconds: null,
          isBuiltin: false,
        });
      } catch (err) {
        fs.unlinkSync(dest); // jangan tinggalkan berkas yatim
        throw err;
      }
      logger.record({ event: `Sound diunggah: ${sound.name}`, status: 'ok', source: 'admin', detail: `${storedName} (${Math.round(req.file.size / 1024)} KB) oleh ${actorOf(req)}` });
      if (!scheduler.cfg.defaultSoundId) store.setSettings({ default_sound_id: String(sound.id) });
      changed();
      res.status(201).json({ sound: view(sound) });
    })
  );

  r.put('/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const s = store.getSound(id);
    if (!s) throw new HttpError(404, 'Sound tidak ditemukan');
    const b = req.body || {};
    const name = b.name === undefined ? s.name : String(b.name).trim();
    if (!name || name.length > 60) throw new HttpError(400, 'Nama sound wajib diisi (maks. 60 karakter)');
    const volume = b.volume === undefined ? s.volume : Number(b.volume);
    if (!Number.isInteger(volume) || volume < 0 || volume > 100) throw new HttpError(400, 'Volume harus 0–100');
    let maxPlaySeconds = s.maxPlaySeconds;
    if (b.maxPlaySeconds !== undefined) {
      if (b.maxPlaySeconds === null || b.maxPlaySeconds === '') maxPlaySeconds = null;
      else {
        maxPlaySeconds = Number(b.maxPlaySeconds);
        if (!Number.isInteger(maxPlaySeconds) || maxPlaySeconds < 1 || maxPlaySeconds > 600) throw new HttpError(400, 'Durasi maksimum harus 1–600 detik');
      }
    }
    const updated = store.updateSound(id, { name, volume, maxPlaySeconds });
    logger.record({ event: `Sound diperbarui: ${updated.name}`, status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
    changed();
    res.json({ sound: view(updated) });
  });

  r.post('/:id/default', requireAdmin, (req, res) => {
    const s = store.getSound(Number(req.params.id));
    if (!s) throw new HttpError(404, 'Sound tidak ditemukan');
    store.setSettings({ default_sound_id: String(s.id) });
    logger.record({ event: `Sound default diubah: ${s.name}`, status: 'ok', source: 'admin', detail: `oleh ${actorOf(req)}` });
    changed();
    res.json({ ok: true });
  });

  // Putar sound ini di speaker SERVER (uji coba singkat)
  r.post('/:id/test', requireAdmin, (req, res) => {
    const s = store.getSound(Number(req.params.id));
    if (!s) throw new HttpError(404, 'Sound tidak ditemukan');
    const result = bell.triggerManual({ soundId: s.id, volume: (req.body || {}).volume, actor: actorOf(req), test: true });
    if (!result.ok) throw new HttpError(500, result.error);
    res.json(result);
  });

  r.delete('/:id', requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    const s = store.getSound(id);
    if (!s) throw new HttpError(404, 'Sound tidak ditemukan');
    const usedBy = store.countSchedulesUsingSound(id);
    store.deleteSound(id);
    if (scheduler.cfg.defaultSoundId === id) store.setSettings({ default_sound_id: '' });
    const abs = resolveSoundPath(paths, s.filepath);
    if (abs) {
      try {
        fs.unlinkSync(abs);
      } catch {
        /* berkas sudah tidak ada */
      }
    }
    logger.record({
      event: `Sound dihapus: ${s.name}`,
      status: 'ok',
      source: 'admin',
      detail: `oleh ${actorOf(req)}${usedBy ? ` — ${usedBy} jadwal kini memakai sound default` : ''}`,
    });
    changed();
    res.json({ ok: true, affectedSchedules: usedBy });
  });

  return r;
};
