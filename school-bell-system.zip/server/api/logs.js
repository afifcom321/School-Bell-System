'use strict';
const express = require('express');
const { requireAuth, requireAdmin } = require('../auth/middleware');

module.exports = function logRoutes({ bell, actorOf }) {
  const r = express.Router();

  r.get('/', requireAuth, (req, res) => {
    const status = ['ok', 'info', 'warning', 'error', 'skipped', 'missed'].includes(req.query.status) ? req.query.status : undefined;
    res.json(bell.store.listLogs({ limit: req.query.limit, offset: req.query.offset, status }));
  });

  r.delete('/', requireAdmin, (req, res) => {
    const removed = bell.store.clearLogs();
    bell.logger.record({ event: `Log dibersihkan (${removed} entri)`, status: 'info', source: 'admin', detail: `oleh ${actorOf(req)}` });
    res.json({ ok: true, removed });
  });

  return r;
};
