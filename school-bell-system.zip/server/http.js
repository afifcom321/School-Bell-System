'use strict';
const http = require('http');
const express = require('express');
const { attachUser, sameOriginOnly } = require('./auth/middleware');
const { createApiRouter } = require('./api');

/**
 * Membuat web server (dashboard + REST API). Mendengarkan pada 0.0.0.0 sehingga dapat diakses dari
 * perangkat lain di jaringan lokal: http://IP-SERVER:PORT
 */
function createHttpServer(bell) {
  const app = express();
  app.disable('x-powered-by');

  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; img-src 'self' data:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
    );
    next();
  });

  app.use(express.json({ limit: '2mb' }));
  app.use(attachUser(bell.auth));

  // ---- SSE hub: dorong status & event ke browser secara realtime
  const clients = new Set();
  const send = (res, event, data) => {
    try {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    } catch {
      /* koneksi putus */
    }
  };
  const broadcast = (event, data) => clients.forEach((res) => send(res, event, data));
  const hub = {
    add(req, res) {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no',
      });
      res.write('retry: 3000\n\n');
      clients.add(res);
      try {
        send(res, 'status', bell.buildStatus());
      } catch {
        /* status gagal dibangun: klien akan mencoba lagi lewat polling */
      }
      req.on('close', () => clients.delete(res));
    },
  };
  const onChange = () => {
    if (!clients.size) return;
    try {
      broadcast('status', bell.buildStatus());
    } catch {
      /* abaikan */
    }
  };
  const onProblem = (p) => broadcast('problem', p);
  const onLog = (e) => broadcast('log', e);
  bell.on('change', onChange);
  bell.on('problem', onProblem);
  bell.on('log', onLog);
  const heartbeat = setInterval(() => clients.forEach((res) => res.write(': ping\n\n')), 15000);
  heartbeat.unref();

  // ---- REST API
  app.use('/api', sameOriginOnly, createApiRouter(bell, hub));
  app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint tidak ditemukan' }));

  // ---- Frontend statis
  app.use(express.static(bell.paths.frontendDir, { index: 'index.html', maxAge: 0 }));

  // ---- Penanganan error terpusat
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Format JSON tidak valid' });
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Data terlalu besar' });
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'Ukuran berkas melebihi batas yang diizinkan' });
    if (err.code === 'LIMIT_UNEXPECTED_FILE' || (err.name === 'MulterError')) return res.status(400).json({ error: 'Upload tidak valid' });
    const isDb = /sqlite|database|SQLITE/i.test(String(err.code || '') + String(err.message || ''));
    const status = err.status && err.status < 500 ? err.status : 500;
    if (status >= 500) bell.logger.system('error', `${req.method} ${req.originalUrl}: ${err.stack || err.message}`);
    res.status(status).json({
      error: status < 500 ? err.message : isDb ? `Database bermasalah: ${err.message}` : `Terjadi kesalahan pada server: ${err.message}`,
      code: isDb ? 'DB_ERROR' : undefined,
    });
  });

  const server = http.createServer(app);
  server.keepAliveTimeout = 65000;

  return {
    listen(port, host) {
      return new Promise((resolve, reject) => {
        const onErr = (err) => reject(err);
        server.once('error', onErr);
        server.listen(port, host, () => {
          server.removeListener('error', onErr);
          server.on('error', (e) => bell.logger.system('error', `HTTP server error: ${e.message}`));
          resolve();
        });
      });
    },
    close() {
      bell.off('change', onChange);
      bell.off('problem', onProblem);
      bell.off('log', onLog);
      clearInterval(heartbeat);
      clients.forEach((res) => {
        try {
          res.end();
        } catch {
          /* abaikan */
        }
      });
      clients.clear();
      return new Promise((resolve) => {
        server.close(() => resolve());
        server.closeAllConnections && server.closeAllConnections();
      });
    },
  };
}

module.exports = { createHttpServer };
