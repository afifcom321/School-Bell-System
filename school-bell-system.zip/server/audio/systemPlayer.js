'use strict';
/**
 * Pemutar audio cadangan berbasis perintah sistem — dipakai saat server dijalankan TANPA Electron
 * (npm run server). Pada aplikasi desktop, pemutar utama adalah jendela audio Electron.
 *
 *  Windows : PowerShell + System.Windows.Media.MediaPlayer (mp3/wav/ogg tergantung codec Windows)
 *  macOS   : afplay
 *  Linux   : ffplay → mpv → paplay → aplay (yang tersedia)
 */
const { spawn, spawnSync } = require('child_process');

function commandExists(cmd) {
  const probe = process.platform === 'win32' ? 'where' : 'which';
  try {
    return spawnSync(probe, [cmd], { stdio: 'ignore' }).status === 0;
  } catch {
    return false;
  }
}

function psQuote(s) {
  return `'${String(s).replace(/'/g, "''")}'`;
}

function buildCommand(filepath, volume, seconds) {
  const pct = Math.round(volume * 100);
  if (process.platform === 'win32') {
    const script = [
      'Add-Type -AssemblyName presentationCore',
      '$p = New-Object System.Windows.Media.MediaPlayer',
      `$p.Open([Uri]${psQuote(filepath)})`,
      `$p.Volume = ${volume.toFixed(2)}`,
      '$p.Play()',
      '$w = 0; while (-not $p.NaturalDuration.HasTimeSpan -and $w -lt 50) { Start-Sleep -Milliseconds 100; $w++ }',
      '$d = if ($p.NaturalDuration.HasTimeSpan) { $p.NaturalDuration.TimeSpan.TotalSeconds } else { 10 }',
      `$lim = ${seconds ? Number(seconds) : 0}`,
      'if ($lim -gt 0 -and $lim -lt $d) { $d = $lim }',
      'Start-Sleep -Milliseconds ([int]($d * 1000) + 300)',
      '$p.Stop(); $p.Close()',
    ].join('; ');
    const encoded = Buffer.from(script, 'utf16le').toString('base64');
    return { cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded] };
  }
  if (process.platform === 'darwin') {
    const args = ['-v', String(volume)];
    if (seconds) args.push('-t', String(seconds));
    return { cmd: 'afplay', args: [...args, filepath] };
  }
  if (commandExists('ffplay')) {
    const args = ['-nodisp', '-autoexit', '-loglevel', 'quiet', '-volume', String(pct)];
    if (seconds) args.push('-t', String(seconds));
    return { cmd: 'ffplay', args: [...args, filepath] };
  }
  if (commandExists('mpv')) {
    const args = ['--no-video', '--really-quiet', `--volume=${pct}`];
    if (seconds) args.push(`--length=${seconds}`);
    return { cmd: 'mpv', args: [...args, filepath] };
  }
  if (commandExists('paplay')) return { cmd: 'paplay', args: [`--volume=${Math.round(volume * 65536)}`, filepath] };
  if (commandExists('aplay')) return { cmd: 'aplay', args: ['-q', filepath] };
  return null;
}

function createSystemBackend() {
  let child = null;
  return {
    name: `system (${process.platform})`,
    play({ filepath, volume, seconds }) {
      return new Promise((resolve, reject) => {
        const spec = buildCommand(filepath, volume, seconds);
        if (!spec) return reject(new Error('Tidak ada pemutar audio di sistem ini (pasang ffplay/mpv/paplay)'));
        let killedByTimer = false;
        let timer = null;
        try {
          child = spawn(spec.cmd, spec.args, { stdio: 'ignore', windowsHide: true });
        } catch (err) {
          return reject(err);
        }
        // Batas durasi untuk pemutar yang tidak punya opsi durasi
        if (seconds) {
          timer = setTimeout(() => {
            killedByTimer = true;
            try {
              child.kill();
            } catch {
              /* abaikan */
            }
          }, (seconds + 1) * 1000);
        }
        child.on('error', (err) => {
          clearTimeout(timer);
          reject(new Error(`Gagal menjalankan ${spec.cmd}: ${err.message}`));
        });
        child.on('exit', (code, signal) => {
          clearTimeout(timer);
          child = null;
          if (code === 0 || killedByTimer || signal) resolve();
          else reject(new Error(`${spec.cmd} berhenti dengan kode ${code}`));
        });
      });
    },
    stop() {
      if (child) {
        try {
          child.kill();
        } catch {
          /* abaikan */
        }
      }
    },
  };
}

module.exports = { createSystemBackend };
