'use strict';
const fs = require('fs');
const { EventEmitter } = require('events');
const { resolveSoundPath } = require('../paths');

const MAX_QUEUE = 3;
const DEFAULT_MAX_SECONDS = 180; // batas pengaman bila durasi file tidak diketahui

/**
 * AudioManager — satu-satunya pintu untuk membunyikan suara di komputer server.
 *
 * Backend (pemutar sebenarnya) bisa diganti:
 *   - Electron : jendela tersembunyi berisi <audio> (desktop/audioPlayer.js)
 *   - Sistem   : PowerShell / afplay / ffplay / mpv / paplay (server/audio/systemPlayer.js)
 *   - Null     : simulasi untuk testing (BELL_AUDIO=null)
 *
 * Kontrak backend:
 *   backend.name : string
 *   backend.play({ filepath, volume (0..1), seconds (number|null) }) : Promise<void>   (resolve saat selesai)
 *   backend.stop() : void
 *
 * Bel terjadwal masuk ANTRIAN (maks 3); bel manual menginterupsi bel yang sedang berbunyi.
 * Kegagalan memutar suara TIDAK melempar error ke pemanggil: dicatat, dilaporkan lewat event, dan
 * antrian/scheduler tetap berjalan.
 *
 * Events: 'start' (info), 'finish' (info + result), 'error' ({message, ...})
 */
class AudioManager extends EventEmitter {
  constructor({ paths, logger }) {
    super();
    this.paths = paths;
    this.logger = logger;
    this.backend = null;
    this.current = null;
    this.queue = [];
    this.lastError = null;
    this.jobSeq = 0;
  }

  setBackend(backend) {
    this.backend = backend;
    this.logger && this.logger.system('info', `Audio backend: ${backend ? backend.name : '-'}`);
  }

  get backendName() {
    return this.backend ? this.backend.name : null;
  }

  state() {
    return {
      ringing: !!this.current,
      current: this.current
        ? { name: this.current.label, source: this.current.source, startedAt: this.current.startedAt, seconds: this.current.seconds }
        : null,
      queued: this.queue.length,
      backend: this.backendName,
      lastError: this.lastError,
    };
  }

  /**
   * job: { label, filepath (relatif, dari DB), volume (0..100), seconds|null, source, scheduleId, interrupt, duration }
   * Mengembalikan Promise<{ ok, error?, stopped?, queued? }> yang selesai saat bel selesai.
   */
  play(job) {
    return new Promise((resolve) => {
      job = { id: ++this.jobSeq, ...job, resolve };
      if (!this.current) return void this._run(job);
      if (job.interrupt) {
        this.queue.unshift(job);
        this.stop({ keepQueue: true });
      } else if (this.queue.length >= MAX_QUEUE) {
        resolve({ ok: false, error: 'Antrian bel penuh' });
      } else {
        this.queue.push(job);
        this.emit('queued', { label: job.label });
      }
    });
  }

  /** Hentikan bel yang sedang berbunyi (dan kosongkan antrian kecuali keepQueue) */
  stop({ keepQueue = false } = {}) {
    if (!keepQueue) {
      const pending = this.queue.splice(0);
      for (const j of pending) j.resolve({ ok: true, stopped: true });
    }
    if (this.current) {
      this.current.stopped = true;
      try {
        this.backend && this.backend.stop();
      } catch (err) {
        this.logger && this.logger.system('warn', `Gagal menghentikan audio: ${err.message}`);
      }
    }
  }

  async _run(job) {
    const startedAt = Date.now();
    const seconds = job.seconds && job.seconds > 0 ? job.seconds : null;
    this.current = { ...job, startedAt, seconds, stopped: false };
    this.emit('start', { label: job.label, source: job.source, scheduleId: job.scheduleId, startedAt });

    let result;
    let timer;
    try {
      if (!this.backend) throw new Error('Tidak ada pemutar audio yang aktif');
      const abs = resolveSoundPath(this.paths, job.filepath);
      if (!abs) throw new Error('Path file sound tidak valid');
      if (!fs.existsSync(abs)) throw new Error(`File sound tidak ditemukan: ${job.filepath}`);

      const volume = Math.min(Math.max((Number(job.volume) || 0) / 100, 0), 1);
      // Pengaman: jika backend macet, paksa berhenti setelah durasi + 15 detik
      const limit = ((seconds || job.duration || DEFAULT_MAX_SECONDS) + 15) * 1000;
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => {
          try {
            this.backend.stop();
          } catch {
            /* abaikan */
          }
          reject(new Error('Pemutaran melebihi batas waktu dan dihentikan paksa'));
        }, limit);
      });
      await Promise.race([this.backend.play({ filepath: abs, volume, seconds }), timeout]);
      result = { ok: true, stopped: this.current.stopped };
      this.lastError = null;
    } catch (err) {
      if (this.current && this.current.stopped) {
        result = { ok: true, stopped: true };
      } else {
        result = { ok: false, error: err.message };
        this.lastError = { message: err.message, sound: job.label, at: Date.now() };
        this.emit('error', { ...this.lastError, source: job.source, scheduleId: job.scheduleId });
      }
    } finally {
      clearTimeout(timer);
    }

    const finished = { label: job.label, source: job.source, scheduleId: job.scheduleId, startedAt, endedAt: Date.now(), ...result };
    this.current = null;
    this.emit('finish', finished);
    job.resolve(result);

    const next = this.queue.shift();
    if (next) setImmediate(() => this._run(next));
  }
}

/** Backend simulasi (tanpa suara) untuk testing / server tanpa speaker */
function createNullBackend() {
  let timer = null;
  let release = null;
  return {
    name: 'null (simulasi, tanpa suara)',
    play({ seconds }) {
      return new Promise((resolve) => {
        release = resolve;
        timer = setTimeout(resolve, Math.min((seconds || 2) * 1000, 2000));
      });
    },
    stop() {
      clearTimeout(timer);
      release && release();
    },
  };
}

module.exports = { AudioManager, createNullBackend };
