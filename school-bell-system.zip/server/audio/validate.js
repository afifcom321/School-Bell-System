'use strict';
const path = require('path');
const crypto = require('crypto');

const MAX_UPLOAD_BYTES = (Number(process.env.MAX_UPLOAD_MB) || 20) * 1024 * 1024;

const ALLOWED = {
  '.mp3': { mimes: ['audio/mpeg', 'audio/mp3', 'audio/x-mpeg', 'audio/mpeg3', 'audio/x-mpeg-3'], label: 'MP3' },
  '.wav': { mimes: ['audio/wav', 'audio/x-wav', 'audio/wave', 'audio/vnd.wave'], label: 'WAV' },
  '.ogg': { mimes: ['audio/ogg', 'application/ogg', 'audio/x-ogg', 'audio/vorbis'], label: 'OGG' },
};
// Sebagian browser/OS mengirim tipe generik; tetap diterima HANYA jika isi file cocok dengan ekstensi.
const GENERIC_MIMES = ['', 'application/octet-stream'];

function hasValidSignature(ext, buf) {
  if (!buf || buf.length < 12) return false;
  if (ext === '.mp3') {
    const id3 = buf.toString('latin1', 0, 3) === 'ID3';
    const frameSync = buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0;
    return id3 || frameSync;
  }
  if (ext === '.wav') return buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WAVE';
  if (ext === '.ogg') return buf.toString('latin1', 0, 4) === 'OggS';
  return false;
}

/**
 * Validasi berkas upload (dari multer memoryStorage). Mengembalikan { ok, error?, ext, mime }.
 */
function validateAudioUpload(file) {
  if (!file) return { ok: false, error: 'Tidak ada berkas yang diunggah' };
  const ext = path.extname(String(file.originalname || '')).toLowerCase();
  const rule = ALLOWED[ext];
  if (!rule) return { ok: false, error: 'Format tidak didukung. Gunakan MP3, WAV, atau OGG.' };
  if (file.size > MAX_UPLOAD_BYTES) {
    return { ok: false, error: `Ukuran berkas melebihi batas ${Math.round(MAX_UPLOAD_BYTES / 1048576)} MB` };
  }
  const mime = String(file.mimetype || '').toLowerCase();
  if (!rule.mimes.includes(mime) && !GENERIC_MIMES.includes(mime)) {
    return { ok: false, error: `Tipe berkas (${mime}) tidak sesuai dengan ekstensi ${ext}` };
  }
  if (!hasValidSignature(ext, file.buffer)) {
    return { ok: false, error: `Isi berkas bukan ${rule.label} yang valid` };
  }
  return { ok: true, ext, mime: rule.mimes[0] };
}

/** Nama tampilan default dari nama berkas asli (tanpa ekstensi, dibersihkan) */
function displayNameFrom(originalName) {
  const base = path.basename(String(originalName || 'sound'), path.extname(String(originalName || '')));
  return base.replace(/[\u0000-\u001f<>]/g, '').replace(/[_]+/g, ' ').trim().slice(0, 60) || 'Sound';
}

/**
 * Nama berkas aman di disk: hanya a-z 0-9 - _ , ditambah suffix acak.
 * Tidak pernah memakai path dari client (mencegah path traversal).
 */
function safeStoredFilename(originalName, ext) {
  const base = path
    .basename(String(originalName || 'sound'), path.extname(String(originalName || '')))
    .normalize('NFKD')
    .replace(/[^a-zA-Z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .toLowerCase()
    .slice(0, 40);
  return `${base || 'sound'}-${crypto.randomBytes(3).toString('hex')}${ext}`;
}

/** Baca durasi audio (detik). Mengembalikan null bila tidak dapat dibaca. */
async function readDuration(buffer, mime) {
  try {
    const mm = require('music-metadata');
    const meta = await mm.parseBuffer(buffer, { mimeType: mime }, { duration: true });
    const d = meta.format && meta.format.duration;
    return Number.isFinite(d) ? Math.round(d * 100) / 100 : null;
  } catch {
    return null;
  }
}

module.exports = { validateAudioUpload, displayNameFrom, safeStoredFilename, readDuration, MAX_UPLOAD_BYTES, ALLOWED };
