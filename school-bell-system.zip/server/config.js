'use strict';
/**
 * Konfigurasi level aplikasi (bukan jadwal) — disimpan di data/config.json.
 * Konfigurasi ini dibaca SEBELUM database dibuka (mis. port server).
 */
const fs = require('fs');

const DEFAULTS = {
  port: 3000,
  host: '0.0.0.0', // 0.0.0.0 = dapat diakses dari perangkat lain di jaringan lokal
  startServerAutomatically: true, // web server otomatis jalan saat aplikasi dibuka
  startSchedulerAutomatically: true, // scheduler otomatis jalan saat aplikasi dibuka
  startWithWindows: false, // aplikasi otomatis jalan saat Windows startup
  launchDashboardAutomatically: false, // buka dashboard di browser saat aplikasi mulai
  minimizeToTray: true, // tombol close hanya menyembunyikan jendela (bel tetap jalan)
  preventSleep: true, // cegah komputer masuk mode sleep agar bel tidak terlewat
};

function loadConfig(paths) {
  let stored = {};
  try {
    stored = JSON.parse(fs.readFileSync(paths.configFile, 'utf8'));
  } catch {
    /* file belum ada / rusak → pakai default */
  }
  const cfg = { ...DEFAULTS, ...pick(stored, Object.keys(DEFAULTS)) };
  if (process.env.PORT) cfg.port = Number(process.env.PORT);
  if (process.env.HOST) cfg.host = process.env.HOST;
  return sanitize(cfg);
}

function saveConfig(paths, cfg) {
  const clean = sanitize({ ...DEFAULTS, ...cfg });
  const tmp = paths.configFile + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(clean, null, 2));
  fs.renameSync(tmp, paths.configFile); // atomic replace
  return clean;
}

function sanitize(cfg) {
  const out = { ...cfg };
  const port = Number(out.port);
  out.port = Number.isInteger(port) && port >= 1 && port <= 65535 ? port : DEFAULTS.port;
  out.host = typeof out.host === 'string' && out.host ? out.host : DEFAULTS.host;
  for (const k of Object.keys(DEFAULTS)) {
    if (typeof DEFAULTS[k] === 'boolean') out[k] = Boolean(out[k]);
  }
  return out;
}

function pick(obj, keys) {
  const out = {};
  for (const k of keys) if (k in obj) out[k] = obj[k];
  return out;
}

module.exports = { loadConfig, saveConfig, DEFAULTS };
