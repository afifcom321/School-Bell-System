#!/usr/bin/env node
'use strict';
/**
 * Menjalankan School Bell System TANPA aplikasi desktop (mis. di server/mini-PC).
 *   npm run server
 *
 * Environment variable (opsional):
 *   PORT        port web (default 3000, atau sesuai data/config.json)
 *   BELL_HOME   folder data (default: folder project)
 *   BELL_AUDIO  "null" untuk simulasi tanpa suara (testing)
 */
const { BellApp } = require('./app');

async function main() {
  const app = await new BellApp().init();

  app.on('problem', (p) => console.error(`[!] ${p.message}`));
  app.on('log', (e) => {
    const t = new Date(e.timestamp).toLocaleTimeString('id-ID', { hour12: false });
    console.log(`[${t}] ${e.event}${e.detail ? ` — ${e.detail}` : ''}`);
  });

  if (app.config.startSchedulerAutomatically) app.startScheduler();
  const info = await app.startServer();

  console.log('\n=== School Bell System ===');
  if (info.running) {
    console.log(`Dashboard (komputer ini) : ${info.localUrl}`);
    for (const u of info.urls) console.log(`Dashboard (jaringan LAN) : ${u.url}   [${u.interface}]`);
  } else {
    console.log(`Web server TIDAK berjalan: ${info.error}`);
  }
  console.log(`Audio backend            : ${app.audio.backendName}`);
  console.log(`Folder data              : ${app.paths.home}`);
  console.log('Login awal               : admin / admin123  (wajib diganti saat login pertama)\n');

  const stop = async () => {
    console.log('\nMenghentikan…');
    await app.shutdown();
    process.exit(0);
  };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);

  // Failsafe: kesalahan tak terduga dicatat, proses tidak mati
  process.on('uncaughtException', (err) => app.logger.system('error', `uncaughtException: ${err.stack || err.message}`));
  process.on('unhandledRejection', (err) => app.logger.system('error', `unhandledRejection: ${err && err.stack ? err.stack : err}`));
}

main().catch((err) => {
  console.error('Gagal memulai School Bell System:', err);
  process.exit(1);
});
