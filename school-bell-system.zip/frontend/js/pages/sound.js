import { $, $$, on, html, setHtml, fmtSize, fmtDur } from '../util.js';
import { isAdmin } from '../state.js';
import { get, post, put, del } from '../api.js';
import { icon, toast, openModal, confirmDialog, withBusy } from '../ui.js';

let sounds = [];
let maxUploadMb = 20;
let audioEl = null;
let playingId = null;

export async function mountSound(root) {
  audioEl = new Audio();
  audioEl.addEventListener('ended', () => setPlaying(root, null));
  audioEl.addEventListener('error', () => {
    if (playingId != null) toast('Gagal memutar preview di browser ini', 'error');
    setPlaying(root, null);
  });

  setHtml(root, template());
  await load(root);
  bindEvents(root);

  return () => {
    audioEl.pause();
    audioEl.src = '';
  };
}

function template() {
  const admin = isAdmin();
  return html`
    ${admin
      ? html`
        <div class="drop" id="drop">
          ${icon('upload')}
          <div><b>Seret berkas MP3/WAV/OGG ke sini</b></div>
          <div class="hint">atau</div>
          <button class="btn primary" id="btn-pick">Pilih Berkas</button>
          <input type="file" id="file-input" accept=".mp3,.wav,.ogg,audio/*" hidden />
          <div class="hint" style="margin-top:8px" id="drop-hint">Maks. ${maxUploadMb} MB per berkas</div>
        </div>
      `
      : ''}
    <div class="sound-list" id="sound-list"></div>
    <div id="sound-empty"></div>
  `;
}

async function load(root) {
  const r = await get('/api/sounds');
  sounds = r.sounds;
  maxUploadMb = r.maxUploadMb;
  const hint = $('#drop-hint', root);
  if (hint) hint.textContent = `Maks. ${maxUploadMb} MB per berkas`;
  paintList(root);
}

function paintList(root) {
  const el = $('#sound-list', root);
  $('#sound-empty', root).innerHTML = sounds.length ? '' : `<div class="empty"><b>Belum ada sound</b><span>Unggah berkas MP3, WAV, atau OGG untuk mulai memakainya di jadwal.</span></div>`;
  setHtml(
    el,
    html`${sounds.map(
      (s) => html`<div class="sound" data-id="${s.id}">
        <button class="pbtn act-play" title="Putar/berhenti" ${s.fileMissing ? 'disabled' : ''}>${icon('play', 'ic-play')}</button>
        <div>
          <h3>${s.name} ${s.isDefault ? html`<span class="pill brass">Default</span>` : ''} ${s.isBuiltin ? html`<span class="pill">Bawaan</span>` : ''} ${s.fileMissing ? html`<span class="pill error">Berkas hilang</span>` : ''}</h3>
          <div class="meta">
            <span>${fmtDur(s.duration)}</span><span>${fmtSize(s.size)}</span><span>Volume ${s.volume}%</span>
            ${s.maxPlaySeconds ? html`<span>Maks ${s.maxPlaySeconds} dtk</span>` : ''}
            ${s.usedBy ? html`<span>Dipakai ${s.usedBy} jadwal</span>` : html`<span class="muted">Belum dipakai jadwal</span>`}
          </div>
        </div>
        ${isAdmin()
          ? html`<div class="acts">
              ${!s.isDefault ? html`<button class="btn sm act-default">Jadikan Default</button>` : ''}
              <button class="btn sm icon quiet act-edit" title="Ubah">${icon('pencil')}</button>
              <button class="btn sm icon quiet act-del" title="Hapus">${icon('trash')}</button>
            </div>`
          : ''}
      </div>`
    )}`
  );
}

function setPlaying(root, id) {
  playingId = id;
  $$('.sound', root).forEach((el) => {
    const on = Number(el.dataset.id) === id;
    el.querySelector('.act-play')?.classList.toggle('playing', on);
    const ic = el.querySelector('.act-play svg');
    if (ic) ic.outerHTML = icon(on ? 'stop' : 'play').s;
  });
}

// ------------------------------------------------------------------ events
function bindEvents(root) {
  on(root, 'click', '.act-play', (e, btn) => {
    const id = Number(btn.closest('.sound').dataset.id);
    if (playingId === id) {
      audioEl.pause();
      setPlaying(root, null);
      return;
    }
    audioEl.src = `/api/sounds/${id}/file`;
    audioEl.currentTime = 0;
    audioEl.play().catch(() => toast('Gagal memutar preview', 'error'));
    setPlaying(root, id);
  });

  on(root, 'click', '.act-default', async (e, btn) => {
    const id = Number(btn.closest('.sound').dataset.id);
    await withBusy(btn, async () => {
      await post(`/api/sounds/${id}/default`, {});
      await load(root);
      toast('Sound default diperbarui', 'ok');
    });
  });

  on(root, 'click', '.act-edit', (e, btn) => openEdit(root, Number(btn.closest('.sound').dataset.id)));

  on(root, 'click', '.act-del', async (e, btn) => {
    const id = Number(btn.closest('.sound').dataset.id);
    const s = sounds.find((x) => x.id === id);
    const msg = s.usedBy
      ? html`Hapus <b>${s.name}</b>? Sound ini dipakai oleh <b>${s.usedBy}</b> jadwal — jadwal tersebut akan otomatis memakai sound default.`
      : html`Hapus <b>${s.name}</b>? Tindakan ini tidak dapat dibatalkan.`;
    const ok = await confirmDialog({ title: 'Hapus Sound', message: msg, danger: true, confirmLabel: 'Hapus' });
    if (!ok) return;
    await withBusy(btn, async () => {
      if (playingId === id) { audioEl.pause(); setPlaying(root, null); }
      await del(`/api/sounds/${id}`);
      sounds = sounds.filter((x) => x.id !== id);
      paintList(root);
      toast('Sound dihapus', 'ok');
    });
  });

  if (!isAdmin()) return;

  const drop = $('#drop', root);
  const fileInput = $('#file-input', root);
  $('#btn-pick', root).addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => {
    if (fileInput.files[0]) uploadFile(root, fileInput.files[0]);
    fileInput.value = '';
  });
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => {
    const f = e.dataTransfer.files[0];
    if (f) uploadFile(root, f);
  });
}

async function uploadFile(root, file) {
  const drop = $('#drop', root);
  const original = drop.innerHTML;
  drop.innerHTML = `<div class="loading" style="min-height:auto;padding:10px">Mengunggah "${file.name}"…</div>`;
  try {
    const fd = new FormData();
    fd.append('file', file);
    const r = await post('/api/sounds/upload', fd);
    sounds.push(r.sound);
    paintList(root);
    toast(`Sound "${r.sound.name}" berhasil diunggah`, 'ok');
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    drop.innerHTML = original;
  }
}

function openEdit(root, id) {
  const s = sounds.find((x) => x.id === id);
  const m = openModal({
    title: 'Ubah Sound',
    body: html`
      <div class="field"><label for="s-name">Nama</label><input id="s-name" type="text" maxlength="60" value="${s.name}" /></div>
      <div class="field"><label for="s-volume">Volume: <span id="s-vol-val">${s.volume}</span>%</label><input id="s-volume" type="range" min="0" max="100" value="${s.volume}" /></div>
      <div class="field"><label for="s-max">Batas durasi (detik, opsional)</label><input id="s-max" type="number" min="1" max="600" placeholder="Putar sampai selesai" value="${s.maxPlaySeconds ?? ''}" />
        <span class="hint">Berguna untuk memotong sound panjang agar tidak mengganggu jam pelajaran.</span></div>
    `,
    buttons: [
      { label: 'Batal' },
      {
        label: 'Simpan',
        kind: 'primary',
        onClick: async (mm) => {
          const r = await put(`/api/sounds/${id}`, {
            name: $('#s-name', mm.el).value.trim(),
            volume: Number($('#s-volume', mm.el).value),
            maxPlaySeconds: $('#s-max', mm.el).value === '' ? null : Number($('#s-max', mm.el).value),
          });
          sounds = sounds.map((x) => (x.id === id ? r.sound : x));
          paintList(root);
          toast('Sound diperbarui', 'ok');
          mm.close();
        },
      },
    ],
  });
  $('#s-volume', m.el).addEventListener('input', (e) => ($('#s-vol-val', m.el).textContent = e.target.value));
}
