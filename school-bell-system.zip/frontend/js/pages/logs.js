import { $, $$, on, html, setHtml, dateTimeShort } from '../util.js';
import * as U from '../util.js';
import { subscribe, tz, timeFmt, isAdmin } from '../state.js';
import { get, del } from '../api.js';
import { icon, toast, confirmDialog, withBusy } from '../ui.js';

const PAGE_SIZE = 40;
const STATUS_LABEL = { ok: 'Berhasil', info: 'Info', warning: 'Peringatan', error: 'Error', skipped: 'Dilewati', missed: 'Terlewat' };
const FILTERS = [
  ['', 'Semua'],
  ['error', 'Error'],
  ['warning', 'Peringatan'],
  ['missed', 'Terlewat'],
  ['skipped', 'Dilewati'],
  ['ok', 'Berhasil'],
];

let rows = [];
let total = 0;
let offset = 0;
let status = '';
let liveTimer = null;

export async function mountLogs(root) {
  setHtml(root, template());
  await loadFirst(root);
  bindEvents(root);
  liveTimer = setInterval(() => refreshTop(root), 8000);
  return () => clearInterval(liveTimer);
}

function template() {
  const admin = isAdmin();
  return html`
    <div class="toolbar">
      <div class="seg" id="log-filter" role="group">
        ${FILTERS.map(([v, l], i) => html`<button type="button" data-v="${v}" aria-pressed="${i === 0}">${l}</button>`)}
      </div>
      <div class="spacer"></div>
      ${admin ? html`<button class="btn sm danger" id="btn-clear">${icon('trash')} Bersihkan Log</button>` : ''}
    </div>
    <div class="card" style="padding:0">
      <div class="tablewrap">
        <table class="tbl stackable">
          <thead><tr><th>Waktu</th><th>Kejadian</th><th>Status</th></tr></thead>
          <tbody id="log-tbody"></tbody>
        </table>
      </div>
      <div id="log-empty"></div>
    </div>
    <div style="text-align:center;margin-top:16px"><button class="btn" id="btn-more" hidden>Muat Lebih Banyak</button></div>
  `;
}

async function loadFirst(root) {
  offset = 0;
  const r = await get(`/api/logs?limit=${PAGE_SIZE}&offset=0${status ? `&status=${status}` : ''}`);
  rows = r.rows;
  total = r.total;
  offset = rows.length;
  paint(root);
}
async function loadMore(root) {
  const r = await get(`/api/logs?limit=${PAGE_SIZE}&offset=${offset}${status ? `&status=${status}` : ''}`);
  rows = rows.concat(r.rows);
  total = r.total;
  offset += r.rows.length;
  paint(root);
}
/** Sisipkan entri baru tanpa mengganggu scroll (dipanggil berkala di halaman ini) */
async function refreshTop(root) {
  if (offset === 0) return; // belum ada data awal
  const r = await get(`/api/logs?limit=${PAGE_SIZE}&offset=0${status ? `&status=${status}` : ''}`);
  const known = new Set(rows.map((x) => x.id));
  const fresh = r.rows.filter((x) => !known.has(x.id));
  if (!fresh.length) return;
  rows = fresh.concat(rows);
  total = r.total;
  offset += fresh.length;
  paint(root);
}

function paint(root) {
  const tbody = $('#log-tbody', root);
  $('#log-empty', root).innerHTML = rows.length ? '' : `<div class="empty"><b>Belum ada catatan</b><span>Aktivitas bel dan sistem akan muncul di sini.</span></div>`;
  tbody.closest('.tablewrap').style.display = rows.length ? '' : 'none';
  setHtml(
    tbody,
    html`${rows.map((l) => {
      const d = new Date(l.timestamp);
      return html`<tr>
        <td class="log-time" data-label="Waktu">${dateTimeShort(l.timestamp, tz(), timeFmt())}</td>
        <td data-label="Kejadian"><div>${l.event}</div>${l.detail ? html`<div class="log-detail">${l.detail}</div>` : ''}</td>
        <td data-label="Status"><span class="pill ${l.status}">${STATUS_LABEL[l.status] || l.status}</span></td>
      </tr>`;
    })}`
  );
  $('#btn-more', root).hidden = offset >= total;
  $('#btn-more', root).textContent = offset >= total ? '' : `Muat Lebih Banyak (${total - offset} lagi)`;
}

function bindEvents(root) {
  on(root, 'click', '#log-filter button', async (e, btn) => {
    $$('#log-filter button', root).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
    status = btn.dataset.v;
    await loadFirst(root);
  });
  on(root, 'click', '#btn-more', (e, btn) => withBusy(btn, () => loadMore(root)));
  on(root, 'click', '#btn-clear', async (e, btn) => {
    const ok = await confirmDialog({ title: 'Bersihkan Log', message: 'Seluruh riwayat log akan dihapus permanen. Lanjutkan?', danger: true, confirmLabel: 'Hapus Semua' });
    if (!ok) return;
    await withBusy(btn, async () => {
      const r = await del('/api/logs');
      toast(`${r.removed} log dihapus`, 'ok');
      await loadFirst(root);
    });
  });
}
