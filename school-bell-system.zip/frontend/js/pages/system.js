import { $, $$, on, html, setHtml, fmtSize, dateTimeShort } from '../util.js';
import { state, tz, timeFmt, isAdmin } from '../state.js';
import { get, post, put, del } from '../api.js';
import { icon, toast, openModal, confirmDialog, withBusy } from '../ui.js';

let sys = null;
let users = [];
let backups = [];

export async function mountSystem(root) {
  const admin = isAdmin();
  setHtml(root, html`<div class="loading">Memuat…</div>`);
  const calls = [get('/api/system')];
  if (admin) calls.push(get('/api/auth/users'), get('/api/system/backups'));
  const results = await Promise.all(calls);
  sys = results[0];
  if (admin) {
    users = results[1].users;
    backups = results[2].backups;
  }
  setHtml(root, template(admin));
  bindEvents(root);
  return () => {};
}

function template(admin) {
  return html`
    <div class="two-col">
      <div class="card">
        <h2>${icon('monitor')} Info Sistem</h2>
        <dl class="kv">
          <dt>Versi Aplikasi</dt><dd>${sys.app.version}</dd>
          <dt>Node.js</dt><dd>${sys.runtime.node}</dd>
          <dt>Electron</dt><dd>${sys.runtime.electron || html`<span class="muted">Mode headless (npm run server)</span>`}</dd>
          <dt>Platform</dt><dd>${sys.runtime.platform}</dd>
          <dt>Nama Komputer</dt><dd>${sys.runtime.hostname}</dd>
          <dt>Zona Waktu Sistem</dt><dd>${sys.runtime.osTimezone}</dd>
          <dt>Waktu Aktif</dt><dd>${formatUptime(sys.runtime.uptimeSec)}</dd>
          <dt>Memori Terpakai</dt><dd>${sys.runtime.memoryMb} MB</dd>
          <dt>Pemutar Audio</dt><dd>${sys.audioBackend || '-'}</dd>
          <dt>Database</dt><dd>${sys.db.ok ? html`<span class="pill ok">${icon('check')} Normal</span>` : html`<span class="pill error">${icon('alert')} ${sys.db.error}</span>`}</dd>
        </dl>
        ${admin
          ? html`<div class="row" style="margin-top:16px">
              <button class="btn sm" id="btn-timesync">${icon('refresh')} Sinkronkan Waktu Sistem</button>
            </div>
            <div id="timesync-result"></div>`
          : ''}
      </div>

      <div class="card">
        <h2>${icon('list')} Alamat Dashboard</h2>
        <p class="sub">Buka salah satu alamat ini dari perangkat lain (laptop guru, HP) yang berada di jaringan Wi-Fi/LAN yang sama.</p>
        <div class="url-row"><span class="grow">Komputer ini</span><a href="${sys.server.localUrl}" target="_blank" rel="noopener">${sys.server.localUrl}</a></div>
        ${sys.server.urls.length
          ? sys.server.urls.map((u) => html`<div class="url-row"><span class="grow">Jaringan (${u.interface})</span><a href="${u.url}" target="_blank" rel="noopener">${u.url}</a></div>`)
          : html`<div class="url-row muted">Tidak ada alamat jaringan terdeteksi — pastikan komputer terhubung Wi-Fi/LAN.</div>`}
      </div>
    </div>

    ${admin
      ? html`
        <div class="card">
          <div class="card-head">
            <div><h2>${icon('copyfile')} Backup &amp; Restore Database</h2><div class="sub">Mencakup jadwal, sound, pengaturan, log, dan akun. Berkas audio (folder <span class="mono">sounds/</span>) tidak termasuk — cadangkan folder itu secara terpisah bila perlu.</div></div>
            <div class="row tight">
              <button class="btn sm" id="btn-backup-now">${icon('copyfile')} Buat Backup</button>
              <button class="btn sm" id="btn-download-backup">${icon('download')} Unduh Backup</button>
              <button class="btn sm" id="btn-restore">${icon('upload')} Restore</button>
              <input type="file" id="restore-file" accept=".db" hidden />
            </div>
          </div>
          <ul class="list-plain" id="backup-list"></ul>
        </div>

        <div class="card">
          <div class="card-head">
            <div><h2>${icon('user')} Manajemen User</h2><div class="sub">Admin dapat mengelola semua fitur; Viewer hanya dapat melihat.</div></div>
            <button class="btn sm" id="btn-add-user">${icon('plus')} Tambah User</button>
          </div>
          <div class="tablewrap">
            <table class="tbl stackable">
              <thead><tr><th>Username</th><th>Role</th><th>Dibuat</th><th></th></tr></thead>
              <tbody id="user-tbody"></tbody>
            </table>
          </div>
        </div>
      `
      : ''}

    <div class="card">
      <h2>${icon('info')} Tentang</h2>
      <p class="sub">School Bell System — aplikasi bel sekolah otomatis yang berjalan sepenuhnya di jaringan lokal, tanpa memerlukan koneksi internet.</p>
    </div>
  `;
}

function formatUptime(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (h > 0) return `${h} jam ${m} menit`;
  return `${m} menit`;
}

function paintBackups(root) {
  const el = $('#backup-list', root);
  if (!el) return;
  if (!backups.length) {
    el.innerHTML = `<li class="muted">Belum ada backup. Klik "Buat Backup" untuk membuat yang pertama.</li>`;
    return;
  }
  setHtml(
    el,
    html`${backups.map(
      (b) => html`<li><span class="grow mono">${b.name}</span><span class="muted">${fmtSize(b.size)}</span><span class="muted">${dateTimeShort(b.modifiedAt, tz(), timeFmt())}</span></li>`
    )}`
  );
}

function paintUsers(root) {
  const tbody = $('#user-tbody', root);
  if (!tbody) return;
  setHtml(
    tbody,
    html`${users.map(
      (u) => html`<tr data-id="${u.id}">
        <td data-label="Username"><b>${u.username}</b>${u.id === state.user.id ? html` <span class="pill">Anda</span>` : ''}</td>
        <td data-label="Role"><span class="pill ${u.role === 'admin' ? 'brass' : ''}">${u.role === 'admin' ? 'Administrator' : 'Viewer'}</span></td>
        <td data-label="Dibuat">${dateTimeShort(u.createdAt, tz(), timeFmt())}</td>
        <td class="actions">
          <button class="btn sm icon quiet act-edit-user" title="Ubah">${icon('pencil')}</button>
          ${u.id !== state.user.id ? html`<button class="btn sm icon quiet act-del-user" title="Hapus">${icon('trash')}</button>` : ''}
        </td>
      </tr>`
    )}`
  );
}

function bindEvents(root) {
  const admin = isAdmin();
  if (!admin) return;
  paintBackups(root);
  paintUsers(root);

  $('#btn-timesync', root).addEventListener('click', async (e) => {
    await withBusy(e.currentTarget, async () => {
      const r = await post('/api/system/time-sync', {});
      setHtml(
        $('#timesync-result', root),
        r.ok
          ? html`<div class="result-box">${icon('check')} Sinkronisasi berhasil.</div>`
          : html`<div class="result-box">${icon('alert')} ${r.error}</div>`
      );
      toast(r.ok ? 'Waktu sistem disinkronkan' : r.error, r.ok ? 'ok' : 'error');
    });
  });

  $('#btn-backup-now', root).addEventListener('click', async (e) => {
    await withBusy(e.currentTarget, async () => {
      const r = await post('/api/system/backups', {});
      backups = r.backups;
      paintBackups(root);
      toast('Backup dibuat', 'ok');
    });
  });

  $('#btn-download-backup', root).addEventListener('click', () => {
    window.location.href = '/api/system/backups/download';
  });

  $('#btn-restore', root).addEventListener('click', () => $('#restore-file', root).click());
  root.addEventListener('change', async (e) => {
    if (e.target.id !== 'restore-file' || !e.target.files[0]) return;
    const file = e.target.files[0];
    e.target.value = '';
    const ok = await confirmDialog({
      title: 'Restore Database?',
      message: 'Data saat ini akan digantikan oleh isi backup ini. Cadangan pengaman otomatis dibuat sebelum restore. Anda perlu login kembali setelahnya. Lanjutkan?',
      danger: true,
      confirmLabel: 'Restore',
    });
    if (!ok) return;
    try {
      const fd = new FormData();
      fd.append('file', file);
      const r = await post('/api/system/restore', fd);
      toast(`Database dipulihkan. ${r.note}`, 'ok', 8000);
      setTimeout(() => window.location.reload(), 1200);
    } catch (err) {
      toast(err.message, 'error');
    }
  });

  $('#btn-add-user', root).addEventListener('click', () => openUserForm(root, null));
  on(root, 'click', '.act-edit-user', (e, btn) => openUserForm(root, Number(btn.closest('tr').dataset.id)));
  on(root, 'click', '.act-del-user', async (e, btn) => {
    const id = Number(btn.closest('tr').dataset.id);
    const u = users.find((x) => x.id === id);
    const ok = await confirmDialog({ title: 'Hapus User', message: html`Hapus akun <b>${u.username}</b>?`, danger: true, confirmLabel: 'Hapus' });
    if (!ok) return;
    await withBusy(btn, async () => {
      await del(`/api/auth/users/${id}`);
      users = users.filter((x) => x.id !== id);
      paintUsers(root);
      toast('User dihapus', 'ok');
    });
  });
}

function openUserForm(root, id) {
  const editing = id ? users.find((u) => u.id === id) : null;
  openModal({
    title: editing ? `Ubah User: ${editing.username}` : 'Tambah User',
    body: html`
      ${editing ? '' : html`<div class="field"><label for="u-username">Username</label><input id="u-username" type="text" autocomplete="off" placeholder="huruf, angka, titik, strip" /></div>`}
      <div class="field"><label for="u-role">Role</label>
        <select id="u-role" ${editing && editing.id === state.user.id ? 'disabled' : ''}>
          <option value="admin" ${!editing || editing.role === 'admin' ? 'selected' : ''}>Administrator (akses penuh)</option>
          <option value="viewer" ${editing && editing.role === 'viewer' ? 'selected' : ''}>Viewer (hanya melihat)</option>
        </select>
      </div>
      <div class="field"><label for="u-password">${editing ? 'Password baru (kosongkan jika tidak diganti)' : 'Password'}</label><input id="u-password" type="password" autocomplete="new-password" minlength="6" /></div>
    `,
    buttons: [
      { label: 'Batal' },
      {
        label: editing ? 'Simpan' : 'Tambah',
        kind: 'primary',
        onClick: async (mm) => {
          if (editing) {
            const body = {};
            if (!$('#u-role', mm.el).disabled) body.role = $('#u-role', mm.el).value;
            if ($('#u-password', mm.el).value) body.password = $('#u-password', mm.el).value;
            const r = await put(`/api/auth/users/${editing.id}`, body);
            users = users.map((u) => (u.id === editing.id ? r.user : u));
            toast('User diperbarui', 'ok');
          } else {
            const username = $('#u-username', mm.el).value.trim();
            const role = $('#u-role', mm.el).value;
            const password = $('#u-password', mm.el).value;
            if (!username) throw new Error('Username wajib diisi');
            if (!password || password.length < 6) throw new Error('Password minimal 6 karakter');
            const r = await post('/api/auth/users', { username, role, password });
            users.push(r.user);
            toast('User ditambahkan', 'ok');
          }
          paintUsers(root);
          mm.close();
        },
      },
    ],
  });
}
