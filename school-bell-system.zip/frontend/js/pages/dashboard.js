import { $, $$, on, html, setHtml, esc } from '../util.js';
import * as U from '../util.js';
import { state, subscribe, serverNow, tz, timeFmt, isAdmin, refreshStatus } from '../state.js';
import { get, post } from '../api.js';
import { icon, toast, openModal, withBusy } from '../ui.js';

export async function mountDashboard(root) {
  setHtml(root, template());
  paint();

  let clockTimer = setInterval(tickClock, 1000);
  const unsub = subscribe(paint);
  bindEvents(root);

  return () => {
    clearInterval(clockTimer);
    unsub();
  };
}

function template() {
  const admin = isAdmin();
  return html`
    <div id="dash-banner"></div>
    <div class="board">
      <div>
        <div class="lbl">Waktu sekarang</div>
        <div class="clock" id="clock">--:--<span class="sec">:--</span></div>
        <div class="dateline" id="dateline">-</div>
        <div class="badges" id="badges"></div>
      </div>
      <div class="next-side" id="next-side"></div>
      <div class="rail-wrap"><div id="rail"></div></div>
    </div>

    <div class="two-col">
      <div class="card">
        <h2>Jadwal Hari Ini</h2>
        <p class="sub">Diurutkan berdasarkan jam, memakai jam &amp; zona waktu server.</p>
        <ul class="today-list" id="today-list"></ul>
      </div>

      <div class="card controls">
        <h2>Kontrol Bel</h2>
        <p class="sub">${admin ? 'Bunyikan bel manual atau uji coba sound.' : 'Anda masuk sebagai Viewer — hanya dapat melihat.'}</p>
        ${admin
          ? html`
            <div class="actions">
              <button class="btn primary big" id="btn-ring">${icon('bell')} Bunyikan Bel Sekarang</button>
              <button class="btn big" id="btn-test">${icon('flask')} Test Sound</button>
            </div>
            <div class="ctl-row">
              <div class="t"><b>Jadwal Otomatis</b><small>Matikan sementara seluruh bel otomatis</small></div>
              <label class="switch"><input type="checkbox" id="sw-sched" /><span></span></label>
            </div>
            <div class="ctl-row">
              <div class="t"><b>Mode Ujian</b><small id="exam-desc">Bel otomatis ditahan selama ujian</small></div>
              <label class="switch"><input type="checkbox" id="sw-exam" /><span></span></label>
            </div>
            <div class="ctl-row">
              <div class="t"><b>Jeda Sementara</b><small id="pause-desc">Hentikan bel otomatis untuk beberapa saat</small></div>
              <div class="menu" id="pause-menu">
                <button type="button" class="btn sm" id="btn-pause">${icon('pause')} Jeda</button>
              </div>
            </div>
          `
          : ''}
      </div>
    </div>
  `;
}

// ------------------------------------------------------------------- jam
function tickClock() {
  if (!state.status) return;
  const now = serverNow();
  const p = U.clockParts(now, tz(), timeFmt());
  const clockEl = $('#clock');
  if (clockEl) clockEl.innerHTML = `${p.hh}:${p.mm}<span class="sec">:${p.ss}</span>${p.period ? `<span class="ampm">${p.period}</span>` : ''}`;
  const dl = $('#dateline');
  if (dl) dl.textContent = U.dateLong(now, tz());
  paintNext(now, false);
}

// ------------------------------------------------------------------- paint
function paint() {
  const s = state.status;
  if (!s) return;
  paintBanner(s);
  paintBadges(s);
  paintNext(serverNow(), true, s);
  paintToday(s);
  paintControls(s);
}

function paintBanner(s) {
  const el = $('#dash-banner');
  if (!el) return;
  if (s.bell.ringing) {
    setHtml(
      el,
      html`<div class="banner ring">${icon('bell', 'ring-icon')}<div class="grow"><b>Bel sedang berbunyi</b> — ${s.bell.current.name}</div>${isAdmin() ? html`<button class="btn sm danger" id="btn-stop-ring">${icon('stop')} Hentikan</button>` : ''}</div>`
    );
    return;
  }
  if (!s.db.ok) {
    setHtml(el, html`<div class="banner bad">${icon('alert')}<div class="grow"><b>Masalah database</b> — ${s.db.error || 'periksa folder data'}. Bel otomatis memakai data terakhir yang tersimpan.</div></div>`);
    return;
  }
  if (!s.scheduler.running) {
    setHtml(el, html`<div class="banner warn">${icon('alert')}<div class="grow">Scheduler tidak berjalan — bel otomatis <b>tidak aktif</b>.</div></div>`);
    return;
  }
  if (s.autoBell.reason) {
    const map = { exam: 'warn', paused: 'warn', holiday: 'info', disabled: 'warn' };
    setHtml(el, html`<div class="banner ${map[s.autoBell.reason] || 'info'}">${icon('info')}<div class="grow">${s.autoBell.label}${s.holidayToday ? ` — ${s.holidayToday}` : ''}. Bel otomatis tidak akan berbunyi.</div></div>`);
    return;
  }
  el.innerHTML = '';
}

function paintBadges(s) {
  const el = $('#badges');
  if (!el) return;
  const items = [];
  items.push({ ok: s.scheduler.running, on: 'Bel Otomatis Aktif', off: 'Bel Otomatis Nonaktif' });
  if (s.exam.active) items.push({ warn: true, label: 'Mode Ujian' });
  if (s.pause.until) items.push({ warn: true, label: 'Dijeda Sementara' });
  if (s.holidayToday) items.push({ info: true, label: `Libur: ${s.holidayToday}` });
  if (!s.db.ok) items.push({ bad: true, label: 'Database Bermasalah' });
  setHtml(
    el,
    html`${items.map((it) =>
      it.label
        ? html`<span class="badge">${icon(it.bad ? 'alert' : 'info')} ${it.label}</span>`
        : html`<span class="badge">${icon(it.ok ? 'check' : 'x')} ${it.ok ? it.on : it.off}</span>`
    )}`
  );
}

function paintNext(now, full, s = state.status) {
  const side = $('#next-side');
  if (!side || !s) return;
  const next = s.next;
  if (!next) {
    setHtml(side, html`<div class="lbl">Bel Berikutnya</div><div class="next-name" style="margin-top:10px;color:var(--hero-dim)">Tidak ada jadwal aktif</div>`);
    paintRail(null, now);
    return;
  }
  const remain = next.at - now;
  setHtml(
    side,
    html`<div class="lbl">Bel Berikutnya</div>
    <div class="next-name">${next.name}</div>
    <div class="next-time">${U.hhmm(next.time, timeFmt())}</div>
    <div class="next-sound">${next.soundName ? `Sound: ${next.soundName}` : 'Belum ada sound'} · ${U.dateShort(next.at, tz())}</div>
    <div class="count ${remain > 3600000 * 6 ? 'none' : ''}">${remain > 0 ? U.countdown(remain) : 'Sebentar lagi…'}</div>`
  );
  if (full) paintRail(next, now, s);
}

function paintRail(next, now, s = state.status) {
  const el = $('#rail');
  if (!el || !s) return;
  const today = s.today || [];
  if (!today.length) {
    el.innerHTML = '<div class="rail-empty">Tidak ada bel terjadwal hari ini.</div>';
    return;
  }
  const dayStart = today[0].at - 30 * 60000;
  const dayEnd = today[today.length - 1].at + 30 * 60000;
  const span = Math.max(dayEnd - dayStart, 1);
  const pct = (t) => Math.min(100, Math.max(0, ((t - dayStart) / span) * 100));
  const nowPct = pct(now);
  const parts = [`<div class="track"></div><div class="fill" style="width:${nowPct}%"></div>`];
  today.forEach((b, i) => {
    const p = pct(b.at);
    const cls = b.state === 'done' ? 'done' : b.state === 'next' ? 'next' : '';
    parts.push(`<div class="tick ${cls}" style="left:${p}%"></div>`);
    parts.push(`<div class="tl ${i % 2 === 0 ? 'up' : 'down'} ${cls}" style="left:${p}%">${esc(U.hhmm(b.time, timeFmt()))}</div>`);
  });
  if (now >= dayStart && now <= dayEnd) parts.push(`<div class="now" style="left:${nowPct}%"></div>`);
  el.innerHTML = parts.join('');
}

function paintToday(s) {
  const el = $('#today-list');
  if (!el) return;
  if (!s.today.length) {
    el.innerHTML = `<div class="empty"><b>Tidak ada bel hari ini</b><span>Tambahkan jadwal di menu Jadwal Bel.</span></div>`;
    return;
  }
  setHtml(
    el,
    html`${s.today.map(
      (b) => html`<li class="${b.state}">
        <div class="t">${U.hhmm(b.time, timeFmt())}</div>
        <div class="n"><b>${b.name}</b>${b.soundName ? html`<small>${b.soundName}</small>` : html`<small>Belum ada sound</small>`}</div>
        <div>${b.state === 'next' ? html`<span class="pill brass">Berikutnya</span>` : b.state === 'done' ? html`<span class="pill">Selesai</span>` : ''}</div>
      </li>`
    )}`
  );
}

function paintControls(s) {
  const sw = $('#sw-sched');
  if (sw) sw.checked = s.scheduler.running;
  const swExam = $('#sw-exam');
  if (swExam) swExam.checked = s.exam.active;
  const examDesc = $('#exam-desc');
  if (examDesc) examDesc.textContent = s.exam.active ? (s.exam.until ? `Aktif sampai ${U.dateTimeShort(s.exam.until, tz(), timeFmt())}` : 'Aktif — matikan manual saat ujian selesai') : 'Bel otomatis ditahan selama ujian';
  const pauseDesc = $('#pause-desc');
  if (pauseDesc) pauseDesc.textContent = s.pause.until ? `Dijeda sampai ${U.dateTimeShort(s.pause.until, tz(), timeFmt())}` : 'Hentikan bel otomatis untuk beberapa saat';
  const btnPause = $('#btn-pause');
  if (btnPause) btnPause.innerHTML = s.pause.until ? icon('x') + ' Batalkan Jeda' : icon('pause') + ' Jeda';
}

// ------------------------------------------------------------------ events
function bindEvents(root) {
  on(root, 'click', '#btn-stop-ring', async (e, btn) => withBusy(btn, () => post('/api/bell/stop', {})));

  on(root, 'click', '#btn-ring', async (e, btn) => {
    await withBusy(btn, async () => {
      await post('/api/bell/trigger', {});
      toast('Bel dibunyikan', 'ok');
    });
  });

  on(root, 'click', '#btn-test', () => openTestModal());

  on(root, 'click', '#sw-sched', async (e, el) => {
    const enabled = el.checked;
    el.disabled = true;
    try {
      await post('/api/scheduler/toggle', { enabled });
      toast(enabled ? 'Jadwal otomatis diaktifkan' : 'Jadwal otomatis dinonaktifkan', 'ok');
    } catch (err) {
      el.checked = !enabled;
      toast(err.message, 'error');
    } finally {
      el.disabled = false;
    }
  });

  on(root, 'click', '#sw-exam', async (e, el) => {
    const enabling = el.checked;
    el.disabled = true;
    try {
      if (!enabling) {
        await post('/api/scheduler/exam', { enabled: false });
        toast('Mode ujian dimatikan', 'ok');
      } else {
        const choice = await openExamModal();
        if (!choice) {
          el.checked = false;
        } else {
          await post('/api/scheduler/exam', { enabled: true, ...choice });
          toast('Mode ujian diaktifkan', 'ok');
        }
      }
    } catch (err) {
      el.checked = !enabling;
      toast(err.message, 'error');
    } finally {
      el.disabled = false;
    }
  });

  on(root, 'click', '#btn-pause', async () => {
    if (state.status.pause.until) {
      await post('/api/scheduler/pause', { clear: true });
      toast('Jeda dibatalkan', 'ok');
      return;
    }
    openPauseModal();
  });
}

function openTestModal() {
  const sounds = (state.soundsCache || []).length ? state.soundsCache : null;
  get('/api/sounds').then((r) => {
    const list = r.sounds;
    const m = openModal({
      title: 'Test Sound',
      body: html`<div class="field"><label>Pilih sound</label>
        <select id="test-sound">${list.map((s) => html`<option value="${s.id}">${s.name}</option>`)}</select>
      </div>
      <div class="field"><label>Volume</label>
        <input type="range" id="test-vol" min="0" max="100" value="${state.status.masterVolume}" />
      </div>`,
      buttons: [
        { label: 'Batal' },
        {
          label: 'Putar',
          kind: 'primary',
          onClick: async (mm) => {
            await post(`/api/sounds/${$('#test-sound', mm.el).value}/test`, { volume: Number($('#test-vol', mm.el).value) });
            toast('Test sound dijalankan', 'ok');
            mm.close();
          },
        },
      ],
    });
  });
}

function openExamModal() {
  return new Promise((resolve) => {
    const m = openModal({
      title: 'Aktifkan Mode Ujian',
      body: html`<p class="hint" style="margin-bottom:14px">Bel otomatis akan ditahan. Bel manual tetap dapat digunakan.</p>
        <div class="field"><label>Sampai kapan?</label>
          <select id="exam-mode-sel">
            <option value="manual">Sampai dimatikan manual</option>
            <option value="minutes">Untuk beberapa jam</option>
            <option value="date">Sampai tanggal tertentu</option>
          </select>
        </div>
        <div class="field" id="exam-hours-field" hidden><label>Berapa jam?</label><input type="number" id="exam-hours" min="1" max="72" value="4" /></div>
        <div class="field" id="exam-date-field" hidden><label>Sampai tanggal</label><input type="date" id="exam-date" /></div>`,
      buttons: [
        { label: 'Batal', onClick: (mm) => { mm.close(); resolve(null); } },
        {
          label: 'Aktifkan',
          kind: 'primary',
          onClick: (mm) => {
            const mode = $('#exam-mode-sel', mm.el).value;
            let payload = {};
            if (mode === 'minutes') payload.untilMinutes = Number($('#exam-hours', mm.el).value) * 60;
            if (mode === 'date') {
              const d = $('#exam-date', mm.el).value;
              if (!d) throw new Error('Pilih tanggal');
              payload.untilDate = d;
            }
            mm.close();
            resolve(payload);
          },
        },
      ],
    });
    $('#exam-mode-sel', m.el).addEventListener('change', (e) => {
      $('#exam-hours-field', m.el).hidden = e.target.value !== 'minutes';
      $('#exam-date-field', m.el).hidden = e.target.value !== 'date';
    });
  });
}

function openPauseModal() {
  const m = openModal({
    title: 'Jeda Bel Sementara',
    body: html`<div class="field"><label>Durasi</label>
      <div class="seg" id="pause-seg" role="group">
        <button type="button" data-v="15" aria-pressed="true">15 mnt</button>
        <button type="button" data-v="30">30 mnt</button>
        <button type="button" data-v="60">1 jam</button>
        <button type="button" data-v="tomorrow">Sampai besok</button>
      </div>
    </div>`,
    buttons: [
      { label: 'Batal' },
      {
        label: 'Jeda',
        kind: 'primary',
        onClick: async (mm) => {
          const v = $('#pause-seg [aria-pressed="true"]', mm.el).dataset.v;
          if (v === 'tomorrow') await post('/api/scheduler/pause', { untilTomorrow: true });
          else await post('/api/scheduler/pause', { minutes: Number(v) });
          toast('Bel dijeda sementara', 'ok');
          mm.close();
        },
      },
    ],
  });
  on(m.el, 'click', '#pause-seg button', (e, btn) => {
    $$('#pause-seg button', m.el).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
  });
}
