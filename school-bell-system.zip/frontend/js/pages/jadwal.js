import { $, $$, on, html, setHtml, esc, daysHtml, DAY_LONG, DAY_ORDER } from '../util.js';
import * as U from '../util.js';
import { state, subscribe, tz, timeFmt, isAdmin } from '../state.js';
import { get, post, put, patch, del } from '../api.js';
import { icon, toast, openModal, confirmDialog, withBusy } from '../ui.js';

let schedules = [];
let sounds = [];

export async function mountJadwal(root) {
  setHtml(root, template());
  await loadAll(root);
  bindEvents(root);
  const unsub = subscribe(() => paintEmptyBanner(root));
  return () => unsub();
}

function template() {
  const admin = isAdmin();
  return html`
    <div class="toolbar">
      <div class="seg" id="day-filter" role="group">
        <button type="button" data-d="all" aria-pressed="true">Semua</button>
        ${DAY_ORDER.map((d) => html`<button type="button" data-d="${d}">${DAY_LONG[d].slice(0, 3)}</button>`)}
      </div>
      <div class="spacer"></div>
      ${admin
        ? html`
          <button class="btn sm" id="btn-preview">${icon('calendar')} Pratinjau Tanggal</button>
          <button class="btn sm" id="btn-export">${icon('download')} Ekspor</button>
          <button class="btn sm" id="btn-import">${icon('upload')} Impor</button>
          <button class="btn primary" id="btn-add">${icon('plus')} Tambah Jadwal</button>
          <input type="file" id="import-file" accept="application/json" hidden />
        `
        : ''}
    </div>
    <div class="card" style="padding:0" id="jadwal-card">
      <div class="tablewrap">
        <table class="tbl stackable">
          <thead><tr><th>Jam</th><th>Nama Bel</th><th>Hari / Tanggal</th><th>Sound</th>${admin ? '<th>Aktif</th><th></th>' : ''}</tr></thead>
          <tbody id="jadwal-tbody"></tbody>
        </table>
      </div>
      <div id="jadwal-empty"></div>
    </div>
  `;
}

async function loadAll(root) {
  const [sc, sd] = await Promise.all([get('/api/schedules'), get('/api/sounds')]);
  schedules = sc.schedules;
  sounds = sd.sounds;
  paintTable(root, currentFilter(root));
}

function currentFilter(root) {
  const btn = $('#day-filter [aria-pressed="true"]', root);
  return btn ? btn.dataset.d : 'all';
}

function paintTable(root, filter) {
  const admin = isAdmin();
  const tbody = $('#jadwal-tbody', root);
  const rows = schedules
    .filter((s) => filter === 'all' || (s.mode === 'weekly' ? s.days.includes(Number(filter)) : false))
    .sort((a, b) => a.time.localeCompare(b.time) || a.name.localeCompare(b.name));

  $('#jadwal-empty', root).innerHTML = rows.length
    ? ''
    : `<div class="empty"><b>Belum ada jadwal</b><span>${admin ? 'Klik "Tambah Jadwal" untuk membuat yang pertama.' : 'Hubungi administrator untuk menambahkan jadwal.'}</span></div>`;
  tbody.parentElement.parentElement.style.display = rows.length ? '' : 'none';

  setHtml(
    tbody,
    html`${rows.map((s) => {
      const sound = sounds.find((x) => x.id === s.soundId);
      return html`<tr class="${s.enabled ? '' : 'off'}" data-id="${s.id}">
        <td class="time" data-label="Jam">${U.hhmm(s.time, timeFmt())}</td>
        <td data-label="Nama">${s.name}</td>
        <td data-label="Hari">${s.mode === 'date' ? html`<span class="pill info">${U.dateShort(new Date(s.date + 'T00:00:00Z').getTime(), 'UTC')}</span>` : daysHtml(s.days)}</td>
        <td data-label="Sound">${sound ? sound.name : html`<span class="muted">Default</span>`}</td>
        ${admin
          ? html`<td class="sw" data-label="Aktif"><label class="switch"><input type="checkbox" class="sw-enabled" ${s.enabled ? 'checked' : ''} /><span></span></label></td>
            <td class="actions">
              <button class="btn sm icon quiet act-edit" title="Ubah">${icon('pencil')}</button>
              <button class="btn sm icon quiet act-del" title="Hapus">${icon('trash')}</button>
            </td>`
          : ''}
      </tr>`;
    })}`
  );
}

function paintEmptyBanner() {} // reserved (status realtime tidak mengubah tabel jadwal)

// ------------------------------------------------------------------ events
function bindEvents(root) {
  on(root, 'click', '#day-filter button', (e, btn) => {
    $$('#day-filter button', root).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
    paintTable(root, currentFilter(root));
  });

  on(root, 'click', '.sw-enabled', async (e, el) => {
    const tr = el.closest('tr');
    const id = Number(tr.dataset.id);
    const enabled = el.checked;
    el.disabled = true;
    try {
      const r = await patch(`/api/schedules/${id}/enabled`, { enabled });
      schedules = schedules.map((s) => (s.id === id ? r.schedule : s));
      tr.classList.toggle('off', !enabled);
      toast(enabled ? 'Jadwal diaktifkan' : 'Jadwal dinonaktifkan', 'ok');
    } catch (err) {
      el.checked = !enabled;
      toast(err.message, 'error');
    } finally {
      el.disabled = false;
    }
  });

  on(root, 'click', '.act-edit', (e, btn) => openForm(root, Number(btn.closest('tr').dataset.id)));
  on(root, 'click', '.act-del', async (e, btn) => {
    const tr = btn.closest('tr');
    const id = Number(tr.dataset.id);
    const s = schedules.find((x) => x.id === id);
    const ok = await confirmDialog({ title: 'Hapus Jadwal', message: html`Hapus jadwal <b>${s.name}</b> pukul <b>${s.time}</b>? Tindakan ini tidak dapat dibatalkan.`, danger: true, confirmLabel: 'Hapus' });
    if (!ok) return;
    await withBusy(btn, async () => {
      await del(`/api/schedules/${id}`);
      schedules = schedules.filter((x) => x.id !== id);
      paintTable(root, currentFilter(root));
      toast('Jadwal dihapus', 'ok');
    });
  });

  on(root, 'click', '#btn-add', () => openForm(root, null));
  on(root, 'click', '#btn-preview', () => openPreview());
  on(root, 'click', '#btn-export', () => downloadExport());
  on(root, 'click', '#btn-import', () => $('#import-file', root).click());
  root.addEventListener('change', async (e) => {
    if (e.target.id !== 'import-file' || !e.target.files[0]) return;
    const file = e.target.files[0];
    e.target.value = '';
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      openImportConfirm(root, data);
    } catch {
      toast('Berkas tidak dapat dibaca. Pastikan berkas JSON hasil ekspor dari halaman ini.', 'error');
    }
  });
}

// -------------------------------------------------------------- form modal
function openForm(root, id) {
  const editing = id ? schedules.find((s) => s.id === id) : null;
  const mode0 = editing ? editing.mode : 'weekly';
  const days0 = new Set(editing ? editing.days : [1, 2, 3, 4, 5]);

  const m = openModal({
    title: editing ? 'Ubah Jadwal' : 'Tambah Jadwal',
    body: html`
      <div class="field"><label for="f-name">Nama Bel</label><input id="f-name" type="text" maxlength="60" value="${editing ? editing.name : ''}" placeholder="Misal: Masuk Kelas" /></div>
      <div class="grid2">
        <div class="field"><label for="f-time">Jam</label><input id="f-time" type="time" value="${editing ? editing.time : '07:00'}" /></div>
        <div class="field"><label for="f-sound">Sound</label>
          <select id="f-sound"><option value="">Gunakan sound default</option>${sounds.map((s) => html`<option value="${s.id}" ${editing && editing.soundId === s.id ? 'selected' : ''}>${s.name}</option>`)}</select>
        </div>
      </div>
      <div class="field"><label>Berulang</label>
        <div class="seg" id="f-mode" role="group">
          <button type="button" data-v="weekly" aria-pressed="${mode0 === 'weekly'}">Hari dalam seminggu</button>
          <button type="button" data-v="date" aria-pressed="${mode0 === 'date'}">Tanggal tertentu</button>
        </div>
      </div>
      <div class="field" id="f-days-field" ${mode0 !== 'weekly' ? 'hidden' : ''}>
        <label>Hari</label>
        <div class="daysel">${DAY_ORDER.map((d) => html`<label><input type="checkbox" value="${d}" ${days0.has(d) ? 'checked' : ''} /><span>${DAY_LONG[d].slice(0, 3)}</span></label>`)}</div>
      </div>
      <div class="field" id="f-date-field" ${mode0 !== 'date' ? 'hidden' : ''}>
        <label for="f-date">Tanggal</label><input id="f-date" type="date" value="${editing && editing.date ? editing.date : ''}" />
      </div>
      <div class="grid2">
        <div class="field"><label for="f-volume">Volume (opsional)</label><input id="f-volume" type="number" min="0" max="100" placeholder="Ikuti volume sound" value="${editing && editing.volume != null ? editing.volume : ''}" /></div>
        <div class="field"><label for="f-seconds">Durasi maks. detik (opsional)</label><input id="f-seconds" type="number" min="1" max="600" placeholder="Sampai selesai" value="${editing && editing.playSeconds != null ? editing.playSeconds : ''}" /></div>
      </div>
      <label class="check"><input type="checkbox" id="f-enabled" ${!editing || editing.enabled ? 'checked' : ''} /> Jadwal aktif</label>
    `,
    buttons: [
      { label: 'Batal' },
      {
        label: editing ? 'Simpan' : 'Tambah',
        kind: 'primary',
        onClick: async (mm) => {
          const mode = $('#f-mode [aria-pressed="true"]', mm.el).dataset.v;
          const payload = {
            name: $('#f-name', mm.el).value.trim(),
            time: $('#f-time', mm.el).value,
            mode,
            days: $$('.daysel input:checked', mm.el).map((c) => Number(c.value)),
            date: $('#f-date', mm.el).value || null,
            soundId: $('#f-sound', mm.el).value || null,
            volume: $('#f-volume', mm.el).value === '' ? null : Number($('#f-volume', mm.el).value),
            playSeconds: $('#f-seconds', mm.el).value === '' ? null : Number($('#f-seconds', mm.el).value),
            enabled: $('#f-enabled', mm.el).checked,
          };
          const r = editing ? await put(`/api/schedules/${editing.id}`, payload) : await post('/api/schedules', payload);
          if (editing) schedules = schedules.map((s) => (s.id === editing.id ? r.schedule : s));
          else schedules.push(r.schedule);
          paintTable(root, currentFilter(root));
          toast(editing ? 'Jadwal diperbarui' : 'Jadwal ditambahkan', 'ok');
          mm.close();
        },
      },
    ],
  });

  on(m.el, 'click', '#f-mode button', (e, btn) => {
    $$('#f-mode button', m.el).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
    $('#f-days-field', m.el).hidden = btn.dataset.v !== 'weekly';
    $('#f-date-field', m.el).hidden = btn.dataset.v !== 'date';
  });
}

// ---------------------------------------------------------------- preview
function openPreview() {
  const today = U.todayIso(state.status ? state.status.server.now : Date.now(), tz());
  const m = openModal({
    title: 'Pratinjau Jadwal',
    body: html`<div class="field"><label for="pv-date">Tanggal</label><input id="pv-date" type="date" value="${today}" /></div><div id="pv-result"></div>`,
    buttons: [{ label: 'Tutup' }],
  });
  const run = async () => {
    const date = $('#pv-date', m.el).value;
    if (!date) return;
    const r = await get(`/api/schedules/preview?date=${date}`);
    setHtml(
      $('#pv-result', m.el),
      html`${r.holiday ? html`<div class="banner info" style="margin-top:4px">${icon('info')} Hari libur: ${r.holiday} — bel otomatis tidak berbunyi.</div>` : ''}
      <ul class="list-plain">${
        r.items.length
          ? r.items.map((it) => html`<li><span class="time nowrap" style="min-width:60px;display:inline-block">${U.hhmm(it.time, timeFmt())}</span> <span class="grow">${it.name}</span> ${it.willRing ? html`<span class="pill ok">Akan berbunyi</span>` : html`<span class="pill skipped">Tidak berbunyi</span>`}</li>`)
          : html`<li class="muted">Tidak ada jadwal pada tanggal ini.</li>`
      }</ul>`
    );
  };
  $('#pv-date', m.el).addEventListener('change', run);
  run();
}

// -------------------------------------------------------------- export/import
async function downloadExport() {
  const data = await get('/api/schedules/export');
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'jadwal-bel.json';
  a.click();
  URL.revokeObjectURL(a.href);
}

function openImportConfirm(root, data) {
  const count = Array.isArray(data.schedules) ? data.schedules.length : 0;
  if (!count) return toast('Berkas tidak berisi jadwal yang valid', 'error');
  const m = openModal({
    title: 'Impor Jadwal',
    body: html`<p>Berkas berisi <b>${count}</b> jadwal.</p>
      <div class="field"><label>Mode impor</label>
        <div class="seg" id="im-mode" role="group">
          <button type="button" data-v="append" aria-pressed="true">Tambahkan ke jadwal yang ada</button>
          <button type="button" data-v="replace">Ganti seluruh jadwal</button>
        </div>
      </div>`,
    buttons: [
      { label: 'Batal' },
      {
        label: 'Impor',
        kind: 'primary',
        onClick: async (mm) => {
          const mode = $('#im-mode [aria-pressed="true"]', mm.el).dataset.v;
          if (mode === 'replace') {
            const ok = await confirmDialog({ title: 'Ganti Semua Jadwal?', message: 'Seluruh jadwal yang ada saat ini akan dihapus dan digantikan oleh isi berkas. Lanjutkan?', danger: true, confirmLabel: 'Ganti Semua' });
            if (!ok) return;
          }
          const r = await post('/api/schedules/import', { mode, schedules: data.schedules });
          mm.close();
          toast(`${r.imported} jadwal diimpor`, 'ok');
          await loadAll(root);
        },
      },
    ],
  });
  on(m.el, 'click', '#im-mode button', (e, btn) => $$('#im-mode button', m.el).forEach((b) => b.setAttribute('aria-pressed', String(b === btn))));
}
