import { $, $$, on, html, setHtml } from '../util.js';
import { state, refreshStatus, isAdmin } from '../state.js';
import { get, put, post } from '../api.js';
import { icon, toast, openModal, confirmDialog, withBusy } from '../ui.js';

const TIMEZONES = [
  'Asia/Jakarta', 'Asia/Pontianak', 'Asia/Makassar', 'Asia/Jayapura',
  'Asia/Singapore', 'Asia/Kuala_Lumpur', 'Asia/Bangkok', 'Asia/Manila',
  'Asia/Tokyo', 'Asia/Seoul', 'Asia/Kolkata', 'Asia/Dubai',
  'Europe/London', 'Europe/Berlin', 'America/New_York', 'America/Los_Angeles',
  'Australia/Sydney', 'UTC',
];

let settings = null;
let sounds = [];

export async function mountPengaturan(root) {
  const admin = isAdmin();
  setHtml(root, html`<div class="loading">Memuat…</div>`);
  const [s, sd] = await Promise.all([get('/api/settings'), get('/api/sounds')]);
  settings = s.settings;
  sounds = sd.sounds;
  setHtml(root, template(admin));
  bindEvents(root);
  return () => {};
}

function template(admin) {
  return html`
    <div class="two-col">
      <div class="card">
        <h2>${icon('bell')} Identitas &amp; Waktu</h2>
        <p class="sub">Nama sekolah, zona waktu, dan format jam yang tampil di dashboard.</p>
        <form id="form-general">
          <div class="field"><label for="p-school">Nama Sekolah</label><input id="p-school" type="text" maxlength="80" value="${settings.schoolName}" ${admin ? '' : 'disabled'} /></div>
          <div class="grid2">
            <div class="field"><label for="p-tz">Zona Waktu</label>
              <select id="p-tz" ${admin ? '' : 'disabled'}>${TIMEZONES.map((t) => html`<option value="${t}" ${t === settings.timezone ? 'selected' : ''}>${t}</option>`)}</select>
            </div>
            <div class="field"><label for="p-fmt">Format Jam</label>
              <select id="p-fmt" ${admin ? '' : 'disabled'}>
                <option value="24" ${settings.timeFormat === '24' ? 'selected' : ''}>24 jam (14:30)</option>
                <option value="12" ${settings.timeFormat === '12' ? 'selected' : ''}>12 jam (2:30 PM)</option>
              </select>
            </div>
          </div>
          ${admin ? html`<button class="btn primary" type="submit">Simpan</button>` : ''}
        </form>
      </div>

      <div class="card">
        <h2>${icon('volume')} Volume &amp; Sound Default</h2>
        <p class="sub">Berlaku untuk semua bel kecuali diatur berbeda pada jadwal tertentu.</p>
        <form id="form-audio">
          <div class="field"><label for="p-vol">Volume Master: <span id="p-vol-val">${settings.masterVolume}</span>%</label>
            <input id="p-vol" type="range" min="0" max="100" value="${settings.masterVolume}" ${admin ? '' : 'disabled'} /></div>
          <div class="field"><label for="p-sound">Sound Default</label>
            <select id="p-sound" ${admin ? '' : 'disabled'}>
              <option value="">- Pilih -</option>
              ${sounds.map((s) => html`<option value="${s.id}" ${settings.defaultSoundId === s.id ? 'selected' : ''}>${s.name}</option>`)}
            </select>
          </div>
          <div class="field"><label for="p-testsec">Durasi Test Sound (detik)</label><input id="p-testsec" type="number" min="1" max="30" value="${settings.testSoundSeconds}" ${admin ? '' : 'disabled'} /></div>
          ${admin ? html`<button class="btn primary" type="submit">Simpan</button>` : ''}
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div><h2>${icon('calendar')} Hari Libur</h2><div class="sub">Bel otomatis tidak berbunyi pada rentang tanggal ini.</div></div>
        ${admin ? html`<button class="btn sm" id="btn-add-holiday">${icon('plus')} Tambah</button>` : ''}
      </div>
      <ul class="list-plain" id="holiday-list"></ul>
    </div>

    <div class="two-col">
      <div class="card">
        <h2>${icon('sliders')} Lanjutan</h2>
        <p class="sub">Pengaturan teknis penjadwalan.</p>
        <form id="form-advanced">
          <div class="field"><label for="p-catchup">Toleransi Keterlambatan (detik)</label><input id="p-catchup" type="number" min="0" max="3600" value="${settings.catchupSeconds}" ${admin ? '' : 'disabled'} />
            <span class="hint">Bel yang terlambat lebih dari ini (mis. komputer baru menyala) dicatat "terlewat", bukan dibunyikan.</span></div>
          <div class="field"><label for="p-retain">Retensi Log (hari)</label><input id="p-retain" type="number" min="1" max="3650" value="${settings.logRetentionDays}" ${admin ? '' : 'disabled'} /></div>
          <label class="check" style="margin-bottom:16px"><input type="checkbox" id="p-autobackup" ${settings.autoBackup ? 'checked' : ''} ${admin ? '' : 'disabled'} /> Backup database otomatis setiap hari</label>
          ${admin ? html`<button class="btn primary" type="submit">Simpan</button>` : ''}
        </form>
      </div>

      <div class="card">
        <h2>${icon('user')} Akun Saya</h2>
        <p class="sub">Ganti password akun <b>${state.user.username}</b> yang sedang digunakan.</p>
        <button class="btn" id="btn-change-pw">${icon('pencil')} Ganti Password</button>
      </div>
    </div>
  `;
}

function paintHolidays(root) {
  const el = $('#holiday-list', root);
  const admin = isAdmin();
  if (!settings.holidays.length) {
    el.innerHTML = `<li class="muted">Belum ada hari libur yang diatur.</li>`;
    return;
  }
  setHtml(
    el,
    html`${settings.holidays.map(
      (h, i) => html`<li>
        <span class="grow"><b>${h.name}</b> — ${h.start}${h.end !== h.start ? ` s/d ${h.end}` : ''}</span>
        ${admin ? html`<button class="btn sm icon quiet act-del-holiday" data-i="${i}" title="Hapus">${icon('trash')}</button>` : ''}
      </li>`
    )}`
  );
}

function bindEvents(root) {
  paintHolidays(root);
  const admin = isAdmin();

  $('#p-vol', root)?.addEventListener('input', (e) => ($('#p-vol-val', root).textContent = e.target.value));

  if (admin) {
    $('#form-general', root).addEventListener('submit', (e) => save(e, root, { schoolName: $('#p-school', root).value.trim(), timezone: $('#p-tz', root).value, timeFormat: $('#p-fmt', root).value }));
    $('#form-audio', root).addEventListener('submit', (e) =>
      save(e, root, { masterVolume: Number($('#p-vol', root).value), defaultSoundId: $('#p-sound', root).value || null, testSoundSeconds: Number($('#p-testsec', root).value) })
    );
    $('#form-advanced', root).addEventListener('submit', (e) =>
      save(e, root, { catchupSeconds: Number($('#p-catchup', root).value), logRetentionDays: Number($('#p-retain', root).value), autoBackup: $('#p-autobackup', root).checked })
    );
    $('#btn-add-holiday', root).addEventListener('click', () => openHolidayForm(root));
    on(root, 'click', '.act-del-holiday', async (e, btn) => {
      const i = Number(btn.dataset.i);
      const h = settings.holidays[i];
      const ok = await confirmDialog({ title: 'Hapus Hari Libur', message: html`Hapus <b>${h.name}</b>?`, danger: true, confirmLabel: 'Hapus' });
      if (!ok) return;
      const next = settings.holidays.filter((_, idx) => idx !== i);
      await put('/api/settings', { holidays: next });
      settings.holidays = next;
      paintHolidays(root);
      toast('Hari libur dihapus', 'ok');
    });
  }

  $('#btn-change-pw', root).addEventListener('click', () => openChangePassword());
}

async function save(e, root, patchObj) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type=submit]');
  await withBusy(btn, async () => {
    await put('/api/settings', patchObj);
    Object.assign(settings, patchObj);
    await refreshStatus();
    toast('Pengaturan disimpan', 'ok');
  });
}

function openHolidayForm(root) {
  const m = openModal({
    title: 'Tambah Hari Libur',
    body: html`
      <div class="field"><label for="h-name">Nama</label><input id="h-name" type="text" maxlength="80" placeholder="Misal: Libur Semester" /></div>
      <div class="grid2">
        <div class="field"><label for="h-start">Mulai</label><input id="h-start" type="date" /></div>
        <div class="field"><label for="h-end">Sampai</label><input id="h-end" type="date" /></div>
      </div>
    `,
    buttons: [
      { label: 'Batal' },
      {
        label: 'Tambah',
        kind: 'primary',
        onClick: async (mm) => {
          const name = $('#h-name', mm.el).value.trim() || 'Libur';
          const start = $('#h-start', mm.el).value;
          const end = $('#h-end', mm.el).value || start;
          if (!start) throw new Error('Tanggal mulai wajib diisi');
          if (end < start) throw new Error('Tanggal akhir tidak boleh sebelum tanggal mulai');
          const next = [...settings.holidays, { name, start, end }];
          await put('/api/settings', { holidays: next });
          settings.holidays = next;
          paintHolidays(root);
          toast('Hari libur ditambahkan', 'ok');
          mm.close();
        },
      },
    ],
  });
}

function openChangePassword() {
  const m = openModal({
    title: 'Ganti Password',
    body: html`
      <div class="field"><label for="cp-current">Password saat ini</label><input id="cp-current" type="password" autocomplete="current-password" /></div>
      <div class="field"><label for="cp-new">Password baru</label><input id="cp-new" type="password" autocomplete="new-password" minlength="6" /></div>
      <div class="field"><label for="cp-confirm">Ulangi password baru</label><input id="cp-confirm" type="password" autocomplete="new-password" minlength="6" /></div>
    `,
    buttons: [
      { label: 'Batal' },
      {
        label: 'Simpan',
        kind: 'primary',
        onClick: async (mm) => {
          const nw = $('#cp-new', mm.el).value;
          if (nw !== $('#cp-confirm', mm.el).value) throw new Error('Konfirmasi password baru tidak sama');
          await post('/api/auth/change-password', { currentPassword: $('#cp-current', mm.el).value, newPassword: nw });
          toast('Password berhasil diganti', 'ok');
          mm.close();
        },
      },
    ],
  });
}
