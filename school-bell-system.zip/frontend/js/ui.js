/* Komponen UI: ikon inline (tanpa CDN), toast, modal, konfirmasi */
import { html, raw, setHtml, esc, $, $$ } from './util.js';

const ICONS = {
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
  play: '<path d="M6 3l14 9-14 9V3z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  pencil: '<path d="M17 3a2.85 2.85 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>',
  trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  volume: '<path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',
  alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z"/><path d="M12 9v4M12 17h.01"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  pause: '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8M21 3v5h-5M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16M8 16H3v5"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  flask: '<path d="M9 3h6M10 3v6L4.5 19A2 2 0 0 0 6.3 22h11.4a2 2 0 0 0 1.8-3L14 9V3"/>',
  copyfile: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
  chevron: '<path d="m6 9 6 6 6-6"/>',
};

export function icon(name, extra = '') {
  return raw(`<svg class="i ${extra}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ''}</svg>`);
}

// ----------------------------------------------------------------------- toast
let toastBox;
export function toast(message, kind = 'ok', ms = 4200) {
  if (!toastBox) {
    toastBox = document.createElement('div');
    toastBox.className = 'toasts';
    toastBox.setAttribute('role', 'status');
    toastBox.setAttribute('aria-live', 'polite');
    document.body.appendChild(toastBox);
  }
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  setHtml(el, html`${icon(kind === 'error' ? 'alert' : kind === 'info' ? 'info' : 'check')}<div class="msg">${message}</div><button aria-label="Tutup">${icon('x')}</button>`);
  const close = () => el.remove();
  $('button', el).addEventListener('click', close);
  toastBox.appendChild(el);
  while (toastBox.children.length > 4) toastBox.firstChild.remove();
  if (ms > 0) setTimeout(close, kind === 'error' ? Math.max(ms, 7000) : ms);
}

// ----------------------------------------------------------------------- modal
/**
 * openModal({ title, body: Raw, buttons: [{ label, kind, onClick(m) }], dismissable })
 * → { el, close(), setError(msg), setBusy(bool), $(sel) }
 */
export function openModal({ title, body, buttons = [], dismissable = true }) {
  const prevFocus = document.activeElement;
  const overlay = document.createElement('div');
  overlay.className = 'overlay';
  setHtml(
    overlay,
    html`<div class="modal" role="dialog" aria-modal="true" aria-label="${title}">
      <header><h2>${title}</h2>${dismissable ? html`<button class="btn quiet icon" data-close aria-label="Tutup">${icon('x')}</button>` : ''}</header>
      <div class="body"><div class="form-error" hidden data-error></div>${body}</div>
      ${buttons.length ? html`<footer>${buttons.map((b, i) => html`<button type="button" class="btn ${b.kind || ''}" data-btn="${i}">${b.label}</button>`)}</footer>` : ''}
    </div>`
  );
  document.body.appendChild(overlay);

  const m = {
    el: overlay,
    $: (sel) => $(sel, overlay),
    close() {
      document.removeEventListener('keydown', onKey);
      overlay.remove();
      if (prevFocus && prevFocus.focus) prevFocus.focus();
    },
    setError(msg) {
      const e = $('[data-error]', overlay);
      e.hidden = !msg;
      e.textContent = msg || '';
      if (msg) e.scrollIntoView({ block: 'nearest' });
    },
    setBusy(busy) {
      $$('footer .btn', overlay).forEach((b) => (b.disabled = busy));
    },
  };
  const onKey = (e) => {
    if (e.key === 'Escape' && dismissable) m.close();
  };
  document.addEventListener('keydown', onKey);
  overlay.addEventListener('mousedown', (e) => {
    if (e.target === overlay && dismissable) m.close();
  });
  overlay.addEventListener('click', async (e) => {
    if (e.target.closest('[data-close]')) return m.close();
    const btn = e.target.closest('[data-btn]');
    if (!btn) return;
    const def = buttons[Number(btn.dataset.btn)];
    if (def && def.onClick) {
      m.setError('');
      m.setBusy(true);
      try {
        await def.onClick(m);
      } catch (err) {
        m.setError(err.message || String(err));
      } finally {
        if (overlay.isConnected) m.setBusy(false);
      }
    } else m.close();
  });
  overlay.addEventListener('keydown', (e) => {
    // Enter di dalam input = tombol utama
    if (e.key === 'Enter' && e.target.matches('input:not([type=checkbox]):not([type=radio])')) {
      const primary = $('footer .btn.primary, footer .btn.danger', overlay);
      if (primary) {
        e.preventDefault();
        primary.click();
      }
    }
  });
  const first = $('input:not([type=hidden]):not(:disabled), select:not(:disabled)', overlay);
  setTimeout(() => (first || $('.btn', overlay))?.focus(), 30);
  return m;
}

/** Dialog konfirmasi → Promise<boolean> */
export function confirmDialog({ title, message, confirmLabel = 'Ya, lanjutkan', danger = false }) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v, m) => {
      if (done) return;
      done = true;
      m && m.close();
      resolve(v);
    };
    const m = openModal({
      title,
      body: html`<p>${message}</p>`,
      buttons: [
        { label: 'Batal', onClick: (mm) => finish(false, mm) },
        { label: confirmLabel, kind: danger ? 'danger' : 'primary', onClick: (mm) => finish(true, mm) },
      ],
    });
    // menutup lewat Esc / klik latar = batal
    const obs = new MutationObserver(() => {
      if (!m.el.isConnected) {
        obs.disconnect();
        finish(false);
      }
    });
    obs.observe(document.body, { childList: true });
  });
}

/** Jalankan aksi async pada tombol: tampilkan status sibuk, tangkap error → toast */
export async function withBusy(btn, fn) {
  if (btn) btn.classList.add('busy');
  try {
    return await fn();
  } catch (err) {
    toast(err.message || String(err), 'error');
    return undefined;
  } finally {
    if (btn) btn.classList.remove('busy');
  }
}

export { esc };
