/* State bersama: user, status server (dari SSE/polling), selisih jam server–klien */
import { get } from './api.js';

export const state = { user: null, status: null, offset: 0, online: true };
const subs = new Set();

export function subscribe(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}
export function setStatus(s, sentAt = null) {
  state.status = s;
  // Selisih jam server dan perangkat ini. Semua tampilan waktu memakai JAM SERVER (bukan jam HP/PC pengguna).
  state.offset = s.server.now - (sentAt ?? Date.now());
  subs.forEach((f) => { try { f(s); } catch (e) { console.error(e); } });
}
export const serverNow = () => Date.now() + state.offset;
export const tz = () => (state.status ? state.status.server.timezone : 'Asia/Jakarta');
export const timeFmt = () => (state.status ? state.status.server.timeFormat : '24');
export const isAdmin = () => !!state.user && state.user.role === 'admin';

export async function refreshStatus() {
  const t0 = Date.now();
  const s = await get('/api/status');
  setStatus(s, (t0 + Date.now()) / 2); // koreksi setengah latensi jaringan
  state.online = true;
  return s;
}
