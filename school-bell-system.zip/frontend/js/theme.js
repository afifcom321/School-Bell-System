/* Diterapkan sebelum halaman digambar agar tidak berkedip (mode gelap/terang) */
(function () {
  try {
    var t = localStorage.getItem('sbs-theme');
    if (!t) t = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', t);
  } catch (e) {
    document.documentElement.setAttribute('data-theme', 'light');
  }
})();
