import { $, $$, on } from './util.js';
import { get, post, ApiError } from './api.js';
import { state, subscribe, setStatus, refreshStatus, isAdmin } from './state.js';
import { toast } from './ui.js';

import { mountDashboard } from './pages/dashboard.js';
import { mountJadwal } from './pages/jadwal.js';
import { mountSound } from './pages/sound.js';
import { mountLogs } from './pages/logs.js';
import { mountPengaturan } from './pages/pengaturan.js';
import { mountSystem } from './pages/system.js';

const PAGES = {
  dashboard: { title: 'Dashboard', mount: mountDashboard },
  jadwal: { title: 'Jadwal Bel', mount: mountJadwal },
  sound: { title: 'Sound', mount: mountSound },
  logs: { title: 'Logs', mount: mountLogs },
  pengaturan: { title: 'Pengaturan', mount: mountPengaturan },
  system: { title: 'System', mount: mountSystem },
};

const els = {
  boot: $('#boot-loading'),
  login: $('#login-page'),
  forcepw: $('#forcepw-page'),
  app: $('#app'),
  pageRoot: $('#page-root'),
  pageTitle: $('#page-title'),
  connDot: $('#conn-dot'),
  connText: $('#conn-text'),
};

let currentCleanup = null;
let es = null;
let pollTimer = null;
let pollBusy = false;

function show(which) {
  els.boot.hidden = which !== 'boot';
  els.login.hidden = which !== 'login';
  els.forcepw.hidden = which !== 'forcepw';
  els.app.hidden = which !== 'app';
}

// ------------------------------------------------------------------- router
function currentPageKey() {
  const key = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('?')[0];
  return PAGES[key] ? key : 'dashboard';
}

/**
 * Setiap halaman memakai elemen #page-root BARU (bukan innerHTML pada elemen lama).
 * Ini penting karena beberapa halaman memasang event listener terdelegasi langsung pada
 * elemen root (lihat util.js `on()`). Jika elemen root didaur ulang, listener dari halaman
 * sebelumnya tidak pernah terlepas — menumpuk dan bisa terpicu bersamaan dengan listener
 * halaman baru saat elemen dengan selector yang sama diklik. Mengganti elemen root membuat
 * listener lama otomatis lepas begitu elemen lama tidak lagi direferensikan.
 */
function freshPageRoot() {
  const el = document.createElement('div');
  el.id = 'page-root';
  el.innerHTML = '<div class="loading">Memuat…</div>';
  els.pageRoot.replaceWith(el);
  els.pageRoot = el;
  return el;
}

async function renderPage() {
  const key = currentPageKey();
  const def = PAGES[key];
  $$('#nav a').forEach((a) => {
    if (a.dataset.page === key) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  els.pageTitle.textContent = def.title;
  document.title = `${def.title} · School Bell System`;

  if (typeof currentCleanup === 'function') {
    try { currentCleanup(); } catch (e) { console.error(e); }
  }
  currentCleanup = null;
  const root = freshPageRoot();
  try {
    currentCleanup = await def.mount(root);
  } catch (err) {
    console.error(err);
    root.innerHTML = `<div class="card"><div class="banner bad">${err.message || 'Gagal memuat halaman'}</div></div>`;
  }
}
window.addEventListener('hashchange', renderPage);

// -------------------------------------------------------------- konektivitas
function setConn(online) {
  state.online = online;
  els.connDot.className = 'dot ' + (online ? 'ok' : 'bad');
  els.connText.textContent = online ? 'Tersambung' : 'Terputus';
}

function startRealtime() {
  stopRealtime();
  try {
    es = new EventSource('/api/events');
    es.addEventListener('status', (e) => {
      setConn(true);
      setStatus(JSON.parse(e.data));
    });
    es.addEventListener('problem', (e) => {
      const p = JSON.parse(e.data);
      toast(p.message, 'error');
    });
    es.onerror = () => {
      setConn(false);
      // EventSource akan mencoba menyambung ulang sendiri; polling jadi cadangan sementara
      startPolling();
    };
    es.onopen = () => stopPolling();
  } catch {
    startPolling();
  }
}
function stopRealtime() {
  if (es) { es.close(); es = null; }
}
function startPolling() {
  if (pollTimer) return;
  pollTimer = setInterval(async () => {
    if (pollBusy) return;
    pollBusy = true;
    try {
      await refreshStatus();
      setConn(true);
    } catch {
      setConn(false);
    } finally {
      pollBusy = false;
    }
  }, 4000);
}
function stopPolling() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
}

// ------------------------------------------------------------------- header
function paintHeader() {
  const school = (state.status && state.status.app.schoolName) || 'School Bell';
  $('#brand-name').textContent = school;
  $('#mobile-brand-name').textContent = school;
  $('#login-school-name').textContent = school;
  document.title = document.title.replace(/^.* · /, '') ; // reset, diisi ulang oleh renderPage
  if (state.user) {
    $('#who-name').textContent = state.user.username;
    $('#who-role').textContent = state.user.role === 'admin' ? 'Administrator' : 'Viewer';
    $('#who-avatar').textContent = state.user.username.slice(0, 1).toUpperCase();
  }
}
subscribe(paintHeader);

// ---------------------------------------------------------------------- auth
async function boot() {
  show('boot');
  try {
    const me = await get('/api/auth/me');
    state.user = me.user;
  } catch {
    show('login');
    wireLogin();
    return;
  }
  if (state.user.mustChangePassword) {
    show('forcepw');
    wireForcePw();
    return;
  }
  await enterApp();
}

async function enterApp() {
  try {
    await refreshStatus();
  } catch (err) {
    toast(err.message, 'error');
  }
  paintHeader();
  show('app');
  applyAdminVisibility();
  startRealtime();
  if (!location.hash) location.hash = '#/dashboard';
  await renderPage();
}

function applyAdminVisibility() {
  document.body.classList.toggle('is-viewer', !isAdmin());
}

function wireLogin() {
  const form = $('#login-form');
  const err = $('#login-error');
  form.onsubmit = async (e) => {
    e.preventDefault();
    err.hidden = true;
    const btn = $('#login-submit');
    btn.classList.add('busy');
    btn.disabled = true;
    try {
      const r = await post('/api/auth/login', { username: $('#login-username').value.trim(), password: $('#login-password').value });
      state.user = r.user;
      form.reset();
      if (r.user.mustChangePassword) {
        show('forcepw');
        wireForcePw();
      } else {
        await enterApp();
      }
    } catch (ex) {
      err.hidden = false;
      err.textContent = ex.message;
    } finally {
      btn.classList.remove('busy');
      btn.disabled = false;
    }
  };
}

function wireForcePw() {
  const form = $('#forcepw-form');
  const err = $('#forcepw-error');
  form.onsubmit = async (e) => {
    e.preventDefault();
    err.hidden = true;
    const cur = $('#fp-current').value;
    const nw = $('#fp-new').value;
    const cf = $('#fp-confirm').value;
    if (nw !== cf) {
      err.hidden = false;
      err.textContent = 'Konfirmasi password baru tidak sama';
      return;
    }
    try {
      await post('/api/auth/change-password', { currentPassword: cur, newPassword: nw });
      const me = await get('/api/auth/me');
      state.user = me.user;
      toast('Password berhasil diganti', 'ok');
      form.reset();
      await enterApp();
    } catch (ex) {
      err.hidden = false;
      err.textContent = ex.message;
    }
  };
}

$('#logout-btn').addEventListener('click', async () => {
  stopRealtime();
  stopPolling();
  try { await post('/api/auth/logout', {}); } catch { /* abaikan */ }
  state.user = null;
  location.hash = '';
  show('login');
  wireLogin();
});

$('#theme-toggle').addEventListener('click', () => {
  const cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  try { localStorage.setItem('sbs-theme', next); } catch { /* mode privat */ }
});

window.addEventListener('auth:required', () => {
  stopRealtime();
  stopPolling();
  if (state.user) toast('Sesi berakhir, silakan login kembali', 'error');
  state.user = null;
  show('login');
  wireLogin();
});
window.addEventListener('auth:change-password', () => {
  show('forcepw');
  wireForcePw();
});
window.addEventListener('online', () => location.hash && renderPage());

boot();
