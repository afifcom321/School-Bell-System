/* Utilitas: templating aman (anti-XSS), format waktu berbasis timezone server */

export class Raw {
  constructor(s) { this.s = s; }
  toString() { return this.s; }
}
export const raw = (s) => new Raw(s);
export const esc = (v) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

function toStr(v) {
  if (v instanceof Raw) return v.s;
  if (Array.isArray(v)) return v.map(toStr).join('');
  if (v === false || v === null || v === undefined) return '';
  return esc(v);
}

/** Template tag: semua nilai di-escape kecuali berupa Raw (hasil html`` lain / icon()) */
export function html(strings, ...vals) {
  let out = strings[0];
  vals.forEach((v, i) => { out += toStr(v) + strings[i + 1]; });
  return new Raw(out);
}
export function setHtml(el, content) { el.innerHTML = content instanceof Raw ? content.s : String(content); }

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Delegasi event: on(container, 'click', '[data-act]', (e, el) => …) */
export function on(container, type, selector, handler) {
  container.addEventListener(type, (e) => {
    const el = e.target.closest(selector);
    if (el && container.contains(el)) handler(e, el);
  });
}

export const DAY_SHORT = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
export const DAY_LONG = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
export const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0]; // tampilan Senin → Minggu

const fmtCache = new Map();
function dtf(key, opts, locale = 'en-US') {
  const k = `${locale}|${key}`;
  if (!fmtCache.has(k)) fmtCache.set(k, new Intl.DateTimeFormat(locale, opts));
  return fmtCache.get(k);
}

/** Pecah jam: { hh, mm, ss, period } di timezone server, 24/12 jam */
export function clockParts(ms, tz, format) {
  const hourCycle = format === '12' ? 'h12' : 'h23';
  const parts = dtf(`clock|${tz}|${hourCycle}`, { timeZone: tz, hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle }).formatToParts(new Date(ms));
  const o = {};
  for (const p of parts) o[p.type] = p.value;
  return { hh: o.hour === '24' ? '00' : o.hour, mm: o.minute, ss: o.second, period: format === '12' ? (o.dayPeriod || '').toUpperCase() : '' };
}
export const clockText = (ms, tz, format) => {
  const p = clockParts(ms, tz, format);
  return `${p.hh}:${p.mm}:${p.ss}${p.period ? ' ' + p.period : ''}`;
};
export function dateLong(ms, tz) {
  return dtf(`dl|${tz}`, { timeZone: tz, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }, 'id-ID').format(new Date(ms));
}
export function dateShort(ms, tz) {
  return dtf(`ds|${tz}`, { timeZone: tz, day: 'numeric', month: 'short', year: 'numeric' }, 'id-ID').format(new Date(ms));
}
export function dateTimeShort(ms, tz, format) {
  return `${dateShort(ms, tz)}, ${clockText(ms, tz, format)}`;
}
/** '07:30' → '07:30' atau '7:30 AM' */
export function hhmm(t, format) {
  if (!t || format !== '12') return t || '';
  const [h, m] = t.split(':').map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}
export function countdown(ms) {
  let s = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(s / 86400); s -= d * 86400;
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  const p = (n) => String(n).padStart(2, '0');
  if (d > 0) return `${d} hari ${p(h)}:${p(m)}:${p(s)}`;
  if (h > 0) return `${h}:${p(m)}:${p(s)}`;
  return `${p(m)}:${p(s)}`;
}
export const fmtSize = (b) => (b == null ? '-' : b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);
export const fmtDur = (s) => (s == null ? '-' : s >= 60 ? `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, '0')} menit` : `${s.toFixed(1)} dtk`);
export const todayIso = (ms, tz) => {
  const p = {};
  for (const x of dtf(`iso|${tz}`, { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date(ms))) p[x.type] = x.value;
  return `${p.year}-${p.month}-${p.day}`;
};

/** Ringkasan hari: "Senin–Jumat", "Setiap hari", atau chip per hari */
export function daysHtml(days) {
  const set = new Set(days);
  if (set.size === 7) return html`<span class="pill brass">Setiap hari</span>`;
  if (set.size === 5 && [1, 2, 3, 4, 5].every((d) => set.has(d))) return html`<span class="pill">Senin–Jumat</span>`;
  return html`<span class="chips">${DAY_ORDER.filter((d) => set.has(d)).map((d) => html`<span class="chip on">${DAY_SHORT[d]}</span>`)}</span>`;
}

export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
