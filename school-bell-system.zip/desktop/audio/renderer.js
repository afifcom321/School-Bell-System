'use strict';
/* Berjalan di dalam jendela tersembunyi. Tidak punya akses Node — hanya lewat window.audioBridge (preload.js). */
(function () {
  const audio = document.getElementById('a');
  let limitTimer = null;
  let finished = false;

  function clearLimit() {
    clearTimeout(limitTimer);
    limitTimer = null;
  }

  function finish() {
    if (finished) return;
    finished = true;
    clearLimit();
    window.audioBridge.reportEnded();
  }

  window.audioBridge.onPlay(({ url, volume, seconds }) => {
    finished = false;
    clearLimit();
    try {
      audio.pause();
      audio.currentTime = 0;
      audio.src = url;
      audio.volume = Math.min(Math.max(Number(volume) || 0, 0), 1);
      const p = audio.play();
      if (p && p.catch) p.catch((err) => { finished = true; window.audioBridge.reportError(err.message || String(err)); });
      if (seconds && seconds > 0) limitTimer = setTimeout(() => { audio.pause(); finish(); }, seconds * 1000);
    } catch (err) {
      finished = true;
      window.audioBridge.reportError(err.message || String(err));
    }
  });

  window.audioBridge.onStop(() => {
    try {
      audio.pause();
    } catch { /* abaikan */ }
    finish();
  });

  audio.addEventListener('ended', finish);
  audio.addEventListener('error', () => {
    if (finished) return;
    finished = true;
    clearLimit();
    const err = audio.error;
    window.audioBridge.reportError(err ? `Kode error media: ${err.code}` : 'Gagal memutar audio');
  });
})();
