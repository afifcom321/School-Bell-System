'use strict';
const { contextBridge, ipcRenderer } = require('electron');

/**
 * Jembatan IPC yang sempit dan aman untuk jendela pemutar audio tersembunyi.
 * Tidak mengekspos Node/Electron API apa pun selain 4 fungsi ini.
 */
contextBridge.exposeInMainWorld('audioBridge', {
  onPlay: (cb) => ipcRenderer.on('audio:play', (_e, data) => cb(data)),
  onStop: (cb) => ipcRenderer.on('audio:stop', () => cb()),
  reportEnded: () => ipcRenderer.send('audio:ended'),
  reportError: (message) => ipcRenderer.send('audio:error', message),
});
