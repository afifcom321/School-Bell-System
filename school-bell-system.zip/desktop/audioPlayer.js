'use strict';
const path = require('path');
const { pathToFileURL } = require('url');

/**
 * Backend audio utama untuk aplikasi desktop: memutar suara lewat elemen <audio> Chromium
 * di jendela tersembunyi. Lebih andal daripada backend sistem (server/audio/systemPlayer.js)
 * karena tidak bergantung pada program eksternal (ffplay/PowerShell) dan mendukung MP3/WAV/OGG
 * secara native lewat Chromium.
 *
 * @param {{BrowserWindow: Function, ipcMain: import('electron').IpcMain}} electronRefs
 */
function createElectronAudioBackend({ BrowserWindow, ipcMain }) {
  let win = null;
  let pending = null; // { resolve, reject } — hanya satu pemutaran aktif pada satu waktu (dikelola AudioManager)

  function settle(fn, ...args) {
    if (!pending) return;
    const p = pending;
    pending = null;
    p[fn](...args);
  }

  ipcMain.on('audio:ended', () => settle('resolve'));
  ipcMain.on('audio:error', (e, message) => settle('reject', new Error(message || 'Gagal memutar audio')));

  function ensureWindow() {
    if (win && !win.isDestroyed()) return win;
    win = new BrowserWindow({
      show: false,
      skipTaskbar: true,
      webPreferences: {
        preload: path.join(__dirname, 'audio', 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true,
      },
    });
    win.loadFile(path.join(__dirname, 'audio', 'player.html'));
    win.webContents.on('render-process-gone', (e, details) => {
      settle('reject', new Error(`Jendela pemutar audio berhenti bekerja (${details.reason})`));
      win = null;
    });
    win.on('closed', () => {
      win = null;
    });
    return win;
  }

  return {
    name: 'electron (jendela audio Chromium)',
    play({ filepath, volume, seconds }) {
      return new Promise((resolve, reject) => {
        const w = ensureWindow();
        pending = { resolve, reject };
        const fileUrl = pathToFileURL(filepath).toString();
        const send = () => w.webContents.send('audio:play', { url: fileUrl, volume, seconds });
        if (w.webContents.isLoadingMainFrame()) w.webContents.once('did-finish-load', send);
        else send();
      });
    },
    stop() {
      if (win && !win.isDestroyed()) win.webContents.send('audio:stop');
    },
    destroy() {
      if (win && !win.isDestroyed()) win.destroy();
      win = null;
    },
  };
}

module.exports = { createElectronAudioBackend };
