'use strict';
const path = require('path');
const { app, BrowserWindow, Tray, Menu, ipcMain, shell, powerSaveBlocker, nativeImage, dialog } = require('electron');

const { createBellApp } = require('../server');
const { createElectronAudioBackend } = require('./audioPlayer');

const isDev = process.argv.includes('--dev');
const ICON_PATH = path.join(__dirname, 'assets', 'icon.png');
const TRAY_ICON_PATH = path.join(__dirname, 'assets', 'tray.png');

let bell = null;
let controlWin = null;
let tray = null;
let quitting = false;
let sleepBlockerId = null;

// --------------------------------------------------------------- single instance
// Mencegah dua salinan aplikasi berjalan bersamaan (yang akan berebut port & file database)
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    showControlWindow();
  });
}

// ------------------------------------------------------------------- lifecycle
app.whenReady().then(async () => {
  if (!gotLock) return;

  // Folder data aplikasi: %APPDATA%/School Bell System (Windows), ~/Library/Application Support/... (mac),
  // ~/.config/... (Linux). Dev mode tetap memakai folder project (lihat server/paths.js).
  const home = isDev ? undefined : app.getPath('userData');

  bell = await createBellApp({ home }).catch((err) => {
    dialog.showErrorBox('School Bell System', `Gagal memulai aplikasi:\n${err.message}`);
    app.quit();
    throw err;
  });
  if (!bell) return;

  bell.audio.setBackend(createElectronAudioBackend({ BrowserWindow, ipcMain }));

  applyPowerSaveBlocker();
  bell.on('change', () => pushStatus());
  bell.on('problem', (p) => pushProblem(p));
  bell.on('log', () => pushStatus());

  if (bell.config.startSchedulerAutomatically) bell.startScheduler();
  if (bell.config.startServerAutomatically) await bell.startServer();

  createTray();
  createControlWindow();
  syncAutostart();

  if (bell.config.launchDashboardAutomatically && bell.serverState.running) {
    shell.openExternal(bell.getInfo().localUrl);
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createControlWindow();
    else showControlWindow();
  });
});

app.on('window-all-closed', (e) => {
  // Aplikasi tetap berjalan di tray (bel harus tetap aktif walau jendela kontrol ditutup)
  e.preventDefault?.();
});

app.on('before-quit', async (e) => {
  if (quitting || !bell) return;
  e.preventDefault();
  quitting = true;
  if (sleepBlockerId != null) powerSaveBlocker.stop(sleepBlockerId);
  try {
    await bell.shutdown();
  } catch {
    /* tetap lanjut keluar walau ada error saat shutdown */
  }
  app.quit();
});

// ------------------------------------------------------------------- tray
function createTray() {
  const img = nativeImage.createFromPath(TRAY_ICON_PATH);
  tray = new Tray(img.isEmpty() ? nativeImage.createEmpty() : img);
  tray.setToolTip('School Bell System');
  tray.on('click', () => showControlWindow());
  rebuildTrayMenu();
}

function rebuildTrayMenu() {
  if (!tray) return;
  const info = bell.getInfo();
  const schedRunning = bell.scheduler.running;
  const menu = Menu.buildFromTemplate([
    { label: 'School Bell System', enabled: false },
    { label: info.running ? `Server aktif — port ${info.port}` : 'Server tidak aktif', enabled: false },
    { type: 'separator' },
    { label: 'Buka Panel Kontrol', click: () => showControlWindow() },
    { label: 'Buka Dashboard', enabled: info.running, click: () => shell.openExternal(info.localUrl) },
    { type: 'separator' },
    {
      label: schedRunning ? 'Nonaktifkan Jadwal Otomatis' : 'Aktifkan Jadwal Otomatis',
      click: () => { schedRunning ? bell.stopScheduler() : bell.startScheduler(); rebuildTrayMenu(); },
    },
    {
      label: 'Bunyikan Bel Sekarang',
      click: () => {
        const r = bell.triggerManual({ actor: 'Panel Kontrol' });
        if (!r.ok) dialog.showErrorBox('School Bell System', r.error);
      },
    },
    { type: 'separator' },
    { label: 'Keluar', click: () => app.quit() },
  ]);
  tray.setContextMenu(menu);
}

// -------------------------------------------------------------- control window
function createControlWindow() {
  if (controlWin && !controlWin.isDestroyed()) return showControlWindow();
  controlWin = new BrowserWindow({
    width: 480,
    height: 640,
    minWidth: 420,
    minHeight: 560,
    icon: ICON_PATH,
    title: 'School Bell System — Panel Kontrol',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  controlWin.setMenuBarVisibility(false);
  controlWin.loadFile(path.join(__dirname, 'control', 'index.html'));
  controlWin.on('close', (e) => {
    if (!quitting && bell.config.minimizeToTray) {
      e.preventDefault();
      controlWin.hide();
    }
  });
  controlWin.on('closed', () => { controlWin = null; });
  if (isDev) controlWin.webContents.openDevTools({ mode: 'detach' });
}
function showControlWindow() {
  if (!controlWin || controlWin.isDestroyed()) return createControlWindow();
  if (controlWin.isMinimized()) controlWin.restore();
  controlWin.show();
  controlWin.focus();
}

// --------------------------------------------------------------- push status
function pushStatus() {
  rebuildTrayMenu();
  if (controlWin && !controlWin.isDestroyed()) {
    controlWin.webContents.send('bell:status', buildControlSnapshot());
  }
}
function pushProblem(p) {
  if (controlWin && !controlWin.isDestroyed()) controlWin.webContents.send('bell:problem', p);
  if (tray) tray.displayBalloon && tray.displayBalloon({ title: 'School Bell System', content: p.message, icon: nativeImage.createFromPath(ICON_PATH) });
}
function buildControlSnapshot() {
  const status = bell.buildStatus();
  return { info: bell.getInfo(), config: bell.config, status };
}

// --------------------------------------------------------------------- autostart
function syncAutostart() {
  try {
    app.setLoginItemSettings({
      openAtLogin: !!bell.config.startWithWindows,
      openAsHidden: true,
      args: ['--autostart'],
    });
  } catch {
    /* platform tidak didukung (mis. dijalankan lewat npm run dev di Linux) */
  }
}

function applyPowerSaveBlocker() {
  const want = !!bell.config.preventSleep;
  const active = sleepBlockerId != null && powerSaveBlocker.isStarted(sleepBlockerId);
  if (want && !active) sleepBlockerId = powerSaveBlocker.start('prevent-app-suspension');
  if (!want && active) {
    powerSaveBlocker.stop(sleepBlockerId);
    sleepBlockerId = null;
  }
}

// ------------------------------------------------------------------------- IPC
ipcMain.handle('control:get-snapshot', () => buildControlSnapshot());

ipcMain.handle('control:server-start', () => bell.startServer());
ipcMain.handle('control:server-stop', () => bell.stopServer());
ipcMain.handle('control:server-restart', () => bell.restartServer());
ipcMain.handle('control:scheduler-start', () => { bell.startScheduler(); return buildControlSnapshot(); });
ipcMain.handle('control:scheduler-stop', () => { bell.stopScheduler(); return buildControlSnapshot(); });

ipcMain.handle('control:open-dashboard', () => {
  const info = bell.getInfo();
  if (!info.running) throw new Error('Web server belum berjalan');
  shell.openExternal(info.localUrl);
});
ipcMain.handle('control:open-data-folder', () => shell.openPath(bell.paths.home));
ipcMain.handle('control:copy-url', (e, url) => require('electron').clipboard.writeText(url));

ipcMain.handle('control:set-config', (e, patch) => {
  const allowed = ['startServerAutomatically', 'startSchedulerAutomatically', 'startWithWindows', 'launchDashboardAutomatically', 'minimizeToTray', 'preventSleep', 'port'];
  const clean = {};
  for (const k of allowed) if (k in patch) clean[k] = patch[k];
  bell.updateConfig(clean);
  syncAutostart();
  applyPowerSaveBlocker();
  return bell.config;
});

ipcMain.handle('control:trigger-bell', () => bell.triggerManual({ actor: 'Panel Kontrol' }));
ipcMain.handle('control:stop-bell', () => { bell.audio.stop(); return { ok: true }; });

ipcMain.handle('control:quit', () => app.quit());
