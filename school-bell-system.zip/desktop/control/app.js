'use strict';
(function () {
  const $ = (s) => document.querySelector(s);
  let cfgDirty = false;

  function toast(msg, kind = 'ok') {
    const box = $('#toasts');
    const el = document.createElement('div');
    el.className = 'toast' + (kind === 'error' ? ' error' : '');
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => el.remove(), kind === 'error' ? 6000 : 3500);
  }

  async function withBusy(btn, fn) {
    const prev = btn ? btn.disabled : false;
    if (btn) btn.disabled = true;
    try {
      return await fn();
    } catch (err) {
      toast(err.message || String(err), 'error');
    } finally {
      if (btn) btn.disabled = prev;
    }
  }

  function paint(snap) {
    const { info, config, status } = snap;

    $('#version-text').textContent = `Panel Kontrol · v${status.app.version}`;

    $('#server-dot').className = 'dot ' + (info.running ? 'ok' : 'bad');
    $('#server-status').textContent = info.running ? `Aktif di port ${info.port}` : 'Tidak aktif';
    $('#server-error').hidden = !info.error;
    $('#server-error').textContent = info.error || '';
    $('#btn-server-start').disabled = info.running;
    $('#btn-server-stop').disabled = !info.running;

    const list = $('#url-list');
    list.innerHTML = '';
    const rows = [{ label: 'Komputer ini', url: info.localUrl }, ...info.urls.map((u) => ({ label: `Jaringan (${u.interface})`, url: u.url }))];
    for (const r of rows) {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = '#';
      a.textContent = r.url;
      a.title = r.label;
      a.addEventListener('click', (e) => { e.preventDefault(); window.control.openDashboard().catch((err) => toast(err.message, 'error')); });
      const btn = document.createElement('button');
      btn.textContent = 'Salin';
      btn.addEventListener('click', () => { window.control.copyUrl(r.url); toast('Alamat disalin'); });
      li.append(a, btn);
      list.appendChild(li);
    }
    if (!rows.length) list.innerHTML = '<li class="hint">Tidak ada alamat terdeteksi</li>';

    $('#sw-scheduler').checked = status.scheduler.running;
    $('#scheduler-status').textContent = status.scheduler.running
      ? `Aktif — ${status.scheduler.activeScheduleCount} dari ${status.scheduler.scheduleCount} jadwal diaktifkan`
      : 'Tidak aktif — bel otomatis tidak akan berbunyi';

    if (!cfgDirty) {
      $('#cfg-startServerAutomatically').checked = config.startServerAutomatically;
      $('#cfg-startSchedulerAutomatically').checked = config.startSchedulerAutomatically;
      $('#cfg-launchDashboardAutomatically').checked = config.launchDashboardAutomatically;
      $('#cfg-minimizeToTray').checked = config.minimizeToTray;
      $('#cfg-preventSleep').checked = config.preventSleep;
      $('#cfg-startWithWindows').checked = config.startWithWindows;
      $('#cfg-port').value = config.port;
    }
    $('#port-hint').hidden = Number($('#cfg-port').value) === info.port;
  }

  async function refresh() {
    const snap = await window.control.getSnapshot();
    paint(snap);
  }

  $('#btn-server-start').addEventListener('click', (e) => withBusy(e.target, async () => { await window.control.startServer(); await refresh(); }));
  $('#btn-server-stop').addEventListener('click', (e) => withBusy(e.target, async () => { await window.control.stopServer(); await refresh(); }));
  $('#btn-server-restart').addEventListener('click', (e) => withBusy(e.target, async () => { await window.control.restartServer(); await refresh(); toast('Server di-restart'); }));

  $('#sw-scheduler').addEventListener('change', (e) =>
    withBusy(null, async () => {
      e.target.checked ? await window.control.startScheduler() : await window.control.stopScheduler();
      await refresh();
    })
  );

  $('#btn-ring').addEventListener('click', (e) =>
    withBusy(e.target, async () => {
      const r = await window.control.triggerBell();
      if (!r.ok) throw new Error(r.error);
      toast('Bel dibunyikan');
    })
  );
  $('#btn-stop-ring').addEventListener('click', () => window.control.stopBell());
  $('#btn-open-dashboard').addEventListener('click', (e) => withBusy(e.target, () => window.control.openDashboard()));
  $('#btn-open-folder').addEventListener('click', () => window.control.openDataFolder());
  $('#btn-quit').addEventListener('click', () => window.control.quit());

  const cfgIds = ['startServerAutomatically', 'startSchedulerAutomatically', 'launchDashboardAutomatically', 'minimizeToTray', 'preventSleep', 'startWithWindows'];
  let saveTimer = null;
  function scheduleSave() {
    cfgDirty = true;
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      const patch = {};
      for (const id of cfgIds) patch[id] = $(`#cfg-${id}`).checked;
      patch.port = Math.min(65535, Math.max(1, Number($('#cfg-port').value) || 3000));
      try {
        await window.control.setConfig(patch);
        toast('Pengaturan disimpan');
      } catch (err) {
        toast(err.message, 'error');
      } finally {
        cfgDirty = false;
        refresh();
      }
    }, 500);
  }
  for (const id of cfgIds) $(`#cfg-${id}`).addEventListener('change', scheduleSave);
  $('#cfg-port').addEventListener('input', () => { cfgDirty = true; $('#port-hint').hidden = false; });
  $('#cfg-port').addEventListener('change', scheduleSave);

  window.control.onStatus((snap) => paint(snap));
  window.control.onProblem((p) => toast(p.message, 'error'));

  refresh();
  setInterval(refresh, 5000);
})();
