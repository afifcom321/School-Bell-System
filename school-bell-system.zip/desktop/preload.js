'use strict';
const { contextBridge, ipcRenderer } = require('electron');

/** Jembatan IPC sempit untuk Panel Kontrol. Tidak ada akses Node/fs langsung dari renderer. */
contextBridge.exposeInMainWorld('control', {
  getSnapshot: () => ipcRenderer.invoke('control:get-snapshot'),

  startServer: () => ipcRenderer.invoke('control:server-start'),
  stopServer: () => ipcRenderer.invoke('control:server-stop'),
  restartServer: () => ipcRenderer.invoke('control:server-restart'),
  startScheduler: () => ipcRenderer.invoke('control:scheduler-start'),
  stopScheduler: () => ipcRenderer.invoke('control:scheduler-stop'),

  openDashboard: () => ipcRenderer.invoke('control:open-dashboard'),
  openDataFolder: () => ipcRenderer.invoke('control:open-data-folder'),
  copyUrl: (url) => ipcRenderer.invoke('control:copy-url', url),

  setConfig: (patch) => ipcRenderer.invoke('control:set-config', patch),

  triggerBell: () => ipcRenderer.invoke('control:trigger-bell'),
  stopBell: () => ipcRenderer.invoke('control:stop-bell'),

  quit: () => ipcRenderer.invoke('control:quit'),

  onStatus: (cb) => ipcRenderer.on('bell:status', (_e, data) => cb(data)),
  onProblem: (cb) => ipcRenderer.on('bell:problem', (_e, data) => cb(data)),
});
