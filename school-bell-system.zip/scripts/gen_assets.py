#!/usr/bin/env python3
"""
Membuat aset bawaan project:
  - default-sounds/bell.wav        (bel masuk, bel listrik klasik)
  - default-sounds/istirahat.wav   (chime 4 nada)
  - default-sounds/pulang.wav      (melodi turun)
  - build/icon.png, desktop/assets/icon.png, desktop/assets/tray.png

Dijalankan sekali saat pengembangan; hasilnya sudah disertakan di repo.
Kebutuhan: python3, numpy, pillow   (pip install numpy pillow)
"""
import os
import wave
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 44100


def write_wav(path, samples):
    samples = np.clip(samples, -1, 1)
    data = (samples * 32767 * 0.9).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())
    print("wrote", path, f"{len(samples) / SR:.1f}s")


def t_axis(sec):
    return np.arange(int(SR * sec)) / SR


def bell_tone(freq, sec, decay=3.0):
    """Nada lonceng: partial tidak harmonis dengan peluruhan eksponensial."""
    t = t_axis(sec)
    partials = [(1.0, 1.0), (2.0, 0.55), (2.76, 0.4), (5.4, 0.22), (8.93, 0.1)]
    out = np.zeros_like(t)
    for ratio, amp in partials:
        out += amp * np.sin(2 * np.pi * freq * ratio * t) * np.exp(-decay * ratio ** 0.6 * t)
    attack = np.minimum(t / 0.004, 1.0)
    return out * attack


def place(track, tone, at):
    i = int(at * SR)
    n = min(len(tone), len(track) - i)
    if n > 0:
        track[i:i + n] += tone[:n]


def fade_out(x, sec=0.25):
    n = int(sec * SR)
    x[-n:] *= np.linspace(1, 0, n)
    return x


def normalize(x):
    return x / (np.max(np.abs(x)) + 1e-9)


def school_bell():
    """Bel listrik: nada logam dimodulasi ~18 Hz (palu bergetar), sekitar 3.5 detik."""
    dur = 3.6
    t = t_axis(dur)
    carrier = sum(a * np.sin(2 * np.pi * f * t) for f, a in [(1750, 1.0), (2380, 0.6), (3150, 0.45), (4700, 0.25)])
    hammer = (np.sign(np.sin(2 * np.pi * 18 * t)) * 0.5 + 0.5)
    hammer = np.convolve(hammer, np.ones(60) / 60, mode="same")  # haluskan tepi
    env = np.minimum(t / 0.02, 1.0)
    out = carrier * (0.25 + 0.75 * hammer) * env
    return fade_out(normalize(out), 0.4)


def chime_break():
    """Empat nada naik (C5 E5 G5 C6), lembut."""
    track = np.zeros(int(SR * 5.5))
    for i, f in enumerate([523.25, 659.25, 783.99, 1046.5]):
        place(track, bell_tone(f, 3.0, decay=1.6), 0.55 * i)
    return fade_out(normalize(track), 0.5)


def chime_home():
    """Melodi turun (G5 E5 C5 G4) lalu akor penutup."""
    track = np.zeros(int(SR * 7.0))
    for i, f in enumerate([783.99, 659.25, 523.25, 392.0]):
        place(track, bell_tone(f, 3.2, decay=1.4), 0.7 * i)
    for f in (261.63, 329.63, 392.0):
        place(track, bell_tone(f, 3.8, decay=1.2) * 0.6, 2.9)
    return fade_out(normalize(track), 0.6)


def make_sounds():
    d = os.path.join(ROOT, "default-sounds")
    os.makedirs(d, exist_ok=True)
    write_wav(os.path.join(d, "bell.wav"), school_bell())
    write_wav(os.path.join(d, "istirahat.wav"), chime_break())
    write_wav(os.path.join(d, "pulang.wav"), chime_home())


def make_icons():
    from PIL import Image, ImageDraw

    S = 2048
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    # latar rounded-square biru tua
    d.rounded_rectangle((0, 0, S - 1, S - 1), radius=int(S * 0.22), fill=(20, 33, 61, 255))
    amber = (244, 178, 30, 255)
    amber_dark = (201, 136, 0, 255)
    cx = S // 2
    # badan lonceng: kubah + rok melebar
    d.ellipse((cx - 470, 470, cx + 470, 1300), fill=amber)
    d.polygon([(cx - 470, 900), (cx + 470, 900), (cx + 760, 1470), (cx - 760, 1470)], fill=amber)
    d.rounded_rectangle((cx - 800, 1420, cx + 800, 1560), radius=70, fill=amber_dark)
    # gagang atas + pemukul
    d.ellipse((cx - 90, 330, cx + 90, 510), fill=amber_dark)
    d.ellipse((cx - 150, 1520, cx + 150, 1820), fill=amber_dark)
    # kilau
    d.ellipse((cx - 330, 640, cx - 210, 900), fill=(255, 226, 140, 255))
    # garis suara
    for r, a in ((880, 200), (1010, 120)):
        d.arc((cx - r, 800 - r + 200, cx + r, 800 + r + 200), start=200, end=250, fill=(244, 178, 30, a), width=40)
        d.arc((cx - r, 800 - r + 200, cx + r, 800 + r + 200), start=290, end=340, fill=(244, 178, 30, a), width=40)

    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "desktop", "assets"), exist_ok=True)
    img.resize((512, 512), Image.LANCZOS).save(os.path.join(ROOT, "build", "icon.png"))
    img.resize((256, 256), Image.LANCZOS).save(os.path.join(ROOT, "desktop", "assets", "icon.png"))
    # ikon tray: bel amber polos di latar transparan agar terbaca di taskbar gelap/terang
    tray = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    td = ImageDraw.Draw(tray)
    td.ellipse((cx - 560, 300, cx + 560, 1300), fill=amber)
    td.polygon([(cx - 560, 800), (cx + 560, 800), (cx + 900, 1560), (cx - 900, 1560)], fill=amber)
    td.rounded_rectangle((cx - 960, 1500, cx + 960, 1660), radius=80, fill=amber_dark)
    td.ellipse((cx - 190, 1620, cx + 190, 2000), fill=amber_dark)
    tray.resize((64, 64), Image.LANCZOS).save(os.path.join(ROOT, "desktop", "assets", "tray.png"))
    print("wrote icons")


if __name__ == "__main__":
    make_sounds()
    make_icons()
